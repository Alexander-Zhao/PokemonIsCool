
import java.util.HashMap;
import java.util.Scanner;
import java.util.ArrayList;

public class Player {
    public int money = 0;
    private static final Scanner input = new Scanner(System.in);
    private Pokemon myPokemon = null;
    String actionType;
    boolean isStart = true;
    boolean veryRandom;
    int temporary;
    boolean lose = false;
    boolean win = false;
    public Player() {
        if (isStart) getStarter();
        isStart = false;
    }
    public void menu() {
        System.out.print("What do you want to do? (Shop, Battle, Inventory, Switch Pokemon, Pokemon Stats, and I am a nerd and I quit):\n> ");
        actionType = input.nextLine();
        if (actionType.equals("I am a nerd and I quit")) {
            System.out.println("nerd");
            return;
        }
        action();
        System.out.println();
        if (myPokemon.level >= 20) win = true;
        if (win) System.out.println("\nYou win the game!");
        if (!lose || !win) menu();
    }
    public void getStarter() {
        myPokemon = Pokemon.getRandPokemon();
        System.out.println(myPokemon.toString());
    }
    public void action() {
        switch (actionType) {
            case "Shop":
                shop();
                break;
            case "Battle":
                if ((int)Math.random() * 10 == 1) gainMedicine();
                else startBattle();    
                break;
            case "Inventory":
                printItems();
                break;
            case "Switch Pokemon":
                if (money < 10000) {
                    System.out.println("You are too poor to do this action.");
                }
                else {
                    System.out.println("It costs 10,000$ to switch pokemon are you sure? (y/n)");
                    char confirm = input.nextLine().charAt(0);
                    if (confirm == 'y') switchPokemon();
                    }
                break;
            case "Pokemon Stats":
                System.out.println(myPokemon.toString());
                break;
            default:
                System.out.println("Please input an actual action");
                break;
        } 
    }

    public void switchPokemon() {
        money -= 10000;
        Pokemon temp = Pokemon.getRandPokemon();
        temp.xp = myPokemon.xp / 2;
        temp.level = myPokemon.level / 2;
        myPokemon = temp;
        System.out.println("You have gotten a new pokemon, " + myPokemon);
    }
    public void gainMedicine() {
        int temp = (int)(Math.random() * 6);
        switch (temp) {
            case 0:
                gainItem("HP Up");
                break;
            case 1:
                gainItem("Protein");
                break;
            case 2:
                gainItem("Iron");
                break;
            case 3:
                gainItem("Calcium");
                break;
            case 4:
                gainItem("Zinc");
                break;
            case 5:
                gainItem("Carbos");
                break;
        }
    }
    public void startBattle() {
        Pokemon enemy = Pokemon.getRandPokemon();
        enemy.level = myPokemon.level - 2;
        enemy.statsEV();
        enemy.maxHp = enemy.hp;
        System.out.println("A wild " + enemy.name + " has appeared.\nType1 : " + enemy.type1 + "\nType2 : " + enemy.type2);
        loop:
        while (enemy.hp > 0 && myPokemon.hp > 0) {
            System.out.print("\nWhat do you want to do? (Fight, Item, Run):\n> ");
            String battleAction = input.nextLine();
            switch (battleAction) {
                case "Fight":
                    System.out.print("\nWhat type do you want to use? (" + myPokemon.type1 + ", " + myPokemon.type2 + ") Type 1 for type 1\n> ");
                    int temp = input.nextInt();
                    input.nextLine();
                    System.out.print("\nDo you want to use a special attack?(y/n):\n> ");
                    char temp2 = input.nextLine().charAt(0);
                    myPokemon.attack(enemy, temp2 == 'y', temp);
                    break;
                case "Item":
                    printItems();
                    System.out.println("What do you want do use?");
                    String temp3 = input.nextLine();
                    switch (temp3) {
                        case "Potion":
                            usePotion();
                            break;
                        case "Super Potion":
                            useSuperPotion();
                            break;
                        case "Hyper Potion":
                            useHyperPotion();
                            break;
                        case "Max Heal":
                            useMaxHeal();
                            break;
                        case "Normal Gem":
                            useNormalGem();
                            break;
                        case "Fighting Gem":
                            useFightingGem();
                            break;
                        case "Flying Gem":
                            useFlyingGem();
                            break;
                        case "Poison Gem":
                            usePoisonGem();
                            break;
                        case "Ground Gem":
                            useGroundGem();
                            break;
                        case "Rock Gem":
                            useRockGem();
                            break;
                        case "Bug Gem":
                            useBugGem();
                            break;
                        case "Ghost Gem":
                            useGhostGem();
                            break;
                        case "Steel Gem":
                            useSteelGem();
                            break;
                        case "Fire Gem":
                            useFireGem();
                            break;
                        case "Water Gem":
                            useWaterGem();
                            break;
                        case "Grass Gem":
                            useGrassGem();
                            break;
                        case "Electric Gem":
                            useElectricGem();
                            break;
                        case "Psychic Gem":
                            usePsychicGem();
                            break;
                        case "Ice Gem":
                            useIceGem();
                            break;
                        case "Dragon Gem":
                            useDragonGem();
                            break;
                        case "Dark Gem":
                            useDarkGem();
                            break;
                        case "Fairy Gem":
                            useFairyGem();
                            break;
                        case "Rare Candy":
                            useRareCandy();
                            break;
                        case "Attack":
                            useAttack();
                            break;
                        case "Defense":
                            useDefense();
                            break;
                        case "Special Attack":
                            useSpecialAttack();
                            break;
                        case "Special Defense":
                            useSpecialDefense();
                            break;
                        case "Speed":
                            useSpeed();
                            break;
                        case "Health Feather":
                            useHealthFeather();
                            break;
                        case "Muscle Feather":
                            useMuscleFeather();
                            break;
                        case "Resist Feather":
                            useResistFeather();
                            break;
                        case "Genuis Feather":
                            useGenuisFeather();
                            break;
                        case "Clever Feather":
                            useCleverFeather();
                            break;
                        case "Swift Feather":
                            useSwiftFeather();
                            break;
                        case "HP Up":
                            useHPUp();
                            break;
                        case "Protein":
                            useProtein();
                            break;
                        case "Iron":
                            useIron();
                            break;
                        case "Calcium":
                            useCalcium();
                            break;
                        case "Zinc":
                            useZinc();
                            break;
                        case "Carbos":
                            useCarbos();
                            break;
                        default:
                            System.out.println("That is not an item, please choose what to do again.");
                            break;
                    }
                    break;
                case "Run":
                    System.out.println("You ran away!");
                    break loop;
                default:
                    System.out.println("Poop");
                    continue loop;
            }
            // TODO: make enemy attack
            System.out.println();
            veryRandom = (int)Math.random() == 1 ? true : false;
            temporary = (int)Math.random();
            enemy.attack(myPokemon, veryRandom, temporary);
        }
        if (myPokemon.hp < 1) {
            System.out.println(myPokemon.name + " fainted. You lost the game.");
            lose = true;
        }
        else if (enemy.hp < 1) {
            System.out.println("\nThe wild " + enemy.name + " fainted.");
            myPokemon.onKill();
            if (myPokemon.level == 20) win = true;
            
            int moneyGain = (int)((Math.random() * 100 + 1) * myPokemon.level) / 2;
            money += moneyGain;
            System.out.println("You got " + moneyGain + "$");
        }
    }
    public void shop() {
        System.out.println("Please don't somehow break the shop, you can buy: ");
        for (int i = 0; i < itemNames.length; i++) {
            if (itemNames[i].contains("Gem")) {
                System.out.println(itemNames[i] + ": 250$");
            }
            else if (itemNames[i].contains("Feather")) {
                System.out.println(itemNames[i] + ": 100$");
            }
            else {
                switch (itemNames[i]) {
                    case "Potion":
                        System.out.println(itemNames[i] + ": 100$");
                        break;
                    case "Super Potion":
                        System.out.println(itemNames[i] + ": 200$");
                        break;
                    case "Hyper Potion":
                        System.out.println(itemNames[i] + ": 350$");
                        break;
                    case "Max Heal":
                        System.out.println(itemNames[i] + ": 500$");
                        break;
                    case "Attack":
                    case "Defense":
                    case "Special Attack":
                    case "Special Defense":
                    case "Speed":
                        System.out.println(itemNames[i] + ": 200$");
                        break;
                    case "Rare Candy":
                        System.out.println(itemNames[i] + ": 400$");
                        break;
                }
            }
        }
        System.out.println();
        System.out.print("Do you want to buy something? (Type the name of the item) You have " + money + "$:\n> ");
        String item = input.nextLine();
        boolean itemExists = false;
        for (int i = 0; i < itemNames.length && !itemExists; i++) {
            if (item.equals(itemNames[i])) itemExists = true;
        }
        if (!itemExists) {
            System.out.println("Are you illiterate? I said type in an item name. Open the shop again if you want to buy something.");
            return;
        }
        
        System.out.println("How many " + item + "s do you want to buy?");
        int amount = 0;
        try {
            amount = input.nextInt();
            input.nextLine();
        } catch(Exception e) {
            // STOOPID
            System.out.println("You are so dumb. Don't even know that you can't buy 0.684324 of a potion. Open the shop again if you want to buy something.");
            return;
        }
        if (amount <= 0) {
            System.out.println("Why are you trying to buy nothing. Stop wasting my time. Open the shop again if you want to buy something.");
            return;
        }
        String displayName = item;
        if (amount > 1) displayName += "s";
        int cost = 0;
        switch (item) {
            case "Potion":
                cost = 100;
                break;
            case "Super Potion":
                cost = 200;
                break;
            case "Hyper Potion":
                cost = 350;
                break;
            case "Max Heal":
                cost = 500;
                break;
            case "Attack":
            case "Defense":
            case "Speed":
            case "Special Attack":
            case "Special Defense":
                cost = 200;
                break;
            case "Normal Gem":
            case "Fighting Gem":
            case "Flying Gem":
            case "Poison Gem":
            case "Ground Gem":
            case "Rock Gem":
            case "Bug Gem":
            case "Ghost Gem":
            case "Steel Gem":
            case "Fire Gem":
            case "Water Gem":
            case "Grass Gem":
            case "Electric Gem":
            case "Psychic Gem":
            case "Ice Gem":
            case "Dragon Gem":
            case "Dark Gem":
            case "Fairy Gem":
                cost = 250;
                break;
            case "Health Feather":
            case "Muscle Feather":
            case "Resist Feather":
            case "Genuis Feather":
            case "Clever Feather":
            case "Swift Feather":
                cost = 100;
                break;
            case "Rare Candy":
                cost = 400;
                break;
        }
        cost *= amount;
        if (money < cost) {
            System.out.println("Please come back when you are rich enough to afford this.");
            return;
        }
        money -= cost;
        System.out.println("You bought " + amount + " " + displayName + ". You spent " + cost + "$.");
        gainItem(item, amount);
    } 

    private HashMap<String, Integer> items = new HashMap<String, Integer>();
    private String[] itemNames = { "Potion", "Super Potion", "Hyper Potion", "Max Heal", "Normal Gem", "Fighting Gem", "Flying Gem", "Poison Gem", "Ground Gem", "Rock Gem", "Bug Gem", "Ghost Gem", "Steel Gem", "Fire Gem", "Water Gem", "Grass Gem", "Electric Gem", "Pyschic Gem", "Ice Gem", "Dragon Gem", "Dark Gem", "Fairy Gem", "Rare Candy", "Attack", "Defense", "Special Attack", "Special Defense", "Speed", "Health Feather", "Muscle Feather", "Resist Feather", "Genuis Feather", "Clever Feather", "Swift Feather", "HP Up", "Protein", "Iron", "Calcium", "Zinc", "Carbos" };
    {
        for (String i : itemNames) items.put(i, 0);
    }
	private boolean hasItem(String item) {
		return items.containsKey(item) && items.get(item) > 0;
	}
    private void gainItem(String item, int amount) {
        if (items.containsKey(item)) items.put(item, items.get(item) + amount);
    }
    private void gainItem(String item) {
        gainItem(item, 1);
    }
	// h :)
	private String vowels = "AEIOUaeiou";
    private boolean useItem(String item) {
        if (!items.containsKey(item)) return false;
        int count = items.get(item);

        if (count == 0) return false;

        items.put(item, count - 1);
		String prefix = vowels.indexOf(item.charAt(0)) >= 0 ? "n " : " ";
		System.out.println("You used a" + prefix + item);

        return true;
    }
    public void printItems() {
        boolean poor = true;
        System.out.println("You have:");
        for (String i : itemNames) {
            int c = items.get(i);
            if (c > 0) {
                System.out.printf("\t%s x%d", i, c);
                poor = false;
            }
        }
        if (poor) System.out.println("Nothing! You're poor!");
        System.out.println("\nYou also have " + money + "$");
    }

    public void usePotion() {
        if (useItem("Potion")) myPokemon.usePotion();
    }
    public void useSuperPotion() {
        if (useItem("Super Potion")) myPokemon.useSuperPotion();
    }
    public void useHyperPotion() {
        if (useItem("Hyper Potion")) myPokemon.useHyperPotion();
    }
    public void useMaxHeal() {
        if (useItem("Max Heal")) myPokemon.useMaxHeal();
    }
	public void useNormalGem() {
        if (useItem("Normal Gem")) myPokemon.useNormalGem();
    }
    public void useFightingGem() {
        if (useItem("Fighting Gem")) myPokemon.useFightingGem();
    }
    public void useFlyingGem() {
        if (useItem("Flying Gem")) myPokemon.useFlyingGem();
    }
    public void usePoisonGem() {
        if (useItem("Poison Gem")) myPokemon.usePoisonGem();
    }
    public void useGroundGem() {
        if (useItem("Ground Gem")) myPokemon.useGroundGem();
    }
    public void useRockGem() {
        if (useItem("Rock Gem")) myPokemon.useRockGem();
    }
    public void useBugGem() {
        if (useItem("Bug Gem")) myPokemon.useBugGem();
    }
    public void useGhostGem() {
        if (useItem("Ghost Gem")) myPokemon.useGhostGem();
    }
    public void useSteelGem() {
        if (useItem("Steel Gem")) myPokemon.useSteelGem();
    }
    public void useFireGem() {
        if (useItem("Fire Gem")) myPokemon.useFireGem();
    }
    public void useWaterGem() {
        if (useItem("Water Gem")) myPokemon.useWaterGem();
    }
    public void useGrassGem() {
        if (useItem("Grass Gem")) myPokemon.useGrassGem();
    }
    public void useElectricGem() {
        if (useItem("Electric Gem")) myPokemon.useElectricGem();
    }
    public void usePsychicGem() {
        if (useItem("Psychic Gem")) myPokemon.usePsychicGem();
    }
    public void useIceGem() {
        if (useItem("Ice Gem")) myPokemon.useIceGem();
    }
    public void useDragonGem() {
        if (useItem("Dragon Gem")) myPokemon.useDragonGem();
    }
    public void useDarkGem() {
        if (useItem("Dark Gem")) myPokemon.useDarkGem();
    }
    public void useFairyGem() {
        if (useItem("Fairy Gem")) myPokemon.useFairyGem();
    }
    public void useRareCandy() {
        if (useItem("Rare Candy")) myPokemon.useRareCandy();
    }
    public void useAttack() {
        if (useItem("Attack")) myPokemon.useAttack();
    }
    public void useDefense() {
        if (useItem("Defense")) myPokemon.useDefense();
    }
    public void useSpecialAttack() {
        if (useItem("Special Attack")) myPokemon.useSpecialAttack();
    }
    public void useSpecialDefense() {
        if (useItem("Speical Defense")) myPokemon.useSpecialDefense();
    }
    public void useSpeed() {
        if (useItem("Speed")) myPokemon.useSpeed();
    }
    public void useHealthFeather() {
        if (useItem("Health Feather")) myPokemon.useHealthFeather();
    }
    public void useMuscleFeather() {
        if (useItem("Muscle Feather")) myPokemon.useMuscleFeather();
    }
    public void useResistFeather() {
        if (useItem("Resist Feather")) myPokemon.useResistFeather();
    }
    public void useGenuisFeather() {
        if (useItem("Genuis Feather")) myPokemon.useGenuisFeather();
    }
    public void useCleverFeather() {
        if (useItem("Clever Feather")) myPokemon.useCleverFeather();
    }
    public void useSwiftFeather() {
        if (useItem("Swift Feather")) myPokemon.useSwiftFeather();
    }
    public void useHPUp() {
        if (useItem("HP Up")) myPokemon.useHPUp();
    }
    public void useProtein() {
        if (useItem("Protein")) myPokemon.useProtein();
    }
    public void useIron() {
        if (useItem("Iron")) myPokemon.useIron();
    }
    public void useCalcium() {
        if (useItem("Calcium")) myPokemon.useCalcium();
    }
    public void useZinc() {
        if (useItem("Zinc")) myPokemon.useZinc();
    }
    public void useCarbos() {
        if (useItem("Carbos")) myPokemon.useCarbos();
    }
}

class Pokemon {
    public int totalEV = 0;
    public int level = 10;
    public int xp = 0;
    public int xpUntil;
    public double hpEV;
    public double atkEV;
    public double defEV;
    public double spAtkEV;
    public double spDefEV;
    public double spdEV;
    public double baseHp;
    public double maxHp;
    public double baseDef;
    public double baseAtk;
    public double baseSpAtk;
    public double baseSpDef;
    public double baseSpd;
    public double hpIV;
    public double atkIV;
    public double defIV;
    public double spdIV;
    public double spAtkIV;
    public double spDefIV;
    public double hp;
    public double def;
    public double atk;
    public double spd;
    public double spAtk;
    public double spDef;
    public String type1 = "";
    public String type2 = "";
    public String name = "";
    public String gemBoostType = "";
    public String Nature = "";
    public boolean shiny;
    ArrayList<String> xItemBuffs = new ArrayList<String>();
    public Pokemon(double h, double d, double a, double sA, double sD, double sp, String t1, String t2, String n) {
        baseHp = h;
        maxHp = h;
        baseDef = d;
        baseAtk = a;
        baseSpAtk = sA;
        baseSpDef = sD;
        baseSpd = sp;
        type1 = t1;
        type2 = t2.equals("NA") ? t1 : t2;
        name = n;
    }

    public Pokemon clone() {
        return new Pokemon(baseHp, baseDef, baseAtk, baseSpAtk, baseSpDef, baseSpd, type1, type2, name);
    }

    private static HashMap<String, HashMap<String, Double>> types = new HashMap<String, HashMap<String, Double>>();
    static {
        HashMap<String, Double> Normal = new HashMap<String, Double>();
        Normal.put("NORMAL", 1.0);
        Normal.put("FIGHTING", 1.0);
        Normal.put("FLYING", 1.0);
        Normal.put("POISON", 1.0);
        Normal.put("GROUND", 1.0);
        Normal.put("ROCK", 0.5);
        Normal.put("BUG", 1.0);
        Normal.put("GHOST", 0.0);
        Normal.put("STEEL", 0.5);
        Normal.put("FIRE", 1.0);
        Normal.put("WATER", 1.0);
        Normal.put("GRASS", 1.0);
        Normal.put("ELECTRIC", 1.0);
        Normal.put("PSYCHIC", 1.0);
        Normal.put("ICE", 1.0);
        Normal.put("DRAGON", 1.0);
        Normal.put("DARK", 1.0);
        Normal.put("FAIRY", 1.0);
        types.put("NORMAL", Normal);
        HashMap<String, Double> Fighting = new HashMap<String, Double>();
        Fighting.put("NORMAL", 2.0);
        Fighting.put("FIGHTING", 1.0);
        Fighting.put("FLYING", 0.5);
        Fighting.put("POISON", 0.5);
        Fighting.put("GROUND", 1.0);
        Fighting.put("ROCK", 2.0);
        Fighting.put("BUG", 0.5);
        Fighting.put("GHOST", 0.0);
        Fighting.put("STEEL", 2.0);
        Fighting.put("FIRE", 1.0);
        Fighting.put("WATER", 1.0);
        Fighting.put("GRASS", 1.0);
        Fighting.put("ELECTRIC", 1.0);
        Fighting.put("PSYCHIC", 0.5);
        Fighting.put("ICE", 2.0);
        Fighting.put("DRAGON", 1.0);
        Fighting.put("DARK", 2.0);
        Fighting.put("FAIRY", 0.5);
        types.put("FIGHTING", Fighting);
        HashMap<String, Double> Flying = new HashMap<String, Double>();
        Flying.put("NORMAL", 1.0);
        Flying.put("FIGHTING", 2.0);
        Flying.put("FLYING", 1.0);
        Flying.put("POISON", 1.0);
        Flying.put("GROUND", 1.0);
        Flying.put("ROCK", 0.5);
        Flying.put("BUG", 2.0);
        Flying.put("GHOST", 1.0);
        Flying.put("STEEL", 0.5);
        Flying.put("FIRE", 1.0);
        Flying.put("WATER", 1.0);
        Flying.put("GRASS", 2.0);
        Flying.put("ELECTRIC", 0.5);
        Flying.put("PSYCHIC", 1.0);
        Flying.put("ICE", 1.0);
        Flying.put("DRAGON", 1.0);
        Flying.put("DARK", 1.0);
        Flying.put("FAIRY", 1.0);
        types.put("FLYING", Flying);
        HashMap<String, Double> Poison = new HashMap<String, Double>();
        Poison.put("NORMAL", 1.0);
        Poison.put("FIGHTING", 1.0);
        Poison.put("FLYING", 1.0);
        Poison.put("POISON", 0.5);
        Poison.put("GROUND", 0.5);
        Poison.put("ROCK", 0.5);
        Poison.put("BUG", 1.0);
        Poison.put("GHOST", 0.5);
        Poison.put("STEEL", 0.0);
        Poison.put("FIRE", 1.0);
        Poison.put("WATER", 1.0);
        Poison.put("GRASS", 2.0);
        Poison.put("ELECTRIC", 1.0);
        Poison.put("PSYCHIC", 1.0);
        Poison.put("ICE", 1.0);
        Poison.put("DRAGON", 1.0);
        Poison.put("DARK", 1.0);
        Poison.put("FAIRY", 2.0);
        types.put("POISON", Poison);
        HashMap<String, Double> Ground = new HashMap<String, Double>();
        Ground.put("NORMAL", 1.0);
        Ground.put("FIGHTING", 1.0);
        Ground.put("FLYING", 0.0);
        Ground.put("POISON", 2.0);
        Ground.put("GROUND", 1.0);
        Ground.put("ROCK", 2.0);
        Ground.put("BUG", 0.5);
        Ground.put("GHOST", 1.0);
        Ground.put("STEEL", 2.0);
        Ground.put("FIRE", 2.0);
        Ground.put("WATER", 1.0);
        Ground.put("GRASS", 0.5);
        Ground.put("ELECTRIC", 2.0);
        Ground.put("PSYCHIC", 1.0);
        Ground.put("ICE", 1.0);
        Ground.put("DRAGON", 1.0);
        Ground.put("DARK", 1.0);
        Ground.put("FAIRY", 1.0);
        types.put("GROUND", Ground);
        HashMap<String, Double> Rock = new HashMap<String, Double>();
        Rock.put("NORMAL", 1.0);
        Rock.put("FIGHTING", 0.5);
        Rock.put("FLYING", 2.0);
        Rock.put("POISON", 1.0);
        Rock.put("GROUND", 0.5);
        Rock.put("ROCK", 1.0);
        Rock.put("BUG", 2.0);
        Rock.put("GHOST", 1.0);
        Rock.put("STEEL", 0.5);
        Rock.put("FIRE", 2.0);
        Rock.put("WATER", 1.0);
        Rock.put("GRASS", 1.0);
        Rock.put("ELECTRIC", 1.0);
        Rock.put("PSYCHIC", 1.0);
        Rock.put("ICE", 2.0);
        Rock.put("DRAGON", 1.0);
        Rock.put("DARK", 1.0);
        Rock.put("FAIRY", 1.0);
        types.put("ROCK", Rock);
        HashMap<String, Double> Bug = new HashMap<String, Double>();
        Bug.put("NORMAL", 1.0);
        Bug.put("FIGHTING", 0.5);
        Bug.put("FLYING", 0.5);
        Bug.put("POISON", 0.5);
        Bug.put("GROUND", 1.0);
        Bug.put("ROCK", 1.0);
        Bug.put("BUG", 1.0);
        Bug.put("GHOST", 0.5);
        Bug.put("STEEL", 0.5);
        Bug.put("FIRE", 0.5);
        Bug.put("WATER", 1.0);
        Bug.put("GRASS", 2.0);
        Bug.put("ELECTRIC", 1.0);
        Bug.put("PSYCHIC", 2.0);
        Bug.put("ICE", 1.0);
        Bug.put("DRAGON", 1.0);
        Bug.put("DARK", 2.0);
        Bug.put("FAIRY", 0.5);
        types.put("BUG", Bug);
        HashMap<String, Double> Ghost = new HashMap<String, Double>();
        Ghost.put("NORMAL", 0.0);
        Ghost.put("FIGHTING", 1.0);
        Ghost.put("FLYING", 1.0);
        Ghost.put("POISON", 1.0);
        Ghost.put("GROUND", 1.0);
        Ghost.put("ROCK", 1.0);
        Ghost.put("BUG", 1.0);
        Ghost.put("GHOST", 2.0);
        Ghost.put("STEEL", 1.0);
        Ghost.put("FIRE", 1.0);
        Ghost.put("WATER", 1.0);
        Ghost.put("GRASS", 1.0);
        Ghost.put("ELECTRIC", 1.0);
        Ghost.put("PSYCHIC", 2.0);
        Ghost.put("ICE", 1.0);
        Ghost.put("DRAGON", 1.0);
        Ghost.put("DARK", 0.5);
        Ghost.put("FAIRY", 1.0);
        types.put("GHOST", Ghost);
        HashMap<String, Double> Steel = new HashMap<String, Double>();
        Steel.put("NORMAL", 1.0);
        Steel.put("FIGHTING", 1.0);
        Steel.put("FLYING", 1.0);
        Steel.put("POISON", 1.0);
        Steel.put("GROUND", 1.0);
        Steel.put("ROCK", 2.0);
        Steel.put("BUG", 1.0);
        Steel.put("GHOST", 1.0);
        Steel.put("STEEL", 0.5);
        Steel.put("FIRE", 0.5);
        Steel.put("WATER", 0.5);
        Steel.put("GRASS", 1.0);
        Steel.put("ELECTRIC", 0.5);
        Steel.put("PSYCHIC", 1.0);
        Steel.put("ICE", 2.0);
        Steel.put("DRAGON", 1.0);
        Steel.put("DARK", 1.0);
        Steel.put("FAIRY", 2.0);
        types.put("STEEL", Steel);
        HashMap<String, Double> Fire = new HashMap<String, Double>();
        Fire.put("NORMAL", 1.0);
        Fire.put("FIGHTING", 1.0);
        Fire.put("FLYING", 1.0);
        Fire.put("POISON", 1.0);
        Fire.put("GROUND", 1.0);
        Fire.put("ROCK", 0.5);
        Fire.put("BUG", 2.0);
        Fire.put("GHOST", 1.0);
        Fire.put("STEEL", 2.0);
        Fire.put("FIRE", 0.5);
        Fire.put("WATER", 0.5);
        Fire.put("GRASS", 2.0);
        Fire.put("ELECTRIC", 1.0);
        Fire.put("PSYCHIC", 1.0);
        Fire.put("ICE", 2.0);
        Fire.put("DRAGON", 0.5);
        Fire.put("DARK", 1.0);
        Fire.put("FAIRY", 1.0);
        types.put("FIRE", Fire);
        HashMap<String, Double> Water = new HashMap<String, Double>();
        Water.put("NORMAL", 1.0);
        Water.put("FIGHTING", 1.0);
        Water.put("FLYING", 1.0);
        Water.put("POISON", 1.0);
        Water.put("GROUND", 2.0);
        Water.put("ROCK", 2.0);
        Water.put("BUG", 1.0);
        Water.put("GHOST", 1.0);
        Water.put("STEEL", 1.0);
        Water.put("FIRE", 2.0);
        Water.put("WATER", 0.5);
        Water.put("GRASS", 0.5);
        Water.put("ELECTRIC", 1.0);
        Water.put("PSYCHIC", 1.0);
        Water.put("ICE", 1.0);
        Water.put("DRAGON", 0.5);
        Water.put("DARK", 1.0);
        Water.put("FAIRY", 1.0);
        types.put("WATER", Water);
        HashMap<String, Double> Grass = new HashMap<String, Double>();
        Grass.put("NORMAL", 1.0);
        Grass.put("FIGHTING", 1.0);
        Grass.put("FLYING", 0.5);
        Grass.put("POISON", 0.5);
        Grass.put("GROUND", 2.0);
        Grass.put("ROCK", 2.0);
        Grass.put("BUG", 0.5);
        Grass.put("GHOST", 1.0);
        Grass.put("STEEL", 0.5);
        Grass.put("FIRE", 0.5);
        Grass.put("WATER", 2.0);
        Grass.put("GRASS", 0.5);
        Grass.put("ELECTRIC", 1.0);
        Grass.put("PSYCHIC", 1.0);
        Grass.put("ICE", 1.0);
        Grass.put("DRAGON", 0.5);
        Grass.put("DARK", 1.0);
        Grass.put("FAIRY", 1.0);
        types.put("GRASS", Grass);
        HashMap<String, Double> Electric = new HashMap<String, Double>();
        Electric.put("NORMAL", 1.0);
        Electric.put("FIGHTING", 1.0);
        Electric.put("FLYING", 2.0);
        Electric.put("POISON", 1.0);
        Electric.put("GROUND", 0.0);
        Electric.put("ROCK", 1.0);
        Electric.put("BUG", 1.0);
        Electric.put("GHOST", 1.0);
        Electric.put("STEEL", 1.0);
        Electric.put("FIRE", 1.0);
        Electric.put("WATER", 2.0);
        Electric.put("GRASS", 0.5);
        Electric.put("ELECTRIC", 0.5);
        Electric.put("PSYCHIC", 1.0);
        Electric.put("ICE", 1.0);
        Electric.put("DRAGON", 0.5);
        Electric.put("DARK", 1.0);
        Electric.put("FAIRY", 1.0);
        types.put("ELECTRIC", Electric);
        HashMap<String, Double> Psychic = new HashMap<String, Double>();
        Psychic.put("NORMAL", 1.0);
        Psychic.put("FIGHTING", 2.0);
        Psychic.put("FLYING", 1.0);
        Psychic.put("POISON", 2.0);
        Psychic.put("GROUND", 1.0);
        Psychic.put("ROCK", 1.0);
        Psychic.put("BUG", 1.0);
        Psychic.put("GHOST", 1.0);
        Psychic.put("STEEL", 0.5);
        Psychic.put("FIRE", 1.0);
        Psychic.put("WATER", 1.0);
        Psychic.put("GRASS", 1.0);
        Psychic.put("ELECTRIC", 1.0);
        Psychic.put("PSYCHIC", 0.5);
        Psychic.put("ICE", 1.0);
        Psychic.put("DRAGON", 1.0);
        Psychic.put("DARK", 0.0);
        Psychic.put("FAIRY", 1.0);
        types.put("PSYCHIC", Psychic);
        HashMap<String, Double> Ice = new HashMap<String, Double>();
        Ice.put("NORMAL", 1.0);
        Ice.put("FIGHTING", 1.0);
        Ice.put("FLYING", 2.0);
        Ice.put("POISON", 1.0);
        Ice.put("GROUND", 2.0);
        Ice.put("ROCK", 1.0);
        Ice.put("BUG", 1.0);
        Ice.put("GHOST", 1.0);
        Ice.put("STEEL", 0.5);
        Ice.put("FIRE", 0.5);
        Ice.put("WATER", 0.5);
        Ice.put("GRASS", 2.0);
        Ice.put("ELECTRIC", 1.0);
        Ice.put("PSYCHIC", 1.0);
        Ice.put("ICE", 0.5);
        Ice.put("DRAGON", 2.0);
        Ice.put("DARK", 1.0);
        Ice.put("FAIRY", 1.0);
        types.put("ICE", Ice);
        HashMap<String, Double> Dragon = new HashMap<String, Double>();
        Dragon.put("NORMAL", 1.0);
        Dragon.put("FIGHTING", 1.0);
        Dragon.put("FLYING", 1.0);
        Dragon.put("POISON", 1.0);
        Dragon.put("GROUND", 1.0);
        Dragon.put("ROCK", 1.0);
        Dragon.put("BUG", 1.0);
        Dragon.put("GHOST", 1.0);
        Dragon.put("STEEL", 0.5);
        Dragon.put("FIRE", 1.0);
        Dragon.put("WATER", 1.0);
        Dragon.put("GRASS", 1.0);
        Dragon.put("ELECTRIC", 1.0);
        Dragon.put("PSYCHIC", 1.0);
        Dragon.put("ICE", 1.0);
        Dragon.put("DRAGON", 2.0);
        Dragon.put("DARK", 1.0);
        Dragon.put("FAIRY", 0.0);
        types.put("DRAGON", Dragon);
        HashMap<String, Double> Dark = new HashMap<String, Double>();
        Dark.put("NORMAL", 1.0);
        Dark.put("FIGHTING", 0.5);
        Dark.put("FLYING", 1.0);
        Dark.put("POISON", 1.0);
        Dark.put("GROUND", 1.0);
        Dark.put("ROCK", 1.0);
        Dark.put("BUG", 1.0);
        Dark.put("GHOST", 2.0);
        Dark.put("STEEL", 1.0);
        Dark.put("FIRE", 1.0);
        Dark.put("WATER", 1.0);
        Dark.put("GRASS", 1.0);
        Dark.put("ELECTRIC", 1.0);
        Dark.put("PSYCHIC", 2.0);
        Dark.put("ICE", 1.0);
        Dark.put("DRAGON", 1.0);
        Dark.put("DARK", 0.5);
        Dark.put("FAIRY", 0.5);
        types.put("DARK", Dark);
        HashMap<String, Double> Fairy = new HashMap<String, Double>();
        Fairy.put("NORMAL", 1.0);
        Fairy.put("FIGHTING", 2.0);
        Fairy.put("FLYING", 1.0);
        Fairy.put("POISON", 0.5);
        Fairy.put("GROUND", 1.0);
        Fairy.put("ROCK", 1.0);
        Fairy.put("BUG", 1.0);
        Fairy.put("GHOST", 1.0);
        Fairy.put("STEEL", 0.5);
        Fairy.put("FIRE", 0.5);
        Fairy.put("WATER", 1.0);
        Fairy.put("GRASS", 1.0);
        Fairy.put("ELECTRIC", 1.0);
        Fairy.put("PSYCHIC", 1.0);
        Fairy.put("ICE", 1.0);
        Fairy.put("DRAGON", 2.0);
        Fairy.put("DARK", 2.0);
        Fairy.put("FAIRY", 1.0);
        types.put("FAIRY", Fairy);
    }
    public void attack(Pokemon p, boolean useSpAtk, int atkType) {
        String thisType = atkType == 1 ? type1 : type2;

        double modifier = types.get(thisType).get(p.type1) * types.get(thisType).get(p.type2);
        String effectiveness = "normally effective";
        if (modifier == 0) effectiveness = "not affected";
        else if (modifier < 1) effectiveness = "not very effective";
        else if (modifier > 1) effectiveness = "super effective";

        double critical = (Math.random() < 0.0625 ? 1.5 : 1);
        double random = Math.random() / 4 + 0.75;
        double atkODef = (useSpAtk ? spAtk / p.spDef : atk / p.def);
        double damage = Math.rint(2 * Math.rint(((((2.0 * /*level*/ 1.0) / 5.0 + 2.0) * /*power*/ 1.0 * atkODef) / 50.0 + 2.0))* critical * random * modifier);
        if (gemBoostType.equals(thisType)) damage *= 1.35;

        System.out.printf("%s used a %s attack.%n", name, thisType);
        if (critical > 1) System.out.println("Critical Hit!");
        if (modifier != 1) {
            if (modifier == 0) System.out.println(p.name + " was " + effectiveness + ".");
            else System.out.println("It was " + effectiveness + '.');
        }
        p.hp -= damage;
        if (p.hp < 0) p.hp = 0;
        System.out.printf("It did %.0f damage. %s has %.0f/%.0f health", damage, p.name, p.hp, p.maxHp);
        gemBoostType = "";
        System.out.println();
    }

    private void _heal(double max) {
        double amount = Math.min(max, maxHp - hp);
        hp += amount;
        System.out.println(name + " healed for " + amount + " hp.");
    }
    public void usePotion() {
        _heal(20);
    }
    public void useSuperPotion() {
        _heal(60);
    }
    public void useHyperPotion() {
        _heal(120);
    }
    public void useMaxHeal() {
        _heal(maxHp);
        System.out.println(name + " healed to full health.");
    }
    private void useGem(String type) {
        System.out.println("You used a " + type + " Gem.");
        if (!(type1.equals(type)) && !(type2.equals(type))) {
            System.out.println("Your pokemon does not have that type. The gem has been wasted.");
        }
        else {
            System.out.println("Your next attack using " + type + " has been boosted for one turn.");
            gemBoostType = type;
        }
    }
    public void useNormalGem() {
        useGem("Normal");
    }
    public void useFightingGem() {
        useGem("Fighting");
    }
    public void useFlyingGem() {
        useGem("Flying");
    }
    public void usePoisonGem() {
        useGem("Poison");
    }
    public void useGroundGem() {
        useGem("Ground");
    }
    public void useRockGem() {
        useGem("Rock");
    }
    public void useBugGem() {
        useGem("Bug");
    }
    public void useGhostGem() {
        useGem("Ghost");
    }
    public void useSteelGem() {
        useGem("Steel");
    }
    public void useFireGem() {
        useGem("Fire");
    }
    public void useWaterGem() {
        useGem("Water");
    }
    public void useGrassGem() {
        useGem("Grass");
    }
    public void useElectricGem() {
        useGem("Electric");
    }
    public void usePsychicGem() {
        useGem("Psychic");
    }
    public void useIceGem() {
        useGem("Ice");
    }
    public void useDragonGem() {
        useGem("Dragon");
    }
    public void useDarkGem() {
        useGem("Dark");
    }
    public void useFairyGem() {
        useGem("Fairy");
    }
    private void useXItem(String type) {
        System.out.println("You used an X " + type + ". Your " + type + " has been boosted for the battle.");
        xItemBuffs.add(type);
        switch (type) {
            case "Attack":
                atk *= 1.3;
                break;
            case "Defense":
                def *= 1.3;
                break;
            case "Special Attack":
                spAtk *= 1.3;
                break;
            case "Special Defense":
                spDef *= 1.3;
                break;
            case "Speed":
                spDef *= 1.3;
                break;
        }
    }
    public void useAttack() {
        useXItem("Attack");
    }
    public void useDefense() {
        useXItem("Defense");
    }
    public void useSpecialAttack() {
        useXItem("Special Attack");
    }
    public void useSpecialDefense() {
        useXItem("Special Defense");
    }
    public void useSpeed() {
        useXItem("Speed");
    }
    private void useFeather(String type) {
        System.out.println("You used a " + type + ". Your pokemon's EV has gone up.");
    }
    // double temp = Math.min(10, 255 - somethingEV);
    // somethingEV += temp;
    // totalEV += temp;
    public void useHealthFeather() {
        useFeather("Health Feather");
        double temp = hpEV;
        hpEV += 10;
        if (hpEV > 255) {
            System.out.println("Your pokemon's Health EV won't go any higher.");
            hpEV = 255;
        }
        totalEV += (hpEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useMuscleFeather() {
        useFeather("Muscle Feather");
        double temp = atkEV;
        atkEV += 10;
        if (atkEV > 255) {
            System.out.println("Your pokemon's Attack EV won't go any higher.");
            atkEV = 255;
        }
        totalEV += (atkEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useResistFeather() {
        useFeather("Resist Feather");
        double temp = defEV;
        defEV += 10;
        if (defEV > 255) {
            System.out.println("Your pokemon's Defense EV won't go any higher.");
            defEV = 255;
        }
        totalEV += (defEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useGenuisFeather() {
        useFeather("Genuis Feather");
        double temp = spAtkEV;
        spAtkEV += 10;
        if (spAtkEV > 255) {
            System.out.println("Your pokemon's Special Attack EV won't go any higher.");
            spAtkEV = 255;
        }
        totalEV += (spAtkEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useCleverFeather() {
        useFeather("Clever Feather");
        double temp = spDefEV;
        spDefEV += 10;
        if (spDefEV > 255) {
            System.out.println("Your pokemon's Special Defense EV won't go any higher.");
            spDefEV = 255;
        }
        totalEV += (spDefEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useSwiftFeather() {
        useFeather("Swift Feather");
        double temp = spdEV;
        spdEV += 10;
        if (spdEV > 255) {
            System.out.println("Your pokemon's Speed EV won't go any higher.");
            spdEV = 255;
        }
        totalEV += (spdEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useRareCandy() {
        System.out.println(name + " leveled up.");
        onLevelUp();
        xp = 0;
    }
    private void useMedicine(String type) {
        System.out.println("You used a " + type + ". Your pokemon's EV has gone up.");
    }
    public void useHPUp() {
        useMedicine("HP Up");
        double temp = hpEV;
        hpEV += 10;
        if (hpEV > 255) {
            System.out.println("Your pokemon's Health EV won't go any higher.");
            hpEV = 255;
        }
        totalEV += (hpEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        }
    }
    public void useProtein() {
        useMedicine("Protein");
        double temp = atkEV;
        atkEV += 10;
        if (atkEV > 255) {
            System.out.println("Your pokemon's Attack EV won't go any higher.");
            atkEV = 255;
        }
        totalEV += (atkEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useIron() {
        useFeather("Iron");
        double temp = defEV;
        defEV += 10;
        if (defEV > 255) {
            System.out.println("Your pokemon's Defense EV won't go any higher.");
            defEV = 255;
        }
        totalEV += (defEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useCalcium() {
        useMedicine("Calcium");
        double temp = spAtkEV;
        spAtkEV += 10;
        if (spAtkEV > 255) {
            System.out.println("Your pokemon's Special Attack EV won't go any higher.");
            spAtkEV = 255;
        }
        totalEV += (spAtkEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useZinc() {
        useMedicine("Zinc");
        double temp = spDefEV;
        spDefEV += 10;
        if (spDefEV > 255) {
            System.out.println("Your pokemon's Special Defense EV won't go any higher.");
            spDefEV = 255;
        }
        totalEV += (spDefEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void useCarbos() {
        useMedicine("Carbos");
        double temp = spdEV;
        spdEV += 10;
        if (spdEV > 255) {
            System.out.println("Your pokemon's Speed EV won't go any higher.");
            spdEV = 255;
        }
        totalEV += (spdEV - temp);
        if (totalEV > 510) {
            System.out.println("Your pokemon has reached a the cap of 510 EVs. It will no longer gain EVs.");
        } 
    }
    public void onEndBattle() {
        for (int i = 0; i < xItemBuffs.size(); i++) {
            switch (xItemBuffs.get(i)) {
                case "Attack":
                    atk /= 1.3;
                    break;
                case "Defense":
                    def /= 1.3;
                    break;
                case "Special Attack":
                    spAtk /= 1.3;
                    break;
                case "Special Defense":
                    spDef /= 1.3;
                    break;
                case "Speed":
                    spDef /= 1.3;
                    break;
            }
        }
    }
    private static final String[] Natures = new String[]{"Hardy", "Lonely", "Brave", "Adamant", "Naughty", "Bold", "Docile", "Relaxed", "Impish", "Lax", "Timid", "Hasty", "Serious", "Jolly", "Naive", "Modest", "Mild", "Quiet", "Bashful", "Rash", "Calm", "Gentle", "Sassy", "Careful", "Quirky"};
    public void getNature() {
        Nature = Natures[(int)(Math.random()*Natures.length)];
        useNature();
    }
    public void onKill() {
        if (totalEV < 510) gainEV();
        gainXp();
        if (xp >= xpUntil) {
            levelUp();
        }
    }
    public void gainXp() {
        // 0-563
        int xpGain = (int)(level * (Math.random() * 564) / 7);  
        xp += xpGain;
        System.out.println(name + " gained " + xpGain + " xp.");
    }
    public void onLevelUp() {
        levelUp();
        statsEV();
    }
    public void levelUp() {
        xpUntil = (int)(4 * Math.pow(level, 3) / 5.0);
        xp -= xpUntil;
        level++;
        System.out.println("\n" + name +  " leveled up.");
    }
    public void gainEV() {
        int randNum = (int)(Math.random()*6);
        switch (randNum) {
            case 0:
                if (atkEV < 100) {
                    atkEV++;
                    totalEV++;
                }
                break;
            case 1:
                if (defEV < 100) {
                    defEV++;
                    totalEV++;
                }
                break;
            case 2:
                if (spdEV < 100) {
                    spdEV++;
                    totalEV++;
                }
                break;
            case 3:
                if (spAtkEV < 100) {
                    spAtkEV++;
                    totalEV++;
                }
                break;
            case 4:
                if (spDefEV < 100) {
                    spDefEV++;
                    totalEV++;
                }
                break;
            case 5:
                if (hpEV < 100) {
                    hpEV++;
                    totalEV++;
                }
                break;
        }
    }
    public void useNature() {
        switch (Nature) {
            case "Lonely":
                atk *= 1.1;
                def *= 0.9;
                break;
            case "Brave":
                atk *= 1.1;
                spd *= 0.9;
                break;
            case "Adamant":
                atk *= 1.1;
                spAtk *= 0.9;
                break;
            case "Naughty":
                atk *= 1.1;
                spDef *= 0.9;
                break;
            case "Bold":
                def *= 1.1;
                atk *= 0.9;
                break;
            case "Relaxed":
                def *= 1.1;
                spd *= 0.9;
                break;
            case "Impish":
                def *= 1.1;
                spAtk *= 0.9;
                break;
            case "Lax":
                def *= 1.1;
                spDef *= 0.9;
                break;
            case "Timid":
                spd *= 1.1;
                atk *= 0.9;
                break;
            case "Hasty":
                spd *= 1.1;
                def *= 0.9;
                break;
            case "Jolly":
                spd *= 1.1;
                spAtk *= 0.9;
                break;
            case "Naive":
                spd *= 1.1;
                spDef *= 0.9;
                break;
            case "Modest":
                spAtk *= 1.1;
                atk *= 0.9;
                break;
            case "Mild":
                spAtk *= 1.1;
                def *= 0.9;
                break;
            case "Quiet":
                spAtk *= 1.1;
                spd *= 0.9;
                break;
            case "Rash":
                spAtk *= 1.1;
                spDef *= 0.9;
                break;
            case "Calm":
                spDef *= 1.1;
                atk *= 0.9;
                break;
            case "Gentle":
                spDef *= 1.1;
                def *= 0.9;
                break;
            case "Sassy":
                spDef *= 1.1;
                spd *= 0.9;
                break;
            case "Careful":
                spDef *= 1.1;
                spAtk *= 0.9;
                break;
        }
    }
    public void unUseNature() {
        switch (Nature) {
            case "Lonely":
                atk /= 1.1;
                def /= 0.9;
                break;
            case "Brave":
                atk /= 1.1;
                spd /= 0.9;
                break;
            case "Adamant":
                atk /= 1.1;
                spAtk /= 0.9;
                break;
            case "Naughty":
                atk /= 1.1;
                spDef /= 0.9;
                break;
            case "Bold":
                def /= 1.1;
                atk /= 0.9;
                break;
            case "Relaxed":
                def /= 1.1;
                spd /= 0.9;
                break;
            case "Impish":
                def /= 1.1;
                spAtk /= 0.9;
                break;
            case "Lax":
                def /= 1.1;
                spDef /= 0.9;
                break;
            case "Timid":
                spd /= 1.1;
                atk /= 0.9;
                break;
            case "Hasty":
                spd /= 1.1;
                def /= 0.9;
                break;
            case "Jolly":
                spd /= 1.1;
                spAtk /= 0.9;
                break;
            case "Naive":
                spd /= 1.1;
                spDef /= 0.9;
                break;
            case "Modest":
                spAtk /= 1.1;
                atk /= 0.9;
                break;
            case "Mild":
                spAtk /= 1.1;
                def /= 0.9;
                break;
            case "Quiet":
                spAtk /= 1.1;
                spd /= 0.9;
                break;
            case "Rash":
                spAtk /= 1.1;
                spDef /= 0.9;
                break;
            case "Calm":
                spDef /= 1.1;
                atk /= 0.9;
                break;
            case "Gentle":
                spDef /= 1.1;
                def /= 0.9;
                break;
            case "Sassy":
                spDef /= 1.1;
                spd /= 0.9;
                break;
            case "Careful":
                spDef /= 1.1;
                spAtk /= 0.9;
                break;
        }
    }
    public void statsIV() {
        atkIV = (int)(Math.random() * 16);
        defIV = (int)(Math.random() * 16);
        spdIV = (int)(Math.random() * 16);
        spAtkIV = (int)(Math.random() * 16);
        spDefIV = (int)(Math.random() * 16);
        hpIV = 0;
        if (((int)atkIV & 1) == 1) hpIV += 8;
        if (((int)defIV & 1) == 1) hpIV += 4;
        if (((int)spdIV & 1) == 1) hpIV += 2;
        if (((int)spAtkIV & 1) == 1) hpIV += 1;
        if (((int)spDefIV & 1) == 1) hpIV += 1;
        hp = (((2 * baseHp + hpIV) * level) / 100) + level + 10;
        def = (((2 * baseDef + defIV) * level) / 100) + 5;
        atk = (((2 * baseAtk + atkIV) * level) / 100) + 5;
        spd = (((2 * baseSpd + spdIV) * level) / 100) + 5;
        spAtk = (((2 * baseSpAtk + spAtkIV) * level) / 100) + 5;
        spDef = (((2 * baseSpDef + spDefIV) * level) / 100) + 5;
        maxHp = hp;
        if (defIV == 10 && spdIV == 10 && spAtkIV == 10 && spDefIV == 10 && (atkIV == 2 || atkIV == 3 || atkIV == 6 || atkIV == 7|| atkIV == 10 || atkIV == 11 || atkIV == 14 || atkIV == 15)) {
            System.out.println("Wow, you got a shiny pokemon!!!");
            shiny = true;
        }
    }
    public void statsEV() {
        // I'm stalling this because I don't wanna do this :c
        unUseNature();
        int oldHp = (int)hp;
        int temp = (int)(maxHp/oldHp);
        hp = ((2 * baseHp + hpIV + (hpEV / 4) * level) / 100) + level + 10;
        atk = (((2 * baseAtk + atkIV + (atkEV / 4) * level) / 100) + 5);
        def = (((2 * baseDef + defIV + (defEV / 4) * level) / 100) + 5);
        spd = (((2 * baseSpd + spdIV + (spdEV / 4) * level) / 100) + 5);
        spAtk = (((2 * baseSpAtk + spAtkIV + (spAtkEV / 4) * level) / 100) + 5);
        spDef = (((2 * baseSpDef + spDefIV + (spDefEV / 4) * level) / 100) + 5);
        maxHp = (int)(hp * temp);
        useNature();
    }
    public String toString() {
        String isShiny = shiny ? "Yes" : "No";
        return String.format("%s has %.0f/%.0f health.\nAttack: %.0f\tSpecialAttack: %.0f\nDefense: %.0f\tSpecialDefense: %.0f\nType: %s\tType2: %s\nSpeed: %.0f\nNature: %s\nShiny: %s\nLevel: %d\nXP: %d/%d", name, hp, maxHp, atk, spAtk, def, spDef, type1, type2, spd, Nature, isShiny, level, xp, xpUntil);
    }
    public static Pokemon getRandPokemon() {
        Pokemon poke = allPokemon[(int)(Math.random() * allPokemon.length)].clone();
        poke.statsIV();
        poke.xp = 0;
        poke.level = 10;
        poke.getNature();
        poke.maxHp = poke.hp;
        return poke;
    }
    public static Pokemon[] allPokemon = { new Bulbasaur(), new Ivysaur(), new Venusaur(), new VenusaurMega(), new Charmander(), new Charmeleon(), new Charizard(), new CharizardX(), new CharizardY(), new Squirtle(), new Wartortle(), new Blastoise(), new BlastoiseMega(), new Caterpie(), new Metapod(), new Butterfree(), new Weedle(), new Kakuna(), new Beedrill(), new BeedrillMega(), new Pidgey(), new Pidgeotto(), new Pidgeot(), new PidgeotMega(), new Rattata(), new RattataAlolan(), new Raticate(), new RaticateAlolan(), new Spearow(), new Fearow(), new Ekans(), new Arbok(), new Pikachu(), new PikachuPartner(), new Raichu(), new RaichuAlolan(), new Sandshrew(), new SandshrewAlolan(), new Sandslash(), new SandslashAlolan(), new NidoranM(), new Nidorina(), new Nidoqueen(), new NidoranF(), new Nidorino(), new Nidoking(), new Clefairy(), new Clefable(), new Vulpix(), new VulpixAlolan(), new Ninetales(), new NinetalesAlolan(), new Jigglypuff(), new Wigglytuff(), new Zubat(), new Golbat(), new Oddish(), new Gloom(), new Vileplume(), new Paras(), new Parasect(), new Venonat(), new Venomoth(), new Diglett(), new DiglettAlolan(), new Dugtrio(), new DugtrioAlolan(), new Meowth(), new MeowthAlolan(), new MeowthGalarian(), new Persian(), new PersianAlolan(), new Psyduck(), new Golduck(), new Mankey(), new Primeape(), new Growlithe(), new GrowlitheHisuian(), new Arcanine(), new ArcanineHisuian(), new Poliwag(), new Poliwhirl(), new Poliwrath(), new Abra(), new Kadabra(), new Alakazam(), new AlakazamMega(), new Machop(), new Machoke(), new Machamp(), new Bellsprout(), new Weepinbell(), new Victreebel(), new Tentacool(), new Tentacruel(), new Geodude(), new GeodudeAlolan(), new Graveler(), new GravelerAlolan(), new Golem(), new GolemAlolan(), new Ponyta(), new PonytaGalarian(), new Rapidash(), new RapidashGalarian(), new Slowpoke(), new SlowpokeGalarian(), new Slowbro(), new SlowbroMega(), new SlowbroGalarian(), new Magnemite(), new Magneton(), new Farfetchd(), new FarfetchdGalarian(), new Doduo(), new Dodrio(), new Seel(), new Dewgong(), new Grimer(), new GrimerAlolan(), new Muk(), new MukAlolan(), new Shellder(), new Cloyster(), new Gastly(), new Haunter(), new Gengar(), new GengarMega(), new Onix(), new Drowzee(), new Hypno(), new Krabby(), new Kingler(), new Voltorb(), new VoltorbHisuian(), new Electrode(), new ElectrodeHisuian(), new Exeggcute(), new Exeggutor(), new ExeggutorAlolan(), new Cubone(), new Marowak(), new MarowakAlolan(), new Hitmonlee(), new Hitmonchan(), new Lickitung(), new Koffing(), new Weezing(), new WeezingGalarian(), new Rhyhorn(), new Rhydon(), new Chansey(), new Tangela(), new Kangaskhan(), new KangaskhanMega(), new Horsea(), new Seadra(), new Goldeen(), new Seaking(), new Staryu(), new Starmie(), new MrMime(), new MrMimeGalarian(), new Scyther(), new Jynx(), new Electabuzz(), new Magmar(), new Pinsir(), new PinsirMega(), new Tauros(), new Magikarp(), new Gyarados(), new GyaradosMega(), new Lapras(), new Ditto(), new Eevee(), new EeveePartner(), new Vaporeon(), new Jolteon(), new Flareon(), new Porygon(), new Omanyte(), new Omastar(), new Kabuto(), new Kabutops(), new Aerodactyl(), new AerodactylMega(), new Snorlax(), new Articuno(), new ArticunoGalarian(), new Zapdos(), new ZapdosGalarian(), new Moltres(), new MoltresGalarian(), new Dratini(), new Dragonair(), new Dragonite(), new Mewtwo(), new MewtwoX(), new MewtwoY(), new Mew(), new Chikorita(), new Bayleef(), new Meganium(), new Cyndaquil(), new Quilava(), new Typhlosion(), new TyphlosionHisuian(), new Totodile(), new Croconaw(), new Feraligatr(), new Sentret(), new Furret(), new Hoothoot(), new Noctowl(), new Ledyba(), new Ledian(), new Spinarak(), new Ariados(), new Crobat(), new Chinchou(), new Lanturn(), new Pichu(), new Cleffa(), new Igglybuff(), new Togepi(), new Togetic(), new Natu(), new Xatu(), new Mareep(), new Flaaffy(), new Ampharos(), new AmpharosMega(), new Bellossom(), new Marill(), new Azumarill(), new Sudowoodo(), new Politoed(), new Hoppip(), new Skiploom(), new Jumpluff(), new Aipom(), new Sunkern(), new Sunflora(), new Yanma(), new Wooper(), new Quagsire(), new Espeon(), new Umbreon(), new Murkrow(), new Slowking(), new SlowkingGalarian(), new Misdreavus(), new Unown(), new Wobbuffet(), new Girafarig(), new Pineco(), new Forretress(), new Dunsparce(), new Gligar(), new Steelix(), new SteelixMega(), new Snubbull(), new Granbull(), new Qwilfish(), new QwilfishHisuian(), new Scizor(), new ScizorMega(), new Shuckle(), new Heracross(), new HeracrossMega(), new Sneasel(), new SneaselHisuian(), new Teddiursa(), new Ursaring(), new Slugma(), new Magcargo(), new Swinub(), new Piloswine(), new Corsola(), new CorsolaGalarian(), new Remoraid(), new Octillery(), new Delibird(), new Mantine(), new Skarmory(), new Houndour(), new Houndoom(), new HoundoomMega(), new Kingdra(), new Phanpy(), new Donphan(), new Porygon2(), new Stantler(), new Smeargle(), new Tyrogue(), new Hitmontop(), new Smoochum(), new Elekid(), new Magby(), new Miltank(), new Blissey(), new Raikou(), new Entei(), new Suicune(), new Larvitar(), new Pupitar(), new Tyranitar(), new TyranitarMega(), new Lugia(), new Hooh(), new Celebi(), new Treecko(), new Grovyle(), new Sceptile(), new SceptileMega(), new Torchic(), new Combusken(), new Blaziken(), new BlazikenMega(), new Mudkip(), new Marshtomp(), new Swampert(), new SwampertMega(), new Poochyena(), new Mightyena(), new Zigzagoon(), new ZigzagoonGalarian(), new Linoone(), new LinooneGalarian(), new Wurmple(), new Silcoon(), new Beautifly(), new Cascoon(), new Dustox(), new Lotad(), new Lombre(), new Ludicolo(), new Seedot(), new Nuzleaf(), new Shiftry(), new Taillow(), new Swellow(), new Wingull(), new Pelipper(), new Ralts(), new Kirlia(), new Gardevoir(), new GardevoirMega(), new Surskit(), new Masquerain(), new Shroomish(), new Breloom(), new Slakoth(), new Vigoroth(), new Slaking(), new Nincada(), new Ninjask(), new Shedinja(), new Whismur(), new Loudred(), new Exploud(), new Makuhita(), new Hariyama(), new Azurill(), new Nosepass(), new Skitty(), new Delcatty(), new Sableye(), new SableyeMega(), new Mawile(), new MawileMega(), new Aron(), new Lairon(), new Aggron(), new AggronMega(), new Meditite(), new Medicham(), new MedichamMega(), new Electrike(), new Manectric(), new ManectricMega(), new Plusle(), new Minun(), new Volbeat(), new Illumise(), new Roselia(), new Gulpin(), new Swalot(), new Carvanha(), new Sharpedo(), new SharpedoMega(), new Wailmer(), new Wailord(), new Numel(), new Camerupt(), new CameruptMega(), new Torkoal(), new Spoink(), new Grumpig(), new Spinda(), new Trapinch(), new Vibrava(), new Flygon(), new Cacnea(), new Cacturne(), new Swablu(), new Altaria(), new AltariaMega(), new Zangoose(), new Seviper(), new Lunatone(), new Solrock(), new Barboach(), new Whiscash(), new Corphish(), new Crawdaunt(), new Baltoy(), new Claydol(), new Lileep(), new Cradily(), new Anorith(), new Armaldo(), new Feebas(), new Milotic(), new Castform(), new CastformSunny(), new CastformRainy(), new CastformSnowy(), new Kecleon(), new Shuppet(), new Banette(), new BanetteMega(), new Duskull(), new Dusclops(), new Tropius(), new Chimecho(), new Absol(), new AbsolMega(), new Wynaut(), new Snorunt(), new Glalie(), new GlalieMega(), new Spheal(), new Sealeo(), new Walrein(), new Clamperl(), new Huntail(), new Gorebyss(), new Relicanth(), new Luvdisc(), new Bagon(), new Shelgon(), new Salamence(), new SalamenceMega(), new Beldum(), new Metang(), new Metagross(), new MetagrossMega(), new Regirock(), new Regice(), new Registeel(), new Latias(), new LatiasMega(), new Latios(), new LatiosMega(), new Kyogre(), new KyogrePrimal(), new Groudon(), new GroudonPrimal(), new Rayquaza(), new RayquazaMega(), new Jirachi(), new DeoxysNormal(), new DeoxysAttack(), new DeoxysDefense(), new DeoxysSpeed(), new Turtwig(), new Grotle(), new Torterra(), new Chimchar(), new Monferno(), new Infernape(), new Piplup(), new Prinplup(), new Empoleon(), new Starly(), new Staravia(), new Staraptor(), new Bidoof(), new Bibarel(), new Kricketot(), new Kricketune(), new Shinx(), new Luxio(), new Luxray(), new Budew(), new Roserade(), new Cranidos(), new Rampardos(), new Shieldon(), new Bastiodon(), new BurmyPlant(), new BurmySandy(), new BurmyTrash(), new WormadamPlant(), new WormadamSandy(), new WormadamTrash(), new Mothim(), new Combee(), new Vespiquen(), new Pachirisu(), new Buizel(), new Floatzel(), new Cherubi(), new Cherrim(), new Shellos(), new Gastrodon(), new Ambipom(), new Drifloon(), new Drifblim(), new Buneary(), new Lopunny(), new LopunnyMega(), new Mismagius(), new Honchkrow(), new Glameow(), new Purugly(), new Chingling(), new Stunky(), new Skuntank(), new Bronzor(), new Bronzong(), new Bonsly(), new MimeJr(), new Happiny(), new Chatot(), new Spiritomb(), new Gible(), new Gabite(), new Garchomp(), new GarchompMega(), new Munchlax(), new Riolu(), new Lucario(), new LucarioMega(), new Hippopotas(), new Hippowdon(), new Skorupi(), new Drapion(), new Croagunk(), new Toxicroak(), new Carnivine(), new Finneon(), new Lumineon(), new Mantyke(), new Snover(), new Abomasnow(), new AbomasnowMega(), new Weavile(), new Magnezone(), new Lickilicky(), new Rhyperior(), new Tangrowth(), new Electivire(), new Magmortar(), new Togekiss(), new Yanmega(), new Leafeon(), new Glaceon(), new Gliscor(), new Mamoswine(), new PorygonZ(), new Gallade(), new GalladeMega(), new Probopass(), new Dusknoir(), new Froslass(), new Rotom(), new RotomHeat(), new RotomWash(), new RotomFrost(), new RotomFan(), new RotomMow(), new Uxie(), new Mesprit(), new Azelf(), new Dialga(), new DialgaOrigin(), new Palkia(), new PalkiaOrigin(), new Heatran(), new Regigigas(), new GiratinaAltered(), new GiratinaOrigin(), new Cresselia(), new Phione(), new Manaphy(), new Darkrai(), new ShayminLand(), new ShayminSky(), new Arceus(), new Victini(), new Snivy(), new Servine(), new Serperior(), new Tepig(), new Pignite(), new Emboar(), new Oshawott(), new Dewott(), new Samurott(), new SamurottHisuian(), new Patrat(), new Watchog(), new Lillipup(), new Herdier(), new Stoutland(), new Purrloin(), new Liepard(), new Pansage(), new Simisage(), new Pansear(), new Simisear(), new Panpour(), new Simipour(), new Munna(), new Musharna(), new Pidove(), new Tranquill(), new Unfezant(), new Blitzle(), new Zebstrika(), new Roggenrola(), new Boldore(), new Gigalith(), new Woobat(), new Swoobat(), new Drilbur(), new Excadrill(), new Audino(), new AudinoMega(), new Timburr(), new Gurdurr(), new Conkeldurr(), new Tympole(), new Palpitoad(), new Seismitoad(), new Throh(), new Sawk(), new Sewaddle(), new Swadloon(), new Leavanny(), new Venipede(), new Whirlipede(), new Scolipede(), new Cottonee(), new Whimsicott(), new Petilil(), new Lilligant(), new LilligantHisuian(), new BasculinRed(), new BasculinBlue(), new BasculinWhite(), new Sandile(), new Krokorok(), new Krookodile(), new Darumaka(), new DarumakaGalarian(), new DarmanitanStandard(), new DarmanitanZen(), new DarmanitanGalarianStandard(), new DarmanitanGalarianZen(), new Maractus(), new Dwebble(), new Crustle(), new Scraggy(), new Scrafty(), new Sigilyph(), new Yamask(), new YamaskGalarian(), new Cofagrigus(), new Tirtouga(), new Carracosta(), new Archen(), new Archeops(), new Trubbish(), new Garbodor(), new Zorua(), new ZoruaHisuian(), new Zoroark(), new ZoroarkHisuian(), new Minccino(), new Cinccino(), new Gothita(), new Gothorita(), new Gothitelle(), new Solosis(), new Duosion(), new Reuniclus(), new Ducklett(), new Swanna(), new Vanillite(), new Vanillish(), new Vanilluxe(), new Deerling(), new Sawsbuck(), new Emolga(), new Karrablast(), new Escavalier(), new Foongus(), new Amoonguss(), new Frillish(), new Jellicent(), new Alomomola(), new Joltik(), new Galvantula(), new Ferroseed(), new Ferrothorn(), new Klink(), new Klang(), new Klinklang(), new Tynamo(), new Eelektrik(), new Eelektross(), new Elgyem(), new Beheeyem(), new Litwick(), new Lampent(), new Chandelure(), new Axew(), new Fraxure(), new Haxorus(), new Cubchoo(), new Beartic(), new Cryogonal(), new Shelmet(), new Accelgor(), new Stunfisk(), new StunfiskGalarian(), new Mienfoo(), new Mienshao(), new Druddigon(), new Golett(), new Golurk(), new Pawniard(), new Bisharp(), new Bouffalant(), new Rufflet(), new Braviary(), new BraviaryHisuian(), new Vullaby(), new Mandibuzz(), new Heatmor(), new Durant(), new Deino(), new Zweilous(), new Hydreigon(), new Larvesta(), new Volcarona(), new Cobalion(), new Terrakion(), new Virizion(), new TornadusIncarnate(), new TornadusTherian(), new ThundurusIncarnate(), new ThundurusTherian(), new Reshiram(), new Zekrom(), new LandorusIncarnate(), new LandorusTherian(), new Kyurem(), new KyuremBlack(), new KyuremWhite(), new KeldeoOrdinary(), new KeldeoResolute(), new MeloettaAria(), new MeloettaPiroutte(), new Genesect(), new Chespin(), new Quilladin(), new Chesnaught(), new Fennekin(), new Braixen(), new Delphox(), new Froakie(), new Frogadier(), new Greninja(), new GreninjaAsh(), new Bunnelby(), new Diggersby(), new Fletchling(), new Fletchinder(), new Talonflame(), new Scatterbug(), new Spewpa(), new Vivillon(), new Litleo(), new Pyroar(), new Flabebe(), new Floette(), new Florges(), new Skiddo(), new Gogoat(), new Pancham(), new Pangoro(), new Furfrou(), new Espurr(), new MeowsticM(), new MeowsticF(), new Honedge(), new Doublade(), new AegislashShield(), new AegislashBlade(), new Spritzee(), new Aromatisse(), new Swirlix(), new Slurpuff(), new Inkay(), new Malamar(), new Binacle(), new Barbaracle(), new Skrelp(), new Dragalge(), new Clauncher(), new Clawitzer(), new Helioptile(), new Heliolisk(), new Tyrunt(), new Tyrantrum(), new Amaura(), new Aurorus(), new Sylveon(), new Hawlucha(), new Dedenne(), new Carbink(), new Goomy(), new Sliggoo(), new SliggooHisuian(), new Goodra(), new GoodraHisuian(), new Klefki(), new Phantump(), new Trevenant(), new PumpkabooAverage(), new PumpkabooSmall(), new PumpkabooLarge(), new PumpkabooSuper(), new GourgeistAverage(), new GourgeistSmall(), new GourgeistLarge(), new GourgeistSuper(), new Bergmite(), new Avalugg(), new AvaluggHisuian(), new Noibat(), new Noivern(), new Xerneas(), new Yveltal(), new Zygarde50(), new Zygarde10(), new ZygardeComplete(), new Diancie(), new DiancieMega(), new HoopaConfined(), new HoopaUnbound(), new Volcanion(), new Rowlet(), new Dartrix(), new Decidueye(), new DecidueyeHisuian(), new Litten(), new Torracat(), new Incineroar(), new Popplio(), new Brionne(), new Primarina(), new Pikipek(), new Trumbeak(), new Toucannon(), new Yungoos(), new Gumshoos(), new Grubbin(), new Charjabug(), new Vikavolt(), new Crabrawler(), new Crabominable(), new OricorioBaile(), new OricorioPom(), new OricorioPau(), new OricorioSensu(), new Cutiefly(), new Ribombee(), new Rockruff(), new RockruffTempo(), new LycanrocMidday(), new LycanrocMidnight(), new LycanrocDusk(), new WishiwashiSolo(), new WishiwashiSchool(), new Mareanie(), new Toxapex(), new Mudbray(), new Mudsdale(), new Dewpider(), new Araquanid(), new Fomantis(), new Lurantis(), new Morelull(), new Shiinotic(), new Salandit(), new Salazzle(), new Stufful(), new Bewear(), new Bounsweet(), new Steenee(), new Tsareena(), new Comfey(), new Oranguru(), new Passimian(), new Wimpod(), new Golisopod(), new Sandygast(), new Palossand(), new Pyukumuku(), new TypeNull(), new Silvally(), new MiniorMeteor(), new MiniorCore(), new Komala(), new Turtonator(), new Togedemaru(), new Mimikyu(), new Bruxish(), new Drampa(), new Dhelmise(), new Jangmoo(), new Hakamoo(), new Kommoo(), new TapuKoko(), new TapuLele(), new TapuBulu(), new TapuFini(), new Cosmog(), new Cosmoem(), new Solgaleo(), new Lunala(), new Nihilego(), new Buzzwole(), new Pheromosa(), new Xurkitree(), new Celesteela(), new Kartana(), new Guzzlord(), new Necrozma(), new NecrozmaDusk(), new NecrozmaDawn(), new NecrozmaUltra(), new Magearna(), new Marshadow(), new Poipole(), new Naganadel(), new Stakataka(), new Blacephalon(), new Zeraora(), new Meltan(), new Melmetal(), new Grookey(), new Thwackey(), new Rillaboom(), new Scorbunny(), new Raboot(), new Cinderace(), new Sobble(), new Drizzile(), new Inteleon(), new Skwovet(), new Greedent(), new Rookidee(), new Corvisquire(), new Corviknight(), new Blipbug(), new Dottler(), new Orbeetle(), new Nickit(), new Thievul(), new Gossifleur(), new Eldegoss(), new Wooloo(), new Dubwool(), new Chewtle(), new Drednaw(), new Yamper(), new Boltund(), new Rolycoly(), new Carkol(), new Coalossal(), new Applin(), new Flapple(), new Appletun(), new Silicobra(), new Sandaconda(), new Cramorant(), new Arrokuda(), new Barraskewda(), new Toxel(), new ToxtricityLowKey(), new ToxtricityAmped(), new Sizzlipede(), new Centiskorch(), new Clobbopus(), new Grapploct(), new Sinistea(), new Polteageist(), new Hatenna(), new Hattrem(), new Hatterene(), new Impidimp(), new Morgrem(), new Grimmsnarl(), new Obstagoon(), new Perrserker(), new Cursola(), new Sirfetchd(), new MrRime(), new Runerigus(), new Milcery(), new Alcremie(), new Falinks(), new Pincurchin(), new Snom(), new Frosmoth(), new Stonjourner(), new EiscueIce(), new EiscueNoice(), new IndeedeeM(), new IndeedeeF(), new MorpekoFullBelly(), new MorpekoHangry(), new Cufant(), new Copperajah(), new Dracozolt(), new Arctozolt(), new Dracovish(), new Arctovish(), new Duraludon(), new Dreepy(), new Drakloak(), new Dragapult(), new ZacianCrowned(), new ZacianHero(), new ZamazentaCrown(), new ZamazentaHero(), new Eternatus(), new EternatusMax(), new Kubfu(), new UrshifuSingle(), new UrshifuRapid(), new Zarude(), new Regieleki(), new Regidrago(), new Glastrier(), new Spectrier(), new Calyrex(), new CalyrexIce(), new CalyrexShadow(), new Wyrdeer(), new Kleavor(), new Ursaluna(), new BasculegionM(), new BasculegionF(), new Sneasler(), new Overqwil(), new EnamorusIncarnate(), new EnamorusTherian() };
}







// NO SCROLLING HEHE
































class Bulbasaur extends Pokemon {
    public Bulbasaur() {
        super(45, 49, 49, 65, 65, 45, "GRASS", "POISON", "Bulbasaur");
    }
}
class Ivysaur extends Pokemon {
    public Ivysaur() {
        super(60, 63, 62, 80, 80, 60, "GRASS", "POISON", "Ivysaur");
    }
}
class Venusaur extends Pokemon {
    public Venusaur() {
        super(80, 83, 82, 100, 100, 80, "GRASS", "POISON", "Venusaur");
    }
}
class VenusaurMega extends Pokemon {
    public VenusaurMega() {
        super(80, 123, 100, 122, 120, 80, "GRASS", "POISON", "Mega Venusaur");
    }
}
class Charmander extends Pokemon {
    public Charmander() {
        super(39, 43, 52, 60, 50, 65, "FIRE", "NA", "Charmander");
    }
}
class Charmeleon extends Pokemon {
    public Charmeleon() {
        super(58, 58, 64, 80, 65, 80, "FIRE", "NA", "Charmeleon");
    }
}
class Charizard extends Pokemon {
    public Charizard() {
        super(78, 78, 84, 109, 85, 100, "FIRE", "FLYING", "Charizard");
    }
}
class CharizardX extends Pokemon {
    public CharizardX() {
        super(78, 111, 130, 130, 85, 100, "FIRE", "DRAGON", "Mega Charizard X");
    }
}
class CharizardY extends Pokemon {
    public CharizardY() {
        super(78, 78, 104, 159, 115, 100, "FIRE", "FLYING", "Mega Charizard Y");
    }
}
class Squirtle extends Pokemon {
    public Squirtle() {
        super(44, 65, 48, 50, 64, 43, "WATER", "NA", "Squirtle");
    }
}
class Wartortle extends Pokemon {
    public Wartortle() {
        super(59, 80, 63, 65, 80, 58, "WATER", "NA", "Wartortle");
    }
}
class Blastoise extends Pokemon {
    public Blastoise() {
        super(79, 100, 83, 85, 105, 78, "WATER", "NA", "Blastoise");
    }
}
class BlastoiseMega extends Pokemon {
    public BlastoiseMega() {
        super(79, 120, 103, 135, 115, 78, "WATER", "NA", "Mega Blastoise");
    }
}
class Caterpie extends Pokemon {
    public Caterpie() {
        super(45, 35, 30, 20, 20, 45, "BUG", "NA", "Caterpie");
    }
}
class Metapod extends Pokemon {
    public Metapod() {
        super(50, 55, 20, 25, 25, 30, "BUG", "NA", "Metapod");
    }
}
class Butterfree extends Pokemon {
    public Butterfree() {
        super(60, 50, 45, 90, 80, 70, "BUG", "FLYING", "Butterfree");
    }
}
class Weedle extends Pokemon {
    public Weedle() {
        super(40, 30, 35, 20, 20, 50, "BUG", "POISON", "Weedle");
    }
}
class Kakuna extends Pokemon {
    public Kakuna() {
        super(45, 50, 25, 25, 25, 35, "BUG", "POISON", "Kakuna");
    }
}
class Beedrill extends Pokemon {
    public Beedrill() {
        super(65, 40, 90, 45, 80, 75, "BUG", "POISON", "Beedrill");
    }
}
class BeedrillMega extends Pokemon {
    public BeedrillMega() {
        super(65, 40, 150, 15, 80, 145, "BUG", "POISON", "Mega Beedrill");
    }
}
class Pidgey extends Pokemon {
    public Pidgey() {
        super(40, 40, 45, 35, 35, 56, "NORMAL", "FLYING", "Pidgey");
    }
}
class Pidgeotto extends Pokemon {
    public Pidgeotto() {
        super(63, 55, 60, 50, 50, 71, "NORMAL", "FLYING", "Pidgeotto");
    }
}
class Pidgeot extends Pokemon {
    public Pidgeot() {
        super(83, 75, 80, 70, 70, 101, "NORMAL", "FLYING", "Pidgeot");
    }
}
class PidgeotMega extends Pokemon {
    public PidgeotMega() {
        super(83, 80, 80, 135, 80, 121, "NORMAL", "FLYING", "Mega Pidgeot");
    }
}
class Rattata extends Pokemon {
    public Rattata() {
        super(30, 35, 56, 25, 35, 72, "NORMAL", "NA", "Rattata");
    }
}
class RattataAlolan extends Pokemon {
    public RattataAlolan() {
        super(30, 35, 56, 25, 35, 72, "DARK", "NORMAL", "Alolan Rattata");
    }
}
class Raticate extends Pokemon {
    public Raticate() {
        super(55, 60, 81, 50, 70, 97, "NORMAL", "NA", "Raticate");
    }
}
class RaticateAlolan extends Pokemon {
    public RaticateAlolan() {
        super(75, 70, 71, 40, 80, 77, "DARK", "NORMAL", "Alolan Raticate");
    }
}
class Spearow extends Pokemon {
    public Spearow() {
        super(40, 30, 60, 31, 31, 70, "NORMAL", "FLYING", "Spearow");
    }
}
class Fearow extends Pokemon {
    public Fearow() {
        super(65, 65, 90, 61, 61, 100, "NORMAL", "FLYING", "Fearow");
    }
}
class Ekans extends Pokemon {
    public Ekans() {
        super(35, 44, 60, 40, 54, 55, "POISON", "NA", "Ekans");
    }
}
class Arbok extends Pokemon {
    public Arbok() {
        super(60, 69, 95, 65, 79, 80, "POISON", "NA", "Arbok");
    }
}
class Pikachu extends Pokemon {
    public Pikachu() {
        super(35, 40, 55, 50, 50, 90, "ELECTRIC", "NA", "Pikachu");
    }
}
class PikachuPartner extends Pokemon {
    public PikachuPartner() {
        super(45, 50, 80, 75, 60, 120, "ELECTRIC", "NA", "Partner Pikachu");
    }
}
class Raichu extends Pokemon {
    public Raichu() {
        super(60, 55, 90, 90, 80, 110, "ELECTRIC", "NA", "Raichu");
    }
}
class RaichuAlolan extends Pokemon {
    public RaichuAlolan() {
        super(60, 50, 85, 95, 85, 110, "ELECTRIC", "PSYCHIC", "Alolan Raichu");
    }
}
class Sandshrew extends Pokemon {
    public Sandshrew() {
        super(50, 85, 75, 20, 30, 40, "GROUND", "NA", "Sandshrew");
    }
}
class SandshrewAlolan extends Pokemon {
    public SandshrewAlolan() {
        super(50, 90, 75, 10, 35, 40, "ICE", "STEEL", "Alolan Sandshrew");
    }
}
class Sandslash extends Pokemon {
    public Sandslash() {
        super(75, 110, 100, 45, 55, 65, "GROUND", "NA", "Sandslash");
    }
}
class SandslashAlolan extends Pokemon {
    public SandslashAlolan() {
        super(75, 120, 100, 25, 65, 65, "ICE", "STEEL", "Alolan Sandslash");
    }
}
class NidoranM extends Pokemon {
    public NidoranM() {
        super(55, 52, 47, 40, 40, 41, "POISON", "NA", "NidoranÃ¢â„¢â€š");
    }
}
class Nidorina extends Pokemon {
    public Nidorina() {
        super(70, 67, 62, 55, 55, 56, "POISON", "NA", "Nidorina");
    }
}
class Nidoqueen extends Pokemon {
    public Nidoqueen() {
        super(90, 87, 92, 75, 85, 76, "POISON", "GROUND", "Nidoqueen");
    }
}
class NidoranF extends Pokemon {
    public NidoranF() {
        super(46, 40, 57, 40, 40, 50, "POISON", "NA", "NidoranÃ¢â„¢â‚¬");
    }
}
class Nidorino extends Pokemon {
    public Nidorino() {
        super(61, 57, 72, 55, 55, 65, "POISON", "NA", "Nidorino");
    }
}
class Nidoking extends Pokemon {
    public Nidoking() {
        super(81, 77, 102, 85, 75, 85, "POISON", "GROUND", "Nidoking");
    }
}
class Clefairy extends Pokemon {
    public Clefairy() {
        super(70, 48, 45, 60, 65, 35, "FAIRY", "NA", "Clefairy");
    }
}
class Clefable extends Pokemon {
    public Clefable() {
        super(95, 73, 70, 95, 90, 60, "FAIRY", "NA", "Clefable");
    }
}
class Vulpix extends Pokemon {
    public Vulpix() {
        super(38, 40, 41, 50, 65, 65, "FIRE", "NA", "Vulpix");
    }
}
class VulpixAlolan extends Pokemon {
    public VulpixAlolan() {
        super(38, 40, 41, 50, 65, 65, "ICE", "NA", "Alolan Vulpix");
    }
}
class Ninetales extends Pokemon {
    public Ninetales() {
        super(73, 75, 76, 81, 100, 100, "FIRE", "NA", "Ninetales");
    }
}
class NinetalesAlolan extends Pokemon {
    public NinetalesAlolan() {
        super(73, 75, 67, 81, 100, 109, "ICE", "FAIRY", "Alolan Ninetales");
    }
}
class Jigglypuff extends Pokemon {
    public Jigglypuff() {
        super(115, 20, 45, 45, 25, 20, "NORMAL", "FAIRY", "Jigglypuff");
    }
}
class Wigglytuff extends Pokemon {
    public Wigglytuff() {
        super(140, 45, 70, 85, 50, 45, "NORMAL", "FAIRY", "Wigglytuff");
    }
}
class Zubat extends Pokemon {
    public Zubat() {
        super(40, 35, 45, 30, 40, 55, "POISON", "FLYING", "Zubat");
    }
}
class Golbat extends Pokemon {
    public Golbat() {
        super(75, 70, 80, 65, 75, 90, "POISON", "FLYING", "Golbat");
    }
}
class Oddish extends Pokemon {
    public Oddish() {
        super(45, 55, 50, 75, 65, 30, "GRASS", "POISON", "Oddish");
    }
}
class Gloom extends Pokemon {
    public Gloom() {
        super(60, 70, 65, 85, 75, 40, "GRASS", "POISON", "Gloom");
    }
}
class Vileplume extends Pokemon {
    public Vileplume() {
        super(75, 85, 80, 110, 90, 50, "GRASS", "POISON", "Vileplume");
    }
}
class Paras extends Pokemon {
    public Paras() {
        super(35, 55, 70, 45, 55, 25, "BUG", "GRASS", "Paras");
    }
}
class Parasect extends Pokemon {
    public Parasect() {
        super(60, 80, 95, 60, 80, 30, "BUG", "GRASS", "Parasect");
    }
}
class Venonat extends Pokemon {
    public Venonat() {
        super(60, 50, 55, 40, 55, 45, "BUG", "POISON", "Venonat");
    }
}
class Venomoth extends Pokemon {
    public Venomoth() {
        super(70, 60, 65, 90, 75, 90, "BUG", "POISON", "Venomoth");
    }
}
class Diglett extends Pokemon {
    public Diglett() {
        super(10, 25, 55, 35, 45, 95, "GROUND", "NA", "Diglett");
    }
}
class DiglettAlolan extends Pokemon {
    public DiglettAlolan() {
        super(10, 30, 55, 35, 45, 90, "GROUND", "STEEL", "Alolan Diglett");
    }
}
class Dugtrio extends Pokemon {
    public Dugtrio() {
        super(35, 50, 100, 50, 70, 120, "GROUND", "NA", "Dugtrio");
    }
}
class DugtrioAlolan extends Pokemon {
    public DugtrioAlolan() {
        super(35, 60, 100, 50, 70, 110, "GROUND", "STEEL", "Alolan Dugtrio");
    }
}
class Meowth extends Pokemon {
    public Meowth() {
        super(40, 35, 45, 40, 40, 90, "NORMAL", "NA", "Meowth");
    }
}
class MeowthAlolan extends Pokemon {
    public MeowthAlolan() {
        super(40, 35, 35, 50, 40, 90, "DARK", "NA", "Alolan Meowth");
    }
}
class MeowthGalarian extends Pokemon {
    public MeowthGalarian() {
        super(50, 55, 65, 40, 40, 40, "STEEL", "NA", "Galarian Meowth");
    }
}
class Persian extends Pokemon {
    public Persian() {
        super(65, 60, 70, 65, 65, 115, "NORMAL", "NA", "Persian");
    }
}
class PersianAlolan extends Pokemon {
    public PersianAlolan() {
        super(65, 60, 60, 75, 65, 115, "DARK", "NA", "Alolan Persian");
    }
}
class Psyduck extends Pokemon {
    public Psyduck() {
        super(50, 48, 52, 65, 50, 55, "WATER", "NA", "Psyduck");
    }
}
class Golduck extends Pokemon {
    public Golduck() {
        super(80, 78, 82, 95, 80, 85, "WATER", "NA", "Golduck");
    }
}
class Mankey extends Pokemon {
    public Mankey() {
        super(40, 35, 80, 35, 45, 70, "FIGHTING", "NA", "Mankey");
    }
}
class Primeape extends Pokemon {
    public Primeape() {
        super(65, 60, 105, 60, 70, 95, "FIGHTING", "NA", "Primeape");
    }
}
class Growlithe extends Pokemon {
    public Growlithe() {
        super(55, 45, 70, 70, 50, 60, "FIRE", "NA", "Growlithe");
    }
}
class GrowlitheHisuian extends Pokemon {
    public GrowlitheHisuian() {
        super(60, 45, 75, 65, 50, 55, "FIRE", "ROCK", "Hisuian Growlithe");
    }
}
class Arcanine extends Pokemon {
    public Arcanine() {
        super(90, 80, 110, 100, 80, 95, "FIRE", "NA", "Arcanine");
    }
}
class ArcanineHisuian extends Pokemon {
    public ArcanineHisuian() {
        super(95, 80, 115, 95, 80, 90, "FIRE", "ROCK", "Hisuian Arcanine");
    }
}
class Poliwag extends Pokemon {
    public Poliwag() {
        super(40, 40, 50, 40, 40, 90, "WATER", "NA", "Poliwag");
    }
}
class Poliwhirl extends Pokemon {
    public Poliwhirl() {
        super(65, 65, 65, 50, 50, 90, "WATER", "NA", "Poliwhirl");
    }
}
class Poliwrath extends Pokemon {
    public Poliwrath() {
        super(90, 95, 95, 70, 90, 70, "WATER", "FIGHTING", "Poliwrath");
    }
}
class Abra extends Pokemon {
    public Abra() {
        super(25, 15, 20, 105, 55, 90, "PSYCHIC", "NA", "Abra");
    }
}
class Kadabra extends Pokemon {
    public Kadabra() {
        super(40, 30, 35, 120, 70, 105, "PSYCHIC", "NA", "Kadabra");
    }
}
class Alakazam extends Pokemon {
    public Alakazam() {
        super(55, 45, 50, 135, 95, 120, "PSYCHIC", "NA", "Alakazam");
    }
}
class AlakazamMega extends Pokemon {
    public AlakazamMega() {
        super(55, 65, 50, 175, 105, 150, "PSYCHIC", "NA", "Mega Alakazam");
    }
}
class Machop extends Pokemon {
    public Machop() {
        super(70, 50, 80, 35, 35, 35, "FIGHTING", "NA", "Machop");
    }
}
class Machoke extends Pokemon {
    public Machoke() {
        super(80, 70, 100, 50, 60, 45, "FIGHTING", "NA", "Machoke");
    }
}
class Machamp extends Pokemon {
    public Machamp() {
        super(90, 80, 130, 65, 85, 55, "FIGHTING", "NA", "Machamp");
    }
}
class Bellsprout extends Pokemon {
    public Bellsprout() {
        super(50, 35, 75, 70, 30, 40, "GRASS", "POISON", "Bellsprout");
    }
}
class Weepinbell extends Pokemon {
    public Weepinbell() {
        super(65, 50, 90, 85, 45, 55, "GRASS", "POISON", "Weepinbell");
    }
}
class Victreebel extends Pokemon {
    public Victreebel() {
        super(80, 65, 105, 100, 70, 70, "GRASS", "POISON", "Victreebel");
    }
}
class Tentacool extends Pokemon {
    public Tentacool() {
        super(40, 35, 40, 50, 100, 70, "WATER", "POISON", "Tentacool");
    }
}
class Tentacruel extends Pokemon {
    public Tentacruel() {
        super(80, 65, 70, 80, 120, 100, "WATER", "POISON", "Tentacruel");
    }
}
class Geodude extends Pokemon {
    public Geodude() {
        super(40, 100, 80, 30, 30, 20, "ROCK", "GROUND", "Geodude");
    }
}
class GeodudeAlolan extends Pokemon {
    public GeodudeAlolan() {
        super(40, 100, 80, 30, 30, 20, "ROCK", "ELECTRIC", "Alolan Geodude");
    }
}
class Graveler extends Pokemon {
    public Graveler() {
        super(55, 115, 95, 45, 45, 35, "ROCK", "GROUND", "Graveler");
    }
}
class GravelerAlolan extends Pokemon {
    public GravelerAlolan() {
        super(55, 115, 95, 45, 45, 35, "ROCK", "ELECTRIC", "Alolan Graveler");
    }
}
class Golem extends Pokemon {
    public Golem() {
        super(80, 130, 120, 55, 65, 45, "ROCK", "GROUND", "Golem");
    }
}
class GolemAlolan extends Pokemon {
    public GolemAlolan() {
        super(80, 130, 120, 55, 65, 45, "ROCK", "ELECTRIC", "Alolan Golem");
    }
}
class Ponyta extends Pokemon {
    public Ponyta() {
        super(50, 55, 85, 65, 65, 90, "FIRE", "NA", "Ponyta");
    }
}
class PonytaGalarian extends Pokemon {
    public PonytaGalarian() {
        super(50, 55, 85, 65, 65, 90, "PSYCHIC", "NA", "Galarian Ponyta");
    }
}
class Rapidash extends Pokemon {
    public Rapidash() {
        super(65, 70, 100, 80, 80, 105, "FIRE", "NA", "Rapidash");
    }
}
class RapidashGalarian extends Pokemon {
    public RapidashGalarian() {
        super(65, 70, 100, 80, 80, 105, "PSYCHIC", "FAIRY", "Galarian Rapidash");
    }
}
class Slowpoke extends Pokemon {
    public Slowpoke() {
        super(90, 65, 65, 40, 40, 15, "WATER", "PSYCHIC", "Slowpoke");
    }
}
class SlowpokeGalarian extends Pokemon {
    public SlowpokeGalarian() {
        super(90, 65, 65, 40, 40, 15, "PSYCHIC", "NA", "Galarian Slowpoke");
    }
}
class Slowbro extends Pokemon {
    public Slowbro() {
        super(95, 110, 75, 100, 80, 30, "WATER", "PSYCHIC", "Slowbro");
    }
}
class SlowbroMega extends Pokemon {
    public SlowbroMega() {
        super(95, 180, 75, 130, 80, 30, "WATER", "PSYCHIC", "Mega Slowbro");
    }
}
class SlowbroGalarian extends Pokemon {
    public SlowbroGalarian() {
        super(95, 95, 100, 100, 70, 30, "POISON", "PSYCHIC", "Galarian Slowbro");
    }
}
class Magnemite extends Pokemon {
    public Magnemite() {
        super(25, 70, 35, 95, 55, 45, "ELECTRIC", "STEEL", "Magnemite");
    }
}
class Magneton extends Pokemon {
    public Magneton() {
        super(50, 95, 60, 120, 70, 70, "ELECTRIC", "STEEL", "Magneton");
    }
}
class Farfetchd extends Pokemon {
    public Farfetchd() {
        super(52, 55, 90, 58, 62, 60, "NORMAL", "FLYING", "Farfetch'd");
    }
}
class FarfetchdGalarian extends Pokemon {
    public FarfetchdGalarian() {
        super(52, 55, 95, 58, 62, 55, "FIGHTING", "NA", "Galarian Farfetch'd");
    }
}
class Doduo extends Pokemon {
    public Doduo() {
        super(35, 45, 85, 35, 35, 75, "NORMAL", "FLYING", "Doduo");
    }
}
class Dodrio extends Pokemon {
    public Dodrio() {
        super(60, 70, 110, 60, 60, 110, "NORMAL", "FLYING", "Dodrio");
    }
}
class Seel extends Pokemon {
    public Seel() {
        super(65, 55, 45, 45, 70, 45, "WATER", "NA", "Seel");
    }
}
class Dewgong extends Pokemon {
    public Dewgong() {
        super(90, 80, 70, 70, 95, 70, "WATER", "ICE", "Dewgong");
    }
}
class Grimer extends Pokemon {
    public Grimer() {
        super(80, 50, 80, 40, 50, 25, "POISON", "NA", "Grimer");
    }
}
class GrimerAlolan extends Pokemon {
    public GrimerAlolan() {
        super(80, 50, 80, 40, 50, 25, "POISON", "DARK", "Alolan Grimer");
    }
}
class Muk extends Pokemon {
    public Muk() {
        super(105, 75, 105, 65, 100, 50, "POISON", "NA", "Muk");
    }
}
class MukAlolan extends Pokemon {
    public MukAlolan() {
        super(105, 75, 105, 65, 100, 50, "POISON", "DARK", "Alolan Muk");
    }
}
class Shellder extends Pokemon {
    public Shellder() {
        super(30, 100, 65, 45, 25, 40, "WATER", "NA", "Shellder");
    }
}
class Cloyster extends Pokemon {
    public Cloyster() {
        super(50, 180, 95, 85, 45, 70, "WATER", "ICE", "Cloyster");
    }
}
class Gastly extends Pokemon {
    public Gastly() {
        super(30, 30, 35, 100, 35, 80, "GHOST", "POISON", "Gastly");
    }
}
class Haunter extends Pokemon {
    public Haunter() {
        super(45, 45, 50, 115, 55, 95, "GHOST", "POISON", "Haunter");
    }
}
class Gengar extends Pokemon {
    public Gengar() {
        super(60, 60, 65, 130, 75, 110, "GHOST", "POISON", "Gengar");
    }
}
class GengarMega extends Pokemon {
    public GengarMega() {
        super(60, 80, 65, 170, 95, 130, "GHOST", "POISON", "Mega Gengar");
    }
}
class Onix extends Pokemon {
    public Onix() {
        super(35, 160, 45, 30, 45, 70, "ROCK", "GROUND", "Onix");
    }
}
class Drowzee extends Pokemon {
    public Drowzee() {
        super(60, 45, 48, 43, 90, 42, "PSYCHIC", "NA", "Drowzee");
    }
}
class Hypno extends Pokemon {
    public Hypno() {
        super(85, 70, 73, 73, 115, 67, "PSYCHIC", "NA", "Hypno");
    }
}
class Krabby extends Pokemon {
    public Krabby() {
        super(30, 90, 105, 25, 25, 50, "WATER", "NA", "Krabby");
    }
}
class Kingler extends Pokemon {
    public Kingler() {
        super(55, 115, 130, 50, 50, 75, "WATER", "NA", "Kingler");
    }
}
class Voltorb extends Pokemon {
    public Voltorb() {
        super(40, 50, 30, 55, 55, 100, "ELECTRIC", "NA", "Voltorb");
    }
}
class VoltorbHisuian extends Pokemon {
    public VoltorbHisuian() {
        super(40, 50, 30, 55, 55, 100, "ELECTRIC", "GRASS", "Hisuian Voltorb");
    }
}
class Electrode extends Pokemon {
    public Electrode() {
        super(60, 70, 50, 80, 80, 150, "ELECTRIC", "NA", "Electrode");
    }
}
class ElectrodeHisuian extends Pokemon {
    public ElectrodeHisuian() {
        super(60, 70, 50, 80, 80, 150, "ELECTRIC", "GRASS", "Hisuian Electrode");
    }
}
class Exeggcute extends Pokemon {
    public Exeggcute() {
        super(60, 80, 40, 60, 45, 40, "GRASS", "PSYCHIC", "Exeggcute");
    }
}
class Exeggutor extends Pokemon {
    public Exeggutor() {
        super(95, 85, 95, 125, 75, 55, "GRASS", "PSYCHIC", "Exeggutor");
    }
}
class ExeggutorAlolan extends Pokemon {
    public ExeggutorAlolan() {
        super(95, 85, 105, 125, 75, 45, "GRASS", "DRAGON", "Alolan Exeggutor");
    }
}
class Cubone extends Pokemon {
    public Cubone() {
        super(50, 95, 50, 40, 50, 35, "GROUND", "NA", "Cubone");
    }
}
class Marowak extends Pokemon {
    public Marowak() {
        super(60, 110, 80, 50, 80, 45, "GROUND", "NA", "Marowak");
    }
}
class MarowakAlolan extends Pokemon {
    public MarowakAlolan() {
        super(60, 110, 80, 50, 80, 45, "FIRE", "GHOST", "Alolan Marowak");
    }
}
class Hitmonlee extends Pokemon {
    public Hitmonlee() {
        super(50, 53, 120, 35, 110, 87, "FIGHTING", "NA", "Hitmonlee");
    }
}
class Hitmonchan extends Pokemon {
    public Hitmonchan() {
        super(50, 79, 105, 35, 110, 76, "FIGHTING", "NA", "Hitmonchan");
    }
}
class Lickitung extends Pokemon {
    public Lickitung() {
        super(90, 75, 55, 60, 75, 30, "NORMAL", "NA", "Lickitung");
    }
}
class Koffing extends Pokemon {
    public Koffing() {
        super(40, 95, 65, 60, 45, 35, "POISON", "NA", "Koffing");
    }
}
class Weezing extends Pokemon {
    public Weezing() {
        super(65, 120, 90, 85, 70, 60, "POISON", "NA", "Weezing");
    }
}
class WeezingGalarian extends Pokemon {
    public WeezingGalarian() {
        super(65, 120, 90, 85, 70, 60, "POISON", "FAIRY", "Galarian Weezing");
    }
}
class Rhyhorn extends Pokemon {
    public Rhyhorn() {
        super(80, 95, 85, 30, 30, 25, "GROUND", "ROCK", "Rhyhorn");
    }
}
class Rhydon extends Pokemon {
    public Rhydon() {
        super(105, 120, 130, 45, 45, 40, "GROUND", "ROCK", "Rhydon");
    }
}
class Chansey extends Pokemon {
    public Chansey() {
        super(250, 5, 5, 35, 105, 50, "NORMAL", "NA", "Chansey");
    }
}
class Tangela extends Pokemon {
    public Tangela() {
        super(65, 115, 55, 100, 40, 60, "GRASS", "NA", "Tangela");
    }
}
class Kangaskhan extends Pokemon {
    public Kangaskhan() {
        super(105, 80, 95, 40, 80, 90, "NORMAL", "NA", "Kangaskhan");
    }
}
class KangaskhanMega extends Pokemon {
    public KangaskhanMega() {
        super(105, 100, 125, 60, 100, 100, "NORMAL", "NA", "Mega Kangaskhan");
    }
}
class Horsea extends Pokemon {
    public Horsea() {
        super(30, 70, 40, 70, 25, 60, "WATER", "NA", "Horsea");
    }
}
class Seadra extends Pokemon {
    public Seadra() {
        super(55, 95, 65, 95, 45, 85, "WATER", "NA", "Seadra");
    }
}
class Goldeen extends Pokemon {
    public Goldeen() {
        super(45, 60, 67, 35, 50, 63, "WATER", "NA", "Goldeen");
    }
}
class Seaking extends Pokemon {
    public Seaking() {
        super(80, 65, 92, 65, 80, 68, "WATER", "NA", "Seaking");
    }
}
class Staryu extends Pokemon {
    public Staryu() {
        super(30, 55, 45, 70, 55, 85, "WATER", "NA", "Staryu");
    }
}
class Starmie extends Pokemon {
    public Starmie() {
        super(60, 85, 75, 100, 85, 115, "WATER", "PSYCHIC", "Starmie");
    }
}
class MrMime extends Pokemon {
    public MrMime() {
        super(40, 65, 45, 100, 120, 90, "PSYCHIC", "FAIRY", "Mr. Mime");
    }
}
class MrMimeGalarian extends Pokemon {
    public MrMimeGalarian() {
        super(50, 65, 65, 90, 90, 100, "ICE", "PSYCHIC", "Galarian Mr. Mime");
    }
}
class Scyther extends Pokemon {
    public Scyther() {
        super(70, 80, 110, 55, 80, 105, "BUG", "FLYING", "Scyther");
    }
}
class Jynx extends Pokemon {
    public Jynx() {
        super(65, 35, 50, 115, 95, 95, "ICE", "PSYCHIC", "Jynx");
    }
}
class Electabuzz extends Pokemon {
    public Electabuzz() {
        super(65, 57, 83, 95, 85, 105, "ELECTRIC", "NA", "Electabuzz");
    }
}
class Magmar extends Pokemon {
    public Magmar() {
        super(65, 57, 95, 100, 85, 93, "FIRE", "NA", "Magmar");
    }
}
class Pinsir extends Pokemon {
    public Pinsir() {
        super(65, 100, 125, 55, 70, 85, "BUG", "NA", "Pinsir");
    }
}
class PinsirMega extends Pokemon {
    public PinsirMega() {
        super(65, 120, 155, 65, 90, 105, "BUG", "FLYING", "Mega Pinsir");
    }
}
class Tauros extends Pokemon {
    public Tauros() {
        super(75, 95, 100, 40, 70, 110, "NORMAL", "NA", "Tauros");
    }
}
class Magikarp extends Pokemon {
    public Magikarp() {
        super(20, 55, 10, 15, 20, 80, "WATER", "NA", "Magikarp");
    }
}
class Gyarados extends Pokemon {
    public Gyarados() {
        super(95, 79, 125, 60, 100, 81, "WATER", "FLYING", "Gyarados");
    }
}
class GyaradosMega extends Pokemon {
    public GyaradosMega() {
        super(95, 109, 155, 70, 130, 81, "WATER", "DARK", "Mega Gyarados");
    }
}
class Lapras extends Pokemon {
    public Lapras() {
        super(130, 80, 85, 85, 95, 60, "WATER", "ICE", "Lapras");
    }
}
class Ditto extends Pokemon {
    public Ditto() {
        super(48, 48, 48, 48, 48, 48, "NORMAL", "NA", "Ditto");
    }
}
class Eevee extends Pokemon {
    public Eevee() {
        super(55, 50, 55, 45, 65, 55, "NORMAL", "NA", "Eevee");
    }
}
class EeveePartner extends Pokemon {
    public EeveePartner() {
        super(65, 70, 75, 65, 85, 75, "NORMAL", "NA", "Partner Eevee");
    }
}
class Vaporeon extends Pokemon {
    public Vaporeon() {
        super(130, 60, 65, 110, 95, 65, "WATER", "NA", "Vaporeon");
    }
}
class Jolteon extends Pokemon {
    public Jolteon() {
        super(65, 60, 65, 110, 95, 130, "ELECTRIC", "NA", "Jolteon");
    }
}
class Flareon extends Pokemon {
    public Flareon() {
        super(65, 60, 130, 95, 110, 65, "FIRE", "NA", "Flareon");
    }
}
class Porygon extends Pokemon {
    public Porygon() {
        super(65, 70, 60, 85, 75, 40, "NORMAL", "NA", "Porygon");
    }
}
class Omanyte extends Pokemon {
    public Omanyte() {
        super(35, 100, 40, 90, 55, 35, "ROCK", "WATER", "Omanyte");
    }
}
class Omastar extends Pokemon {
    public Omastar() {
        super(70, 125, 60, 115, 70, 55, "ROCK", "WATER", "Omastar");
    }
}
class Kabuto extends Pokemon {
    public Kabuto() {
        super(30, 90, 80, 55, 45, 55, "ROCK", "WATER", "Kabuto");
    }
}
class Kabutops extends Pokemon {
    public Kabutops() {
        super(60, 105, 115, 65, 70, 80, "ROCK", "WATER", "Kabutops");
    }
}
class Aerodactyl extends Pokemon {
    public Aerodactyl() {
        super(80, 65, 105, 60, 75, 130, "ROCK", "FLYING", "Aerodactyl");
    }
}
class AerodactylMega extends Pokemon {
    public AerodactylMega() {
        super(80, 85, 135, 70, 95, 150, "ROCK", "FLYING", "Mega Aerodactyl");
    }
}
class Snorlax extends Pokemon {
    public Snorlax() {
        super(160, 65, 110, 65, 110, 30, "NORMAL", "NA", "Snorlax");
    }
}
class Articuno extends Pokemon {
    public Articuno() {
        super(90, 100, 85, 95, 125, 85, "ICE", "FLYING", "Articuno");
    }
}
class ArticunoGalarian extends Pokemon {
    public ArticunoGalarian() {
        super(90, 85, 85, 125, 100, 95, "PSYCHIC", "FLYING", "Galarian Articuno");
    }
}
class Zapdos extends Pokemon {
    public Zapdos() {
        super(90, 85, 90, 125, 90, 100, "ELECTRIC", "FLYING", "Zapdos");
    }
}
class ZapdosGalarian extends Pokemon {
    public ZapdosGalarian() {
        super(90, 90, 125, 85, 90, 100, "FIGHTING", "FLYING", "Galarian Zapdos");
    }
}
class Moltres extends Pokemon {
    public Moltres() {
        super(90, 90, 100, 125, 85, 90, "FIRE", "FLYING", "Moltres");
    }
}
class MoltresGalarian extends Pokemon {
    public MoltresGalarian() {
        super(90, 90, 85, 100, 125, 90, "DARK", "FLYING", "Galarian Moltres");
    }
}
class Dratini extends Pokemon {
    public Dratini() {
        super(41, 45, 64, 50, 50, 50, "DRAGON", "NA", "Dratini");
    }
}
class Dragonair extends Pokemon {
    public Dragonair() {
        super(61, 65, 84, 70, 70, 70, "DRAGON", "NA", "Dragonair");
    }
}
class Dragonite extends Pokemon {
    public Dragonite() {
        super(91, 95, 134, 100, 100, 80, "DRAGON", "FLYING", "Dragonite");
    }
}
class Mewtwo extends Pokemon {
    public Mewtwo() {
        super(106, 90, 110, 154, 90, 130, "PSYCHIC", "NA", "Mewtwo");
    }
}
class MewtwoX extends Pokemon {
    public MewtwoX() {
        super(106, 100, 190, 154, 100, 130, "PSYCHIC", "FIGHTING", "Mega Mewtwo X");
    }
}
class MewtwoY extends Pokemon {
    public MewtwoY() {
        super(106, 70, 150, 194, 120, 140, "PSYCHIC", "NA", "Mega Mewtwo Y");
    }
}
class Mew extends Pokemon {
    public Mew() {
        super(100, 100, 100, 100, 100, 100, "PSYCHIC", "NA", "Mew");
    }
}
class Chikorita extends Pokemon {
    public Chikorita() {
        super(45, 65, 49, 49, 65, 45, "GRASS", "NA", "Chikorita");
    }
}
class Bayleef extends Pokemon {
    public Bayleef() {
        super(60, 80, 62, 63, 80, 60, "GRASS", "NA", "Bayleef");
    }
}
class Meganium extends Pokemon {
    public Meganium() {
        super(80, 100, 82, 83, 100, 80, "GRASS", "NA", "Meganium");
    }
}
class Cyndaquil extends Pokemon {
    public Cyndaquil() {
        super(39, 43, 52, 60, 50, 65, "FIRE", "NA", "Cyndaquil");
    }
}
class Quilava extends Pokemon {
    public Quilava() {
        super(58, 58, 64, 80, 65, 80, "FIRE", "NA", "Quilava");
    }
}
class Typhlosion extends Pokemon {
    public Typhlosion() {
        super(78, 78, 84, 109, 85, 100, "FIRE", "NA", "Typhlosion");
    }
}
class TyphlosionHisuian extends Pokemon {
    public TyphlosionHisuian() {
        super(73, 78, 84, 119, 85, 95, "FIRE", "GHOST", "Hisuian Typhlosion");
    }
}
class Totodile extends Pokemon {
    public Totodile() {
        super(50, 64, 65, 44, 48, 43, "WATER", "NA", "Totodile");
    }
}
class Croconaw extends Pokemon {
    public Croconaw() {
        super(65, 80, 80, 59, 63, 58, "WATER", "NA", "Croconaw");
    }
}
class Feraligatr extends Pokemon {
    public Feraligatr() {
        super(85, 100, 105, 79, 83, 78, "WATER", "NA", "Feraligatr");
    }
}
class Sentret extends Pokemon {
    public Sentret() {
        super(35, 34, 46, 35, 45, 20, "NORMAL", "NA", "Sentret");
    }
}
class Furret extends Pokemon {
    public Furret() {
        super(85, 64, 76, 45, 55, 90, "NORMAL", "NA", "Furret");
    }
}
class Hoothoot extends Pokemon {
    public Hoothoot() {
        super(60, 30, 30, 36, 56, 50, "NORMAL", "FLYING", "Hoothoot");
    }
}
class Noctowl extends Pokemon {
    public Noctowl() {
        super(100, 50, 50, 86, 96, 70, "NORMAL", "FLYING", "Noctowl");
    }
}
class Ledyba extends Pokemon {
    public Ledyba() {
        super(40, 30, 20, 40, 80, 55, "BUG", "FLYING", "Ledyba");
    }
}
class Ledian extends Pokemon {
    public Ledian() {
        super(55, 50, 35, 55, 110, 85, "BUG", "FLYING", "Ledian");
    }
}
class Spinarak extends Pokemon {
    public Spinarak() {
        super(40, 40, 60, 40, 40, 30, "BUG", "POISON", "Spinarak");
    }
}
class Ariados extends Pokemon {
    public Ariados() {
        super(70, 70, 90, 60, 70, 40, "BUG", "POISON", "Ariados");
    }
}
class Crobat extends Pokemon {
    public Crobat() {
        super(85, 80, 90, 70, 80, 130, "POISON", "FLYING", "Crobat");
    }
}
class Chinchou extends Pokemon {
    public Chinchou() {
        super(75, 38, 38, 56, 56, 67, "WATER", "ELECTRIC", "Chinchou");
    }
}
class Lanturn extends Pokemon {
    public Lanturn() {
        super(125, 58, 58, 76, 76, 67, "WATER", "ELECTRIC", "Lanturn");
    }
}
class Pichu extends Pokemon {
    public Pichu() {
        super(20, 15, 40, 35, 35, 60, "ELECTRIC", "NA", "Pichu");
    }
}
class Cleffa extends Pokemon {
    public Cleffa() {
        super(50, 28, 25, 45, 55, 15, "FAIRY", "NA", "Cleffa");
    }
}
class Igglybuff extends Pokemon {
    public Igglybuff() {
        super(90, 15, 30, 40, 20, 15, "NORMAL", "FAIRY", "Igglybuff");
    }
}
class Togepi extends Pokemon {
    public Togepi() {
        super(35, 65, 20, 40, 65, 20, "FAIRY", "NA", "Togepi");
    }
}
class Togetic extends Pokemon {
    public Togetic() {
        super(55, 85, 40, 80, 105, 40, "FAIRY", "FLYING", "Togetic");
    }
}
class Natu extends Pokemon {
    public Natu() {
        super(40, 45, 50, 70, 45, 70, "PSYCHIC", "FLYING", "Natu");
    }
}
class Xatu extends Pokemon {
    public Xatu() {
        super(65, 70, 75, 95, 70, 95, "PSYCHIC", "FLYING", "Xatu");
    }
}
class Mareep extends Pokemon {
    public Mareep() {
        super(55, 40, 40, 65, 45, 35, "ELECTRIC", "NA", "Mareep");
    }
}
class Flaaffy extends Pokemon {
    public Flaaffy() {
        super(70, 55, 55, 80, 60, 45, "ELECTRIC", "NA", "Flaaffy");
    }
}
class Ampharos extends Pokemon {
    public Ampharos() {
        super(90, 85, 75, 115, 90, 55, "ELECTRIC", "NA", "Ampharos");
    }
}
class AmpharosMega extends Pokemon {
    public AmpharosMega() {
        super(90, 105, 95, 165, 110, 45, "ELECTRIC", "DRAGON", "Mega Ampharos");
    }
}
class Bellossom extends Pokemon {
    public Bellossom() {
        super(75, 95, 80, 90, 100, 50, "GRASS", "NA", "Bellossom");
    }
}
class Marill extends Pokemon {
    public Marill() {
        super(70, 50, 20, 20, 50, 40, "WATER", "FAIRY", "Marill");
    }
}
class Azumarill extends Pokemon {
    public Azumarill() {
        super(100, 80, 50, 60, 80, 50, "WATER", "FAIRY", "Azumarill");
    }
}
class Sudowoodo extends Pokemon {
    public Sudowoodo() {
        super(70, 115, 100, 30, 65, 30, "ROCK", "NA", "Sudowoodo");
    }
}
class Politoed extends Pokemon {
    public Politoed() {
        super(90, 75, 75, 90, 100, 70, "WATER", "NA", "Politoed");
    }
}
class Hoppip extends Pokemon {
    public Hoppip() {
        super(35, 40, 35, 35, 55, 50, "GRASS", "FLYING", "Hoppip");
    }
}
class Skiploom extends Pokemon {
    public Skiploom() {
        super(55, 50, 45, 45, 65, 80, "GRASS", "FLYING", "Skiploom");
    }
}
class Jumpluff extends Pokemon {
    public Jumpluff() {
        super(75, 70, 55, 55, 95, 110, "GRASS", "FLYING", "Jumpluff");
    }
}
class Aipom extends Pokemon {
    public Aipom() {
        super(55, 55, 70, 40, 55, 85, "NORMAL", "NA", "Aipom");
    }
}
class Sunkern extends Pokemon {
    public Sunkern() {
        super(30, 30, 30, 30, 30, 30, "GRASS", "NA", "Sunkern");
    }
}
class Sunflora extends Pokemon {
    public Sunflora() {
        super(75, 55, 75, 105, 85, 30, "GRASS", "NA", "Sunflora");
    }
}
class Yanma extends Pokemon {
    public Yanma() {
        super(65, 45, 65, 75, 45, 95, "BUG", "FLYING", "Yanma");
    }
}
class Wooper extends Pokemon {
    public Wooper() {
        super(55, 45, 45, 25, 25, 15, "WATER", "GROUND", "Wooper");
    }
}
class Quagsire extends Pokemon {
    public Quagsire() {
        super(95, 85, 85, 65, 65, 35, "WATER", "GROUND", "Quagsire");
    }
}
class Espeon extends Pokemon {
    public Espeon() {
        super(65, 60, 65, 130, 95, 110, "PSYCHIC", "NA", "Espeon");
    }
}
class Umbreon extends Pokemon {
    public Umbreon() {
        super(95, 110, 65, 60, 130, 65, "DARK", "NA", "Umbreon");
    }
}
class Murkrow extends Pokemon {
    public Murkrow() {
        super(60, 42, 85, 85, 42, 91, "DARK", "FLYING", "Murkrow");
    }
}
class Slowking extends Pokemon {
    public Slowking() {
        super(95, 80, 75, 100, 110, 30, "WATER", "PSYCHIC", "Slowking");
    }
}
class SlowkingGalarian extends Pokemon {
    public SlowkingGalarian() {
        super(95, 80, 65, 110, 110, 30, "POISON", "PSYCHIC", "Galarian Slowking");
    }
}
class Misdreavus extends Pokemon {
    public Misdreavus() {
        super(60, 60, 60, 85, 85, 85, "GHOST", "NA", "Misdreavus");
    }
}
class Unown extends Pokemon {
    public Unown() {
        super(48, 48, 72, 72, 48, 48, "PSYCHIC", "NA", "Unown");
    }
}
class Wobbuffet extends Pokemon {
    public Wobbuffet() {
        super(190, 58, 33, 33, 58, 33, "PSYCHIC", "NA", "Wobbuffet");
    }
}
class Girafarig extends Pokemon {
    public Girafarig() {
        super(70, 65, 80, 90, 65, 85, "NORMAL", "PSYCHIC", "Girafarig");
    }
}
class Pineco extends Pokemon {
    public Pineco() {
        super(50, 90, 65, 35, 35, 15, "BUG", "NA", "Pineco");
    }
}
class Forretress extends Pokemon {
    public Forretress() {
        super(75, 140, 90, 60, 60, 40, "BUG", "STEEL", "Forretress");
    }
}
class Dunsparce extends Pokemon {
    public Dunsparce() {
        super(100, 70, 70, 65, 65, 45, "NORMAL", "NA", "Dunsparce");
    }
}
class Gligar extends Pokemon {
    public Gligar() {
        super(65, 105, 75, 35, 65, 85, "GROUND", "FLYING", "Gligar");
    }
}
class Steelix extends Pokemon {
    public Steelix() {
        super(75, 200, 85, 55, 65, 30, "STEEL", "GROUND", "Steelix");
    }
}
class SteelixMega extends Pokemon {
    public SteelixMega() {
        super(75, 230, 125, 55, 95, 30, "STEEL", "GROUND", "Mega Steelix");
    }
}
class Snubbull extends Pokemon {
    public Snubbull() {
        super(60, 50, 80, 40, 40, 30, "FAIRY", "NA", "Snubbull");
    }
}
class Granbull extends Pokemon {
    public Granbull() {
        super(90, 75, 120, 60, 60, 45, "FAIRY", "NA", "Granbull");
    }
}
class Qwilfish extends Pokemon {
    public Qwilfish() {
        super(65, 85, 95, 55, 55, 85, "WATER", "POISON", "Qwilfish");
    }
}
class QwilfishHisuian extends Pokemon {
    public QwilfishHisuian() {
        super(65, 85, 95, 55, 55, 85, "DARK", "POISON", "Hisuian Qwilfish");
    }
}
class Scizor extends Pokemon {
    public Scizor() {
        super(70, 100, 130, 55, 80, 65, "BUG", "STEEL", "Scizor");
    }
}
class ScizorMega extends Pokemon {
    public ScizorMega() {
        super(70, 140, 150, 65, 100, 75, "BUG", "STEEL", "Mega Scizor");
    }
}
class Shuckle extends Pokemon {
    public Shuckle() {
        super(20, 230, 10, 10, 230, 5, "BUG", "ROCK", "Shuckle");
    }
}
class Heracross extends Pokemon {
    public Heracross() {
        super(80, 75, 125, 40, 95, 85, "BUG", "FIGHTING", "Heracross");
    }
}
class HeracrossMega extends Pokemon {
    public HeracrossMega() {
        super(80, 115, 185, 40, 105, 75, "BUG", "FIGHTING", "Mega Heracross");
    }
}
class Sneasel extends Pokemon {
    public Sneasel() {
        super(55, 55, 95, 35, 75, 115, "DARK", "ICE", "Sneasel");
    }
}
class SneaselHisuian extends Pokemon {
    public SneaselHisuian() {
        super(55, 55, 95, 35, 75, 115, "POISON", "FIGHTING", "Hisuian Sneasel");
    }
}
class Teddiursa extends Pokemon {
    public Teddiursa() {
        super(60, 50, 80, 50, 50, 40, "NORMAL", "NA", "Teddiursa");
    }
}
class Ursaring extends Pokemon {
    public Ursaring() {
        super(90, 75, 130, 75, 75, 55, "NORMAL", "NA", "Ursaring");
    }
}
class Slugma extends Pokemon {
    public Slugma() {
        super(40, 40, 40, 70, 40, 20, "FIRE", "NA", "Slugma");
    }
}
class Magcargo extends Pokemon {
    public Magcargo() {
        super(60, 120, 50, 90, 80, 30, "FIRE", "ROCK", "Magcargo");
    }
}
class Swinub extends Pokemon {
    public Swinub() {
        super(50, 40, 50, 30, 30, 50, "ICE", "GROUND", "Swinub");
    }
}
class Piloswine extends Pokemon {
    public Piloswine() {
        super(100, 80, 100, 60, 60, 50, "ICE", "GROUND", "Piloswine");
    }
}
class Corsola extends Pokemon {
    public Corsola() {
        super(65, 95, 55, 65, 95, 35, "WATER", "ROCK", "Corsola");
    }
}
class CorsolaGalarian extends Pokemon {
    public CorsolaGalarian() {
        super(60, 100, 55, 65, 100, 30, "GHOST", "NA", "Galarian Corsola");
    }
}
class Remoraid extends Pokemon {
    public Remoraid() {
        super(35, 35, 65, 65, 35, 65, "WATER", "NA", "Remoraid");
    }
}
class Octillery extends Pokemon {
    public Octillery() {
        super(75, 75, 105, 105, 75, 45, "WATER", "NA", "Octillery");
    }
}
class Delibird extends Pokemon {
    public Delibird() {
        super(45, 45, 55, 65, 45, 75, "ICE", "FLYING", "Delibird");
    }
}
class Mantine extends Pokemon {
    public Mantine() {
        super(85, 70, 40, 80, 140, 70, "WATER", "FLYING", "Mantine");
    }
}
class Skarmory extends Pokemon {
    public Skarmory() {
        super(65, 140, 80, 40, 70, 70, "STEEL", "FLYING", "Skarmory");
    }
}
class Houndour extends Pokemon {
    public Houndour() {
        super(45, 30, 60, 80, 50, 65, "DARK", "FIRE", "Houndour");
    }
}
class Houndoom extends Pokemon {
    public Houndoom() {
        super(75, 50, 90, 110, 80, 95, "DARK", "FIRE", "Houndoom");
    }
}
class HoundoomMega extends Pokemon {
    public HoundoomMega() {
        super(75, 90, 90, 140, 90, 115, "DARK", "FIRE", "Mega Houndoom");
    }
}
class Kingdra extends Pokemon {
    public Kingdra() {
        super(75, 95, 95, 95, 95, 85, "WATER", "DRAGON", "Kingdra");
    }
}
class Phanpy extends Pokemon {
    public Phanpy() {
        super(90, 60, 60, 40, 40, 40, "GROUND", "NA", "Phanpy");
    }
}
class Donphan extends Pokemon {
    public Donphan() {
        super(90, 120, 120, 60, 60, 50, "GROUND", "NA", "Donphan");
    }
}
class Porygon2 extends Pokemon {
    public Porygon2() {
        super(85, 90, 80, 105, 95, 60, "NORMAL", "NA", "Porygon2");
    }
}
class Stantler extends Pokemon {
    public Stantler() {
        super(73, 62, 95, 85, 65, 85, "NORMAL", "NA", "Stantler");
    }
}
class Smeargle extends Pokemon {
    public Smeargle() {
        super(55, 35, 20, 20, 45, 75, "NORMAL", "NA", "Smeargle");
    }
}
class Tyrogue extends Pokemon {
    public Tyrogue() {
        super(35, 35, 35, 35, 35, 35, "FIGHTING", "NA", "Tyrogue");
    }
}
class Hitmontop extends Pokemon {
    public Hitmontop() {
        super(50, 95, 95, 35, 110, 70, "FIGHTING", "NA", "Hitmontop");
    }
}
class Smoochum extends Pokemon {
    public Smoochum() {
        super(45, 15, 30, 85, 65, 65, "ICE", "PSYCHIC", "Smoochum");
    }
}
class Elekid extends Pokemon {
    public Elekid() {
        super(45, 37, 63, 65, 55, 95, "ELECTRIC", "NA", "Elekid");
    }
}
class Magby extends Pokemon {
    public Magby() {
        super(45, 37, 75, 70, 55, 83, "FIRE", "NA", "Magby");
    }
}
class Miltank extends Pokemon {
    public Miltank() {
        super(95, 105, 80, 40, 70, 100, "NORMAL", "NA", "Miltank");
    }
}
class Blissey extends Pokemon {
    public Blissey() {
        super(255, 10, 10, 75, 135, 55, "NORMAL", "NA", "Blissey");
    }
}
class Raikou extends Pokemon {
    public Raikou() {
        super(90, 75, 85, 115, 100, 115, "ELECTRIC", "NA", "Raikou");
    }
}
class Entei extends Pokemon {
    public Entei() {
        super(115, 85, 115, 90, 75, 100, "FIRE", "NA", "Entei");
    }
}
class Suicune extends Pokemon {
    public Suicune() {
        super(100, 115, 75, 90, 115, 85, "WATER", "NA", "Suicune");
    }
}
class Larvitar extends Pokemon {
    public Larvitar() {
        super(50, 50, 64, 45, 50, 41, "ROCK", "GROUND", "Larvitar");
    }
}
class Pupitar extends Pokemon {
    public Pupitar() {
        super(70, 70, 84, 65, 70, 51, "ROCK", "GROUND", "Pupitar");
    }
}
class Tyranitar extends Pokemon {
    public Tyranitar() {
        super(100, 110, 134, 95, 100, 61, "ROCK", "DARK", "Tyranitar");
    }
}
class TyranitarMega extends Pokemon {
    public TyranitarMega() {
        super(100, 150, 164, 95, 120, 71, "ROCK", "DARK", "Mega Tyranitar");
    }
}
class Lugia extends Pokemon {
    public Lugia() {
        super(106, 130, 90, 90, 154, 110, "PSYCHIC", "FLYING", "Lugia");
    }
}
class Hooh extends Pokemon {
    public Hooh() {
        super(106, 90, 130, 110, 154, 90, "FIRE", "FLYING", "Ho-oh");
    }
}
class Celebi extends Pokemon {
    public Celebi() {
        super(100, 100, 100, 100, 100, 100, "PSYCHIC", "GRASS", "Celebi");
    }
}
class Treecko extends Pokemon {
    public Treecko() {
        super(40, 35, 45, 65, 55, 70, "GRASS", "NA", "Treecko");
    }
}
class Grovyle extends Pokemon {
    public Grovyle() {
        super(50, 45, 65, 85, 65, 95, "GRASS", "NA", "Grovyle");
    }
}
class Sceptile extends Pokemon {
    public Sceptile() {
        super(70, 65, 85, 105, 85, 120, "GRASS", "NA", "Sceptile");
    }
}
class SceptileMega extends Pokemon {
    public SceptileMega() {
        super(70, 75, 110, 145, 85, 145, "GRASS", "DRAGON", "Mega Sceptile");
    }
}
class Torchic extends Pokemon {
    public Torchic() {
        super(45, 40, 60, 70, 50, 45, "FIRE", "NA", "Torchic");
    }
}
class Combusken extends Pokemon {
    public Combusken() {
        super(60, 60, 85, 85, 60, 55, "FIRE", "FIGHTING", "Combusken");
    }
}
class Blaziken extends Pokemon {
    public Blaziken() {
        super(80, 70, 120, 110, 70, 80, "FIRE", "FIGHTING", "Blaziken");
    }
}
class BlazikenMega extends Pokemon {
    public BlazikenMega() {
        super(80, 80, 160, 130, 80, 100, "FIRE", "FIGHTING", "Mega Blaziken");
    }
}
class Mudkip extends Pokemon {
    public Mudkip() {
        super(50, 50, 70, 50, 50, 40, "WATER", "NA", "Mudkip");
    }
}
class Marshtomp extends Pokemon {
    public Marshtomp() {
        super(70, 70, 85, 60, 70, 50, "WATER", "GROUND", "Marshtomp");
    }
}
class Swampert extends Pokemon {
    public Swampert() {
        super(100, 90, 110, 85, 90, 60, "WATER", "GROUND", "Swampert");
    }
}
class SwampertMega extends Pokemon {
    public SwampertMega() {
        super(100, 110, 150, 95, 110, 70, "WATER", "GROUND", "Mega Swampert");
    }
}
class Poochyena extends Pokemon {
    public Poochyena() {
        super(35, 35, 55, 30, 30, 35, "DARK", "NA", "Poochyena");
    }
}
class Mightyena extends Pokemon {
    public Mightyena() {
        super(70, 70, 90, 60, 60, 70, "DARK", "NA", "Mightyena");
    }
}
class Zigzagoon extends Pokemon {
    public Zigzagoon() {
        super(38, 41, 30, 30, 41, 60, "NORMAL", "NA", "Zigzagoon");
    }
}
class ZigzagoonGalarian extends Pokemon {
    public ZigzagoonGalarian() {
        super(38, 41, 30, 30, 41, 60, "DARK", "NORMAL", "Galarian Zigzagoon");
    }
}
class Linoone extends Pokemon {
    public Linoone() {
        super(78, 61, 70, 50, 61, 100, "NORMAL", "NA", "Linoone");
    }
}
class LinooneGalarian extends Pokemon {
    public LinooneGalarian() {
        super(78, 61, 70, 50, 61, 100, "DARK", "NORMAL", "Galarian Linoone");
    }
}
class Wurmple extends Pokemon {
    public Wurmple() {
        super(45, 35, 45, 20, 30, 20, "BUG", "NA", "Wurmple");
    }
}
class Silcoon extends Pokemon {
    public Silcoon() {
        super(50, 55, 35, 25, 25, 15, "BUG", "NA", "Silcoon");
    }
}
class Beautifly extends Pokemon {
    public Beautifly() {
        super(60, 50, 70, 100, 50, 65, "BUG", "FLYING", "Beautifly");
    }
}
class Cascoon extends Pokemon {
    public Cascoon() {
        super(50, 55, 35, 25, 25, 15, "BUG", "NA", "Cascoon");
    }
}
class Dustox extends Pokemon {
    public Dustox() {
        super(60, 70, 50, 50, 90, 65, "BUG", "POISON", "Dustox");
    }
}
class Lotad extends Pokemon {
    public Lotad() {
        super(40, 30, 30, 40, 50, 30, "WATER", "GRASS", "Lotad");
    }
}
class Lombre extends Pokemon {
    public Lombre() {
        super(60, 50, 50, 60, 70, 50, "WATER", "GRASS", "Lombre");
    }
}
class Ludicolo extends Pokemon {
    public Ludicolo() {
        super(80, 70, 70, 90, 100, 70, "WATER", "GRASS", "Ludicolo");
    }
}
class Seedot extends Pokemon {
    public Seedot() {
        super(40, 50, 40, 30, 30, 30, "GRASS", "NA", "Seedot");
    }
}
class Nuzleaf extends Pokemon {
    public Nuzleaf() {
        super(70, 40, 70, 60, 40, 60, "GRASS", "DARK", "Nuzleaf");
    }
}
class Shiftry extends Pokemon {
    public Shiftry() {
        super(90, 60, 100, 90, 60, 80, "GRASS", "DARK", "Shiftry");
    }
}
class Taillow extends Pokemon {
    public Taillow() {
        super(40, 30, 55, 30, 30, 85, "NORMAL", "FLYING", "Taillow");
    }
}
class Swellow extends Pokemon {
    public Swellow() {
        super(60, 60, 85, 75, 50, 125, "NORMAL", "FLYING", "Swellow");
    }
}
class Wingull extends Pokemon {
    public Wingull() {
        super(40, 30, 30, 55, 30, 85, "WATER", "FLYING", "Wingull");
    }
}
class Pelipper extends Pokemon {
    public Pelipper() {
        super(60, 100, 50, 95, 70, 65, "WATER", "FLYING", "Pelipper");
    }
}
class Ralts extends Pokemon {
    public Ralts() {
        super(28, 25, 25, 45, 35, 40, "PSYCHIC", "FAIRY", "Ralts");
    }
}
class Kirlia extends Pokemon {
    public Kirlia() {
        super(38, 35, 35, 65, 55, 50, "PSYCHIC", "FAIRY", "Kirlia");
    }
}
class Gardevoir extends Pokemon {
    public Gardevoir() {
        super(68, 65, 65, 125, 115, 80, "PSYCHIC", "FAIRY", "Gardevoir");
    }
}
class GardevoirMega extends Pokemon {
    public GardevoirMega() {
        super(68, 65, 85, 165, 135, 100, "PSYCHIC", "FAIRY", "Mega Gardevoir");
    }
}
class Surskit extends Pokemon {
    public Surskit() {
        super(40, 32, 30, 50, 52, 65, "BUG", "WATER", "Surskit");
    }
}
class Masquerain extends Pokemon {
    public Masquerain() {
        super(70, 62, 60, 100, 82, 80, "BUG", "FLYING", "Masquerain");
    }
}
class Shroomish extends Pokemon {
    public Shroomish() {
        super(60, 60, 40, 40, 60, 35, "GRASS", "NA", "Shroomish");
    }
}
class Breloom extends Pokemon {
    public Breloom() {
        super(60, 80, 130, 60, 60, 70, "GRASS", "FIGHTING", "Breloom");
    }
}
class Slakoth extends Pokemon {
    public Slakoth() {
        super(60, 60, 60, 35, 35, 30, "NORMAL", "NA", "Slakoth");
    }
}
class Vigoroth extends Pokemon {
    public Vigoroth() {
        super(80, 80, 80, 55, 55, 90, "NORMAL", "NA", "Vigoroth");
    }
}
class Slaking extends Pokemon {
    public Slaking() {
        super(150, 100, 160, 95, 65, 100, "NORMAL", "NA", "Slaking");
    }
}
class Nincada extends Pokemon {
    public Nincada() {
        super(31, 90, 45, 30, 30, 40, "BUG", "GROUND", "Nincada");
    }
}
class Ninjask extends Pokemon {
    public Ninjask() {
        super(61, 45, 90, 50, 50, 160, "BUG", "FLYING", "Ninjask");
    }
}
class Shedinja extends Pokemon {
    public Shedinja() {
        super(1, 45, 90, 30, 30, 40, "BUG", "GHOST", "Shedinja");
    }
}
class Whismur extends Pokemon {
    public Whismur() {
        super(64, 23, 51, 51, 23, 28, "NORMAL", "NA", "Whismur");
    }
}
class Loudred extends Pokemon {
    public Loudred() {
        super(84, 43, 71, 71, 43, 48, "NORMAL", "NA", "Loudred");
    }
}
class Exploud extends Pokemon {
    public Exploud() {
        super(104, 63, 91, 91, 73, 68, "NORMAL", "NA", "Exploud");
    }
}
class Makuhita extends Pokemon {
    public Makuhita() {
        super(72, 30, 60, 20, 30, 25, "FIGHTING", "NA", "Makuhita");
    }
}
class Hariyama extends Pokemon {
    public Hariyama() {
        super(144, 60, 120, 40, 60, 50, "FIGHTING", "NA", "Hariyama");
    }
}
class Azurill extends Pokemon {
    public Azurill() {
        super(50, 40, 20, 20, 40, 20, "NORMAL", "FAIRY", "Azurill");
    }
}
class Nosepass extends Pokemon {
    public Nosepass() {
        super(30, 135, 45, 45, 90, 30, "ROCK", "NA", "Nosepass");
    }
}
class Skitty extends Pokemon {
    public Skitty() {
        super(50, 45, 45, 35, 35, 50, "NORMAL", "NA", "Skitty");
    }
}
class Delcatty extends Pokemon {
    public Delcatty() {
        super(70, 65, 65, 55, 55, 90, "NORMAL", "NA", "Delcatty");
    }
}
class Sableye extends Pokemon {
    public Sableye() {
        super(50, 75, 75, 65, 65, 50, "DARK", "GHOST", "Sableye");
    }
}
class SableyeMega extends Pokemon {
    public SableyeMega() {
        super(50, 125, 85, 85, 115, 20, "DARK", "GHOST", "Mega Sableye");
    }
}
class Mawile extends Pokemon {
    public Mawile() {
        super(50, 85, 85, 55, 55, 50, "STEEL", "FAIRY", "Mawile");
    }
}
class MawileMega extends Pokemon {
    public MawileMega() {
        super(50, 125, 105, 55, 95, 50, "STEEL", "FAIRY", "Mega Mawile");
    }
}
class Aron extends Pokemon {
    public Aron() {
        super(50, 100, 70, 40, 40, 30, "STEEL", "ROCK", "Aron");
    }
}
class Lairon extends Pokemon {
    public Lairon() {
        super(60, 140, 90, 50, 50, 40, "STEEL", "ROCK", "Lairon");
    }
}
class Aggron extends Pokemon {
    public Aggron() {
        super(70, 180, 110, 60, 60, 50, "STEEL", "ROCK", "Aggron");
    }
}
class AggronMega extends Pokemon {
    public AggronMega() {
        super(70, 230, 140, 60, 80, 50, "STEEL", "NA", "Mega Aggron");
    }
}
class Meditite extends Pokemon {
    public Meditite() {
        super(30, 55, 40, 40, 55, 60, "FIGHTING", "PSYCHIC", "Meditite");
    }
}
class Medicham extends Pokemon {
    public Medicham() {
        super(60, 75, 60, 60, 75, 80, "FIGHTING", "PSYCHIC", "Medicham");
    }
}
class MedichamMega extends Pokemon {
    public MedichamMega() {
        super(60, 85, 100, 80, 85, 100, "FIGHTING", "PSYCHIC", "Mega Medicham");
    }
}
class Electrike extends Pokemon {
    public Electrike() {
        super(40, 40, 45, 65, 40, 65, "ELECTRIC", "NA", "Electrike");
    }
}
class Manectric extends Pokemon {
    public Manectric() {
        super(70, 60, 75, 105, 60, 105, "ELECTRIC", "NA", "Manectric");
    }
}
class ManectricMega extends Pokemon {
    public ManectricMega() {
        super(70, 80, 75, 135, 80, 135, "ELECTRIC", "NA", "Mega Manectric");
    }
}
class Plusle extends Pokemon {
    public Plusle() {
        super(60, 40, 50, 85, 75, 95, "ELECTRIC", "NA", "Plusle");
    }
}
class Minun extends Pokemon {
    public Minun() {
        super(60, 50, 40, 75, 85, 95, "ELECTRIC", "NA", "Minun");
    }
}
class Volbeat extends Pokemon {
    public Volbeat() {
        super(65, 75, 73, 47, 85, 85, "BUG", "NA", "Volbeat");
    }
}
class Illumise extends Pokemon {
    public Illumise() {
        super(65, 75, 47, 73, 85, 85, "BUG", "NA", "Illumise");
    }
}
class Roselia extends Pokemon {
    public Roselia() {
        super(50, 45, 60, 100, 80, 65, "GRASS", "POISON", "Roselia");
    }
}
class Gulpin extends Pokemon {
    public Gulpin() {
        super(70, 53, 43, 43, 53, 40, "POISON", "NA", "Gulpin");
    }
}
class Swalot extends Pokemon {
    public Swalot() {
        super(100, 83, 73, 73, 83, 55, "POISON", "NA", "Swalot");
    }
}
class Carvanha extends Pokemon {
    public Carvanha() {
        super(45, 20, 90, 65, 20, 65, "WATER", "DARK", "Carvanha");
    }
}
class Sharpedo extends Pokemon {
    public Sharpedo() {
        super(70, 40, 120, 95, 40, 95, "WATER", "DARK", "Sharpedo");
    }
}
class SharpedoMega extends Pokemon {
    public SharpedoMega() {
        super(70, 70, 140, 110, 65, 105, "WATER", "DARK", "Mega Sharpedo");
    }
}
class Wailmer extends Pokemon {
    public Wailmer() {
        super(130, 35, 70, 70, 35, 60, "WATER", "NA", "Wailmer");
    }
}
class Wailord extends Pokemon {
    public Wailord() {
        super(170, 45, 90, 90, 45, 60, "WATER", "NA", "Wailord");
    }
}
class Numel extends Pokemon {
    public Numel() {
        super(60, 40, 60, 65, 45, 35, "FIRE", "GROUND", "Numel");
    }
}
class Camerupt extends Pokemon {
    public Camerupt() {
        super(70, 70, 100, 105, 75, 40, "FIRE", "GROUND", "Camerupt");
    }
}
class CameruptMega extends Pokemon {
    public CameruptMega() {
        super(70, 100, 120, 145, 105, 20, "FIRE", "GROUND", "Mega Camerupt");
    }
}
class Torkoal extends Pokemon {
    public Torkoal() {
        super(70, 140, 85, 85, 70, 20, "FIRE", "NA", "Torkoal");
    }
}
class Spoink extends Pokemon {
    public Spoink() {
        super(60, 35, 25, 70, 80, 60, "PSYCHIC", "NA", "Spoink");
    }
}
class Grumpig extends Pokemon {
    public Grumpig() {
        super(80, 65, 45, 90, 110, 80, "PSYCHIC", "NA", "Grumpig");
    }
}
class Spinda extends Pokemon {
    public Spinda() {
        super(60, 60, 60, 60, 60, 60, "NORMAL", "NA", "Spinda");
    }
}
class Trapinch extends Pokemon {
    public Trapinch() {
        super(45, 45, 100, 45, 45, 10, "GROUND", "NA", "Trapinch");
    }
}
class Vibrava extends Pokemon {
    public Vibrava() {
        super(50, 50, 70, 50, 50, 70, "GROUND", "DRAGON", "Vibrava");
    }
}
class Flygon extends Pokemon {
    public Flygon() {
        super(80, 80, 100, 80, 80, 100, "GROUND", "DRAGON", "Flygon");
    }
}
class Cacnea extends Pokemon {
    public Cacnea() {
        super(50, 40, 85, 85, 40, 35, "GRASS", "NA", "Cacnea");
    }
}
class Cacturne extends Pokemon {
    public Cacturne() {
        super(70, 60, 115, 115, 60, 55, "GRASS", "DARK", "Cacturne");
    }
}
class Swablu extends Pokemon {
    public Swablu() {
        super(45, 60, 40, 40, 75, 50, "NORMAL", "FLYING", "Swablu");
    }
}
class Altaria extends Pokemon {
    public Altaria() {
        super(75, 90, 70, 70, 105, 80, "DRAGON", "FLYING", "Altaria");
    }
}
class AltariaMega extends Pokemon {
    public AltariaMega() {
        super(75, 110, 110, 110, 105, 80, "DRAGON", "FAIRY", "Mega Altaria");
    }
}
class Zangoose extends Pokemon {
    public Zangoose() {
        super(73, 60, 115, 60, 60, 90, "NORMAL", "NA", "Zangoose");
    }
}
class Seviper extends Pokemon {
    public Seviper() {
        super(73, 60, 100, 100, 60, 65, "POISON", "NA", "Seviper");
    }
}
class Lunatone extends Pokemon {
    public Lunatone() {
        super(90, 65, 55, 95, 85, 70, "ROCK", "PSYCHIC", "Lunatone");
    }
}
class Solrock extends Pokemon {
    public Solrock() {
        super(90, 85, 95, 55, 65, 70, "ROCK", "PSYCHIC", "Solrock");
    }
}
class Barboach extends Pokemon {
    public Barboach() {
        super(50, 43, 48, 46, 41, 60, "WATER", "GROUND", "Barboach");
    }
}
class Whiscash extends Pokemon {
    public Whiscash() {
        super(110, 73, 78, 76, 71, 60, "WATER", "GROUND", "Whiscash");
    }
}
class Corphish extends Pokemon {
    public Corphish() {
        super(43, 65, 80, 50, 35, 35, "WATER", "NA", "Corphish");
    }
}
class Crawdaunt extends Pokemon {
    public Crawdaunt() {
        super(63, 85, 120, 90, 55, 55, "WATER", "DARK", "Crawdaunt");
    }
}
class Baltoy extends Pokemon {
    public Baltoy() {
        super(40, 55, 40, 40, 70, 55, "GROUND", "PSYCHIC", "Baltoy");
    }
}
class Claydol extends Pokemon {
    public Claydol() {
        super(60, 105, 70, 70, 120, 75, "GROUND", "PSYCHIC", "Claydol");
    }
}
class Lileep extends Pokemon {
    public Lileep() {
        super(66, 77, 41, 61, 87, 23, "ROCK", "GRASS", "Lileep");
    }
}
class Cradily extends Pokemon {
    public Cradily() {
        super(86, 97, 81, 81, 107, 43, "ROCK", "GRASS", "Cradily");
    }
}
class Anorith extends Pokemon {
    public Anorith() {
        super(45, 50, 95, 40, 50, 75, "ROCK", "BUG", "Anorith");
    }
}
class Armaldo extends Pokemon {
    public Armaldo() {
        super(75, 100, 125, 70, 80, 45, "ROCK", "BUG", "Armaldo");
    }
}
class Feebas extends Pokemon {
    public Feebas() {
        super(20, 20, 15, 10, 55, 80, "WATER", "NA", "Feebas");
    }
}
class Milotic extends Pokemon {
    public Milotic() {
        super(95, 79, 60, 100, 125, 81, "WATER", "NA", "Milotic");
    }
}
class Castform extends Pokemon {
    public Castform() {
        super(70, 70, 70, 70, 70, 70, "NORMAL", "NA", "Castform");
    }
}
class CastformSunny extends Pokemon {
    public CastformSunny() {
        super(70, 70, 70, 70, 70, 70, "FIRE", "NA", "Castform Sunny Form");
    }
}
class CastformRainy extends Pokemon {
    public CastformRainy() {
        super(70, 70, 70, 70, 70, 70, "WATER", "NA", "Castform Rainy Form");
    }
}
class CastformSnowy extends Pokemon {
    public CastformSnowy() {
        super(70, 70, 70, 70, 70, 70, "ICE", "NA", "Castform Snowy Form");
    }
}
class Kecleon extends Pokemon {
    public Kecleon() {
        super(60, 70, 90, 60, 120, 40, "NORMAL", "NA", "Kecleon");
    }
}
class Shuppet extends Pokemon {
    public Shuppet() {
        super(44, 35, 75, 63, 33, 45, "GHOST", "NA", "Shuppet");
    }
}
class Banette extends Pokemon {
    public Banette() {
        super(64, 65, 115, 83, 63, 65, "GHOST", "NA", "Banette");
    }
}
class BanetteMega extends Pokemon {
    public BanetteMega() {
        super(64, 75, 165, 93, 83, 75, "GHOST", "NA", "Mega Banette");
    }
}
class Duskull extends Pokemon {
    public Duskull() {
        super(20, 90, 40, 30, 90, 25, "GHOST", "NA", "Duskull");
    }
}
class Dusclops extends Pokemon {
    public Dusclops() {
        super(40, 130, 70, 60, 130, 25, "GHOST", "NA", "Dusclops");
    }
}
class Tropius extends Pokemon {
    public Tropius() {
        super(99, 83, 68, 72, 87, 51, "GRASS", "FLYING", "Tropius");
    }
}
class Chimecho extends Pokemon {
    public Chimecho() {
        super(75, 80, 50, 95, 90, 65, "PSYCHIC", "NA", "Chimecho");
    }
}
class Absol extends Pokemon {
    public Absol() {
        super(65, 60, 130, 75, 60, 75, "DARK", "NA", "Absol");
    }
}
class AbsolMega extends Pokemon {
    public AbsolMega() {
        super(65, 60, 150, 115, 60, 115, "DARK", "NA", "Mega Absol");
    }
}
class Wynaut extends Pokemon {
    public Wynaut() {
        super(95, 48, 23, 23, 48, 23, "PSYCHIC", "NA", "Wynaut");
    }
}
class Snorunt extends Pokemon {
    public Snorunt() {
        super(50, 50, 50, 50, 50, 50, "ICE", "NA", "Snorunt");
    }
}
class Glalie extends Pokemon {
    public Glalie() {
        super(80, 80, 80, 80, 80, 80, "ICE", "NA", "Glalie");
    }
}
class GlalieMega extends Pokemon {
    public GlalieMega() {
        super(80, 80, 120, 120, 80, 100, "ICE", "NA", "Mega Glalie");
    }
}
class Spheal extends Pokemon {
    public Spheal() {
        super(70, 50, 40, 55, 50, 25, "ICE", "WATER", "Spheal");
    }
}
class Sealeo extends Pokemon {
    public Sealeo() {
        super(90, 70, 60, 75, 70, 45, "ICE", "WATER", "Sealeo");
    }
}
class Walrein extends Pokemon {
    public Walrein() {
        super(110, 90, 80, 95, 90, 65, "ICE", "WATER", "Walrein");
    }
}
class Clamperl extends Pokemon {
    public Clamperl() {
        super(35, 85, 64, 74, 55, 32, "WATER", "NA", "Clamperl");
    }
}
class Huntail extends Pokemon {
    public Huntail() {
        super(55, 105, 104, 94, 75, 52, "WATER", "NA", "Huntail");
    }
}
class Gorebyss extends Pokemon {
    public Gorebyss() {
        super(55, 105, 84, 114, 75, 52, "WATER", "NA", "Gorebyss");
    }
}
class Relicanth extends Pokemon {
    public Relicanth() {
        super(100, 130, 90, 45, 65, 55, "WATER", "ROCK", "Relicanth");
    }
}
class Luvdisc extends Pokemon {
    public Luvdisc() {
        super(43, 55, 30, 40, 65, 97, "WATER", "NA", "Luvdisc");
    }
}
class Bagon extends Pokemon {
    public Bagon() {
        super(45, 60, 75, 40, 30, 50, "DRAGON", "NA", "Bagon");
    }
}
class Shelgon extends Pokemon {
    public Shelgon() {
        super(65, 100, 95, 60, 50, 50, "DRAGON", "NA", "Shelgon");
    }
}
class Salamence extends Pokemon {
    public Salamence() {
        super(95, 80, 135, 110, 80, 100, "DRAGON", "FLYING", "Salamence");
    }
}
class SalamenceMega extends Pokemon {
    public SalamenceMega() {
        super(95, 130, 145, 120, 90, 120, "DRAGON", "FLYING", "Mega Salamence");
    }
}
class Beldum extends Pokemon {
    public Beldum() {
        super(40, 80, 55, 35, 60, 30, "STEEL", "PSYCHIC", "Beldum");
    }
}
class Metang extends Pokemon {
    public Metang() {
        super(60, 100, 75, 55, 80, 50, "STEEL", "PSYCHIC", "Metang");
    }
}
class Metagross extends Pokemon {
    public Metagross() {
        super(80, 130, 135, 95, 90, 70, "STEEL", "PSYCHIC", "Metagross");
    }
}
class MetagrossMega extends Pokemon {
    public MetagrossMega() {
        super(80, 150, 145, 105, 110, 110, "STEEL", "PSYCHIC", "Mega Metagross");
    }
}
class Regirock extends Pokemon {
    public Regirock() {
        super(80, 200, 100, 50, 100, 50, "ROCK", "NA", "Regirock");
    }
}
class Regice extends Pokemon {
    public Regice() {
        super(80, 100, 50, 100, 200, 50, "ICE", "NA", "Regice");
    }
}
class Registeel extends Pokemon {
    public Registeel() {
        super(80, 150, 75, 75, 150, 50, "STEEL", "NA", "Registeel");
    }
}
class Latias extends Pokemon {
    public Latias() {
        super(80, 90, 80, 110, 130, 110, "DRAGON", "PSYCHIC", "Latias");
    }
}
class LatiasMega extends Pokemon {
    public LatiasMega() {
        super(80, 120, 100, 140, 150, 110, "DRAGON", "PSYCHIC", "Mega Latias");
    }
}
class Latios extends Pokemon {
    public Latios() {
        super(80, 80, 90, 130, 110, 110, "DRAGON", "PSYCHIC", "Latios");
    }
}
class LatiosMega extends Pokemon {
    public LatiosMega() {
        super(80, 100, 130, 160, 120, 110, "DRAGON", "PSYCHIC", "Mega Latios");
    }
}
class Kyogre extends Pokemon {
    public Kyogre() {
        super(100, 90, 100, 150, 140, 90, "WATER", "NA", "Kyogre");
    }
}
class KyogrePrimal extends Pokemon {
    public KyogrePrimal() {
        super(100, 90, 150, 180, 160, 90, "WATER", "NA", "Primal Kyogre");
    }
}
class Groudon extends Pokemon {
    public Groudon() {
        super(100, 140, 150, 100, 90, 90, "GROUND", "NA", "Groudon");
    }
}
class GroudonPrimal extends Pokemon {
    public GroudonPrimal() {
        super(100, 160, 180, 150, 90, 90, "GROUND", "FIRE", "Primal Groudon");
    }
}
class Rayquaza extends Pokemon {
    public Rayquaza() {
        super(105, 90, 150, 150, 90, 95, "DRAGON", "FLYING", "Rayquaza");
    }
}
class RayquazaMega extends Pokemon {
    public RayquazaMega() {
        super(105, 100, 180, 180, 100, 115, "DRAGON", "FLYING", "Mega Rayquaza");
    }
}
class Jirachi extends Pokemon {
    public Jirachi() {
        super(100, 100, 100, 100, 100, 100, "STEEL", "PSYCHIC", "Jirachi");
    }
}
class DeoxysNormal extends Pokemon {
    public DeoxysNormal() {
        super(50, 50, 150, 150, 50, 150, "PSYCHIC", "NA", "Deoxys Normal Forme");
    }
}
class DeoxysAttack extends Pokemon {
    public DeoxysAttack() {
        super(50, 20, 180, 180, 20, 150, "PSYCHIC", "NA", "Deoxys Attack Forme");
    }
}
class DeoxysDefense extends Pokemon {
    public DeoxysDefense() {
        super(50, 160, 70, 70, 160, 90, "PSYCHIC", "NA", "Deoxys Defense Forme");
    }
}
class DeoxysSpeed extends Pokemon {
    public DeoxysSpeed() {
        super(50, 90, 95, 95, 90, 180, "PSYCHIC", "NA", "Deoxys Speed Forme");
    }
}
class Turtwig extends Pokemon {
    public Turtwig() {
        super(55, 64, 68, 45, 55, 31, "GRASS", "NA", "Turtwig");
    }
}
class Grotle extends Pokemon {
    public Grotle() {
        super(75, 85, 89, 55, 65, 36, "GRASS", "NA", "Grotle");
    }
}
class Torterra extends Pokemon {
    public Torterra() {
        super(95, 105, 109, 75, 85, 56, "GRASS", "GROUND", "Torterra");
    }
}
class Chimchar extends Pokemon {
    public Chimchar() {
        super(44, 44, 58, 58, 44, 61, "FIRE", "NA", "Chimchar");
    }
}
class Monferno extends Pokemon {
    public Monferno() {
        super(64, 52, 78, 78, 52, 81, "FIRE", "FIGHTING", "Monferno");
    }
}
class Infernape extends Pokemon {
    public Infernape() {
        super(76, 71, 104, 104, 71, 108, "FIRE", "FIGHTING", "Infernape");
    }
}
class Piplup extends Pokemon {
    public Piplup() {
        super(53, 53, 51, 61, 56, 40, "WATER", "NA", "Piplup");
    }
}
class Prinplup extends Pokemon {
    public Prinplup() {
        super(64, 68, 66, 81, 76, 50, "WATER", "NA", "Prinplup");
    }
}
class Empoleon extends Pokemon {
    public Empoleon() {
        super(84, 88, 86, 111, 101, 60, "WATER", "STEEL", "Empoleon");
    }
}
class Starly extends Pokemon {
    public Starly() {
        super(40, 30, 55, 30, 30, 60, "NORMAL", "FLYING", "Starly");
    }
}
class Staravia extends Pokemon {
    public Staravia() {
        super(55, 50, 75, 40, 40, 80, "NORMAL", "FLYING", "Staravia");
    }
}
class Staraptor extends Pokemon {
    public Staraptor() {
        super(85, 70, 120, 50, 60, 100, "NORMAL", "FLYING", "Staraptor");
    }
}
class Bidoof extends Pokemon {
    public Bidoof() {
        super(59, 40, 45, 35, 40, 31, "NORMAL", "NA", "Bidoof");
    }
}
class Bibarel extends Pokemon {
    public Bibarel() {
        super(79, 60, 85, 55, 60, 71, "NORMAL", "WATER", "Bibarel");
    }
}
class Kricketot extends Pokemon {
    public Kricketot() {
        super(37, 41, 25, 25, 41, 25, "BUG", "NA", "Kricketot");
    }
}
class Kricketune extends Pokemon {
    public Kricketune() {
        super(77, 51, 85, 55, 51, 65, "BUG", "NA", "Kricketune");
    }
}
class Shinx extends Pokemon {
    public Shinx() {
        super(45, 34, 65, 40, 34, 45, "ELECTRIC", "NA", "Shinx");
    }
}
class Luxio extends Pokemon {
    public Luxio() {
        super(60, 49, 85, 60, 49, 60, "ELECTRIC", "NA", "Luxio");
    }
}
class Luxray extends Pokemon {
    public Luxray() {
        super(80, 79, 120, 95, 79, 70, "ELECTRIC", "NA", "Luxray");
    }
}
class Budew extends Pokemon {
    public Budew() {
        super(40, 35, 30, 50, 70, 55, "GRASS", "POISON", "Budew");
    }
}
class Roserade extends Pokemon {
    public Roserade() {
        super(60, 65, 70, 125, 105, 90, "GRASS", "POISON", "Roserade");
    }
}
class Cranidos extends Pokemon {
    public Cranidos() {
        super(67, 40, 125, 30, 30, 58, "ROCK", "NA", "Cranidos");
    }
}
class Rampardos extends Pokemon {
    public Rampardos() {
        super(97, 60, 165, 65, 50, 58, "ROCK", "NA", "Rampardos");
    }
}
class Shieldon extends Pokemon {
    public Shieldon() {
        super(30, 118, 42, 42, 88, 30, "ROCK", "STEEL", "Shieldon");
    }
}
class Bastiodon extends Pokemon {
    public Bastiodon() {
        super(60, 168, 52, 47, 138, 30, "ROCK", "STEEL", "Bastiodon");
    }
}
class BurmyPlant extends Pokemon {
    public BurmyPlant() {
        super(40, 45, 29, 29, 45, 36, "BUG", "NA", "Burmy Plant Cloak");
    }
}
class BurmySandy extends Pokemon {
    public BurmySandy() {
        super(40, 45, 29, 29, 45, 36, "BUG", "NA", "Burmy Sandy Cloak");
    }
}
class BurmyTrash extends Pokemon {
    public BurmyTrash() {
        super(40, 45, 29, 29, 45, 36, "BUG", "NA", "Burmy Trash Cloak");
    }
}
class WormadamPlant extends Pokemon {
    public WormadamPlant() {
        super(60, 85, 59, 79, 105, 36, "BUG", "GRASS", "Wormadam Plant Cloak");
    }
}
class WormadamSandy extends Pokemon {
    public WormadamSandy() {
        super(60, 105, 79, 59, 85, 36, "BUG", "GROUND", "Wormadam Sandy Cloak");
    }
}
class WormadamTrash extends Pokemon {
    public WormadamTrash() {
        super(60, 95, 69, 69, 95, 36, "BUG", "STEEL", "Wormadam Trash Cloak");
    }
}
class Mothim extends Pokemon {
    public Mothim() {
        super(70, 50, 94, 94, 50, 66, "BUG", "FLYING", "Mothim");
    }
}
class Combee extends Pokemon {
    public Combee() {
        super(30, 42, 30, 30, 42, 70, "BUG", "FLYING", "Combee");
    }
}
class Vespiquen extends Pokemon {
    public Vespiquen() {
        super(70, 102, 80, 80, 102, 40, "BUG", "FLYING", "Vespiquen");
    }
}
class Pachirisu extends Pokemon {
    public Pachirisu() {
        super(60, 70, 45, 45, 90, 95, "ELECTRIC", "NA", "Pachirisu");
    }
}
class Buizel extends Pokemon {
    public Buizel() {
        super(55, 35, 65, 60, 30, 85, "WATER", "NA", "Buizel");
    }
}
class Floatzel extends Pokemon {
    public Floatzel() {
        super(85, 55, 105, 85, 50, 115, "WATER", "NA", "Floatzel");
    }
}
class Cherubi extends Pokemon {
    public Cherubi() {
        super(45, 45, 35, 62, 53, 35, "GRASS", "NA", "Cherubi");
    }
}
class Cherrim extends Pokemon {
    public Cherrim() {
        super(70, 70, 60, 87, 78, 85, "GRASS", "NA", "Cherrim");
    }
}
class Shellos extends Pokemon {
    public Shellos() {
        super(76, 48, 48, 57, 62, 34, "WATER", "NA", "Shellos");
    }
}
class Gastrodon extends Pokemon {
    public Gastrodon() {
        super(111, 68, 83, 92, 82, 39, "WATER", "GROUND", "Gastrodon");
    }
}
class Ambipom extends Pokemon {
    public Ambipom() {
        super(75, 66, 100, 60, 66, 115, "NORMAL", "NA", "Ambipom");
    }
}
class Drifloon extends Pokemon {
    public Drifloon() {
        super(90, 34, 50, 60, 44, 70, "GHOST", "FLYING", "Drifloon");
    }
}
class Drifblim extends Pokemon {
    public Drifblim() {
        super(150, 44, 80, 90, 54, 80, "GHOST", "FLYING", "Drifblim");
    }
}
class Buneary extends Pokemon {
    public Buneary() {
        super(55, 44, 66, 44, 56, 85, "NORMAL", "NA", "Buneary");
    }
}
class Lopunny extends Pokemon {
    public Lopunny() {
        super(65, 84, 76, 54, 96, 105, "NORMAL", "NA", "Lopunny");
    }
}
class LopunnyMega extends Pokemon {
    public LopunnyMega() {
        super(65, 94, 136, 54, 96, 135, "NORMAL", "FIGHTING", "Mega Lopunny");
    }
}
class Mismagius extends Pokemon {
    public Mismagius() {
        super(60, 60, 60, 105, 105, 105, "GHOST", "NA", "Mismagius");
    }
}
class Honchkrow extends Pokemon {
    public Honchkrow() {
        super(100, 52, 125, 105, 52, 71, "DARK", "FLYING", "Honchkrow");
    }
}
class Glameow extends Pokemon {
    public Glameow() {
        super(49, 42, 55, 42, 37, 85, "NORMAL", "NA", "Glameow");
    }
}
class Purugly extends Pokemon {
    public Purugly() {
        super(71, 64, 82, 64, 59, 112, "NORMAL", "NA", "Purugly");
    }
}
class Chingling extends Pokemon {
    public Chingling() {
        super(45, 50, 30, 65, 50, 45, "PSYCHIC", "NA", "Chingling");
    }
}
class Stunky extends Pokemon {
    public Stunky() {
        super(63, 47, 63, 41, 41, 74, "POISON", "DARK", "Stunky");
    }
}
class Skuntank extends Pokemon {
    public Skuntank() {
        super(103, 67, 93, 71, 61, 84, "POISON", "DARK", "Skuntank");
    }
}
class Bronzor extends Pokemon {
    public Bronzor() {
        super(57, 86, 24, 24, 86, 23, "STEEL", "PSYCHIC", "Bronzor");
    }
}
class Bronzong extends Pokemon {
    public Bronzong() {
        super(67, 116, 89, 79, 116, 33, "STEEL", "PSYCHIC", "Bronzong");
    }
}
class Bonsly extends Pokemon {
    public Bonsly() {
        super(50, 95, 80, 10, 45, 10, "ROCK", "NA", "Bonsly");
    }
}
class MimeJr extends Pokemon {
    public MimeJr() {
        super(20, 45, 25, 70, 90, 60, "PSYCHIC", "FAIRY", "Mime Jr.");
    }
}
class Happiny extends Pokemon {
    public Happiny() {
        super(100, 5, 5, 15, 65, 30, "NORMAL", "NA", "Happiny");
    }
}
class Chatot extends Pokemon {
    public Chatot() {
        super(76, 45, 65, 92, 42, 91, "NORMAL", "FLYING", "Chatot");
    }
}
class Spiritomb extends Pokemon {
    public Spiritomb() {
        super(50, 108, 92, 92, 108, 35, "GHOST", "DARK", "Spiritomb");
    }
}
class Gible extends Pokemon {
    public Gible() {
        super(58, 45, 70, 40, 45, 42, "DRAGON", "GROUND", "Gible");
    }
}
class Gabite extends Pokemon {
    public Gabite() {
        super(68, 65, 90, 50, 55, 82, "DRAGON", "GROUND", "Gabite");
    }
}
class Garchomp extends Pokemon {
    public Garchomp() {
        super(108, 95, 130, 80, 85, 102, "DRAGON", "GROUND", "Garchomp");
    }
}
class GarchompMega extends Pokemon {
    public GarchompMega() {
        super(108, 115, 170, 120, 95, 92, "DRAGON", "GROUND", "Mega Garchomp");
    }
}
class Munchlax extends Pokemon {
    public Munchlax() {
        super(135, 40, 85, 40, 85, 5, "NORMAL", "NA", "Munchlax");
    }
}
class Riolu extends Pokemon {
    public Riolu() {
        super(40, 40, 70, 35, 40, 60, "FIGHTING", "NA", "Riolu");
    }
}
class Lucario extends Pokemon {
    public Lucario() {
        super(70, 70, 110, 115, 70, 90, "FIGHTING", "STEEL", "Lucario");
    }
}
class LucarioMega extends Pokemon {
    public LucarioMega() {
        super(70, 88, 145, 140, 70, 112, "FIGHTING", "STEEL", "Mega Lucario");
    }
}
class Hippopotas extends Pokemon {
    public Hippopotas() {
        super(68, 78, 72, 38, 42, 32, "GROUND", "NA", "Hippopotas");
    }
}
class Hippowdon extends Pokemon {
    public Hippowdon() {
        super(108, 118, 112, 68, 72, 47, "GROUND", "NA", "Hippowdon");
    }
}
class Skorupi extends Pokemon {
    public Skorupi() {
        super(40, 90, 50, 30, 55, 65, "POISON", "BUG", "Skorupi");
    }
}
class Drapion extends Pokemon {
    public Drapion() {
        super(70, 110, 90, 60, 75, 95, "POISON", "DARK", "Drapion");
    }
}
class Croagunk extends Pokemon {
    public Croagunk() {
        super(48, 40, 61, 61, 40, 50, "POISON", "FIGHTING", "Croagunk");
    }
}
class Toxicroak extends Pokemon {
    public Toxicroak() {
        super(83, 65, 106, 86, 65, 85, "POISON", "FIGHTING", "Toxicroak");
    }
}
class Carnivine extends Pokemon {
    public Carnivine() {
        super(74, 72, 100, 90, 72, 46, "GRASS", "NA", "Carnivine");
    }
}
class Finneon extends Pokemon {
    public Finneon() {
        super(49, 56, 49, 49, 61, 66, "WATER", "NA", "Finneon");
    }
}
class Lumineon extends Pokemon {
    public Lumineon() {
        super(69, 76, 69, 69, 86, 91, "WATER", "NA", "Lumineon");
    }
}
class Mantyke extends Pokemon {
    public Mantyke() {
        super(45, 50, 20, 60, 120, 50, "WATER", "FLYING", "Mantyke");
    }
}
class Snover extends Pokemon {
    public Snover() {
        super(60, 50, 62, 62, 60, 40, "GRASS", "ICE", "Snover");
    }
}
class Abomasnow extends Pokemon {
    public Abomasnow() {
        super(90, 75, 92, 92, 85, 60, "GRASS", "ICE", "Abomasnow");
    }
}
class AbomasnowMega extends Pokemon {
    public AbomasnowMega() {
        super(90, 105, 132, 132, 105, 30, "GRASS", "ICE", "Mega Abomasnow");
    }
}
class Weavile extends Pokemon {
    public Weavile() {
        super(70, 65, 120, 45, 85, 125, "DARK", "ICE", "Weavile");
    }
}
class Magnezone extends Pokemon {
    public Magnezone() {
        super(70, 115, 70, 130, 90, 60, "ELECTRIC", "STEEL", "Magnezone");
    }
}
class Lickilicky extends Pokemon {
    public Lickilicky() {
        super(110, 95, 85, 80, 95, 50, "NORMAL", "NA", "Lickilicky");
    }
}
class Rhyperior extends Pokemon {
    public Rhyperior() {
        super(115, 130, 140, 55, 55, 40, "GROUND", "ROCK", "Rhyperior");
    }
}
class Tangrowth extends Pokemon {
    public Tangrowth() {
        super(100, 125, 100, 110, 50, 50, "GRASS", "NA", "Tangrowth");
    }
}
class Electivire extends Pokemon {
    public Electivire() {
        super(75, 67, 123, 95, 85, 95, "ELECTRIC", "NA", "Electivire");
    }
}
class Magmortar extends Pokemon {
    public Magmortar() {
        super(75, 67, 95, 125, 95, 83, "FIRE", "NA", "Magmortar");
    }
}
class Togekiss extends Pokemon {
    public Togekiss() {
        super(85, 95, 50, 120, 115, 80, "FAIRY", "FLYING", "Togekiss");
    }
}
class Yanmega extends Pokemon {
    public Yanmega() {
        super(86, 86, 76, 116, 56, 95, "BUG", "FLYING", "Yanmega");
    }
}
class Leafeon extends Pokemon {
    public Leafeon() {
        super(65, 130, 110, 60, 65, 95, "GRASS", "NA", "Leafeon");
    }
}
class Glaceon extends Pokemon {
    public Glaceon() {
        super(65, 110, 60, 130, 95, 65, "ICE", "NA", "Glaceon");
    }
}
class Gliscor extends Pokemon {
    public Gliscor() {
        super(75, 125, 95, 45, 75, 95, "GROUND", "FLYING", "Gliscor");
    }
}
class Mamoswine extends Pokemon {
    public Mamoswine() {
        super(110, 80, 130, 70, 60, 80, "ICE", "GROUND", "Mamoswine");
    }
}
class PorygonZ extends Pokemon {
    public PorygonZ() {
        super(85, 70, 80, 135, 75, 90, "NORMAL", "NA", "Porygon-Z");
    }
}
class Gallade extends Pokemon {
    public Gallade() {
        super(68, 65, 125, 65, 115, 80, "PSYCHIC", "FIGHTING", "Gallade");
    }
}
class GalladeMega extends Pokemon {
    public GalladeMega() {
        super(68, 95, 165, 65, 115, 110, "PSYCHIC", "FIGHTING", "Mega Gallade");
    }
}
class Probopass extends Pokemon {
    public Probopass() {
        super(60, 145, 55, 75, 150, 40, "ROCK", "STEEL", "Probopass");
    }
}
class Dusknoir extends Pokemon {
    public Dusknoir() {
        super(45, 135, 100, 65, 135, 45, "GHOST", "NA", "Dusknoir");
    }
}
class Froslass extends Pokemon {
    public Froslass() {
        super(70, 70, 80, 80, 70, 110, "ICE", "GHOST", "Froslass");
    }
}
class Rotom extends Pokemon {
    public Rotom() {
        super(50, 77, 50, 95, 77, 91, "ELECTRIC", "GHOST", "Rotom");
    }
}
class RotomHeat extends Pokemon {
    public RotomHeat() {
        super(50, 107, 65, 105, 107, 86, "ELECTRIC", "FIRE", "Heat Rotom");
    }
}
class RotomWash extends Pokemon {
    public RotomWash() {
        super(50, 107, 65, 105, 107, 86, "ELECTRIC", "WATER", "Wash Rotom");
    }
}
class RotomFrost extends Pokemon {
    public RotomFrost() {
        super(50, 107, 65, 105, 107, 86, "ELECTRIC", "ICE", "Frost Rotom");
    }
}
class RotomFan extends Pokemon {
    public RotomFan() {
        super(50, 107, 65, 105, 107, 86, "ELECTRIC", "FLYING", "Fan Rotom");
    }
}
class RotomMow extends Pokemon {
    public RotomMow() {
        super(50, 107, 65, 105, 107, 86, "ELECTRIC", "GRASS", "Mow Rotom");
    }
}
class Uxie extends Pokemon {
    public Uxie() {
        super(75, 130, 75, 75, 130, 95, "PSYCHIC", "NA", "Uxie");
    }
}
class Mesprit extends Pokemon {
    public Mesprit() {
        super(80, 105, 105, 105, 105, 80, "PSYCHIC", "NA", "Mesprit");
    }
}
class Azelf extends Pokemon {
    public Azelf() {
        super(75, 70, 125, 125, 70, 115, "PSYCHIC", "NA", "Azelf");
    }
}
class Dialga extends Pokemon {
    public Dialga() {
        super(100, 120, 120, 150, 100, 90, "STEEL", "DRAGON", "Dialga");
    }
}
class DialgaOrigin extends Pokemon {
    public DialgaOrigin() {
        super(100, 120, 100, 150, 120, 90, "STEEL", "DRAGON", "Dialga Origin Forme");
    }
}
class Palkia extends Pokemon {
    public Palkia() {
        super(90, 100, 120, 150, 120, 100, "WATER", "DRAGON", "Palkia");
    }
}
class PalkiaOrigin extends Pokemon {
    public PalkiaOrigin() {
        super(90, 100, 100, 150, 120, 120, "WATER", "DRAGON", "Palkia Origin Forme");
    }
}
class Heatran extends Pokemon {
    public Heatran() {
        super(91, 106, 90, 130, 106, 77, "FIRE", "STEEL", "Heatran");
    }
}
class Regigigas extends Pokemon {
    public Regigigas() {
        super(110, 110, 160, 80, 110, 100, "NORMAL", "NA", "Regigigas");
    }
}
class GiratinaAltered extends Pokemon {
    public GiratinaAltered() {
        super(150, 120, 100, 100, 120, 90, "GHOST", "DRAGON", "Giratina Altered Forme");
    }
}
class GiratinaOrigin extends Pokemon {
    public GiratinaOrigin() {
        super(150, 100, 120, 120, 100, 90, "GHOST", "DRAGON", "Giratina Origin Forme");
    }
}
class Cresselia extends Pokemon {
    public Cresselia() {
        super(120, 120, 70, 75, 130, 85, "PSYCHIC", "NA", "Cresselia");
    }
}
class Phione extends Pokemon {
    public Phione() {
        super(80, 80, 80, 80, 80, 80, "WATER", "NA", "Phione");
    }
}
class Manaphy extends Pokemon {
    public Manaphy() {
        super(100, 100, 100, 100, 100, 100, "WATER", "NA", "Manaphy");
    }
}
class Darkrai extends Pokemon {
    public Darkrai() {
        super(70, 90, 90, 135, 90, 125, "DARK", "NA", "Darkrai");
    }
}
class ShayminLand extends Pokemon {
    public ShayminLand() {
        super(100, 100, 100, 100, 100, 100, "GRASS", "NA", "Shaymin Land Forme");
    }
}
class ShayminSky extends Pokemon {
    public ShayminSky() {
        super(100, 75, 103, 120, 75, 127, "GRASS", "FLYING", "Shaymin Sky Forme");
    }
}
class Arceus extends Pokemon {
    public Arceus() {
        super(120, 120, 120, 120, 120, 120, "NORMAL", "NA", "Arceus");
    }
}
class Victini extends Pokemon {
    public Victini() {
        super(100, 100, 100, 100, 100, 100, "PSYCHIC", "FIRE", "Victini");
    }
}
class Snivy extends Pokemon {
    public Snivy() {
        super(45, 55, 45, 45, 55, 63, "GRASS", "NA", "Snivy");
    }
}
class Servine extends Pokemon {
    public Servine() {
        super(60, 75, 60, 60, 75, 83, "GRASS", "NA", "Servine");
    }
}
class Serperior extends Pokemon {
    public Serperior() {
        super(75, 95, 75, 75, 95, 113, "GRASS", "NA", "Serperior");
    }
}
class Tepig extends Pokemon {
    public Tepig() {
        super(65, 45, 63, 45, 45, 45, "FIRE", "NA", "Tepig");
    }
}
class Pignite extends Pokemon {
    public Pignite() {
        super(90, 55, 93, 70, 55, 55, "FIRE", "FIGHTING", "Pignite");
    }
}
class Emboar extends Pokemon {
    public Emboar() {
        super(110, 65, 123, 100, 65, 65, "FIRE", "FIGHTING", "Emboar");
    }
}
class Oshawott extends Pokemon {
    public Oshawott() {
        super(55, 45, 55, 63, 45, 45, "WATER", "NA", "Oshawott");
    }
}
class Dewott extends Pokemon {
    public Dewott() {
        super(75, 60, 75, 83, 60, 60, "WATER", "NA", "Dewott");
    }
}
class Samurott extends Pokemon {
    public Samurott() {
        super(95, 85, 100, 108, 70, 70, "WATER", "NA", "Samurott");
    }
}
class SamurottHisuian extends Pokemon {
    public SamurottHisuian() {
        super(90, 80, 108, 100, 65, 85, "WATER", "DARK", "Hisuian Samurott");
    }
}
class Patrat extends Pokemon {
    public Patrat() {
        super(45, 39, 55, 35, 39, 42, "NORMAL", "NA", "Patrat");
    }
}
class Watchog extends Pokemon {
    public Watchog() {
        super(60, 69, 85, 60, 69, 77, "NORMAL", "NA", "Watchog");
    }
}
class Lillipup extends Pokemon {
    public Lillipup() {
        super(45, 45, 60, 25, 45, 55, "NORMAL", "NA", "Lillipup");
    }
}
class Herdier extends Pokemon {
    public Herdier() {
        super(65, 65, 80, 35, 65, 60, "NORMAL", "NA", "Herdier");
    }
}
class Stoutland extends Pokemon {
    public Stoutland() {
        super(85, 90, 110, 45, 90, 80, "NORMAL", "NA", "Stoutland");
    }
}
class Purrloin extends Pokemon {
    public Purrloin() {
        super(41, 37, 50, 50, 37, 66, "DARK", "NA", "Purrloin");
    }
}
class Liepard extends Pokemon {
    public Liepard() {
        super(64, 50, 88, 88, 50, 106, "DARK", "NA", "Liepard");
    }
}
class Pansage extends Pokemon {
    public Pansage() {
        super(50, 48, 53, 53, 48, 64, "GRASS", "NA", "Pansage");
    }
}
class Simisage extends Pokemon {
    public Simisage() {
        super(75, 63, 98, 98, 63, 101, "GRASS", "NA", "Simisage");
    }
}
class Pansear extends Pokemon {
    public Pansear() {
        super(50, 48, 53, 53, 48, 64, "FIRE", "NA", "Pansear");
    }
}
class Simisear extends Pokemon {
    public Simisear() {
        super(75, 63, 98, 98, 63, 101, "FIRE", "NA", "Simisear");
    }
}
class Panpour extends Pokemon {
    public Panpour() {
        super(50, 48, 53, 53, 48, 64, "WATER", "NA", "Panpour");
    }
}
class Simipour extends Pokemon {
    public Simipour() {
        super(75, 63, 98, 98, 63, 101, "WATER", "NA", "Simipour");
    }
}
class Munna extends Pokemon {
    public Munna() {
        super(76, 45, 25, 67, 55, 24, "PSYCHIC", "NA", "Munna");
    }
}
class Musharna extends Pokemon {
    public Musharna() {
        super(116, 85, 55, 107, 95, 29, "PSYCHIC", "NA", "Musharna");
    }
}
class Pidove extends Pokemon {
    public Pidove() {
        super(50, 50, 55, 36, 30, 43, "NORMAL", "FLYING", "Pidove");
    }
}
class Tranquill extends Pokemon {
    public Tranquill() {
        super(62, 62, 77, 50, 42, 65, "NORMAL", "FLYING", "Tranquill");
    }
}
class Unfezant extends Pokemon {
    public Unfezant() {
        super(80, 80, 115, 65, 55, 93, "NORMAL", "FLYING", "Unfezant");
    }
}
class Blitzle extends Pokemon {
    public Blitzle() {
        super(45, 32, 60, 50, 32, 76, "ELECTRIC", "NA", "Blitzle");
    }
}
class Zebstrika extends Pokemon {
    public Zebstrika() {
        super(75, 63, 100, 80, 63, 116, "ELECTRIC", "NA", "Zebstrika");
    }
}
class Roggenrola extends Pokemon {
    public Roggenrola() {
        super(55, 85, 75, 25, 25, 15, "ROCK", "NA", "Roggenrola");
    }
}
class Boldore extends Pokemon {
    public Boldore() {
        super(70, 105, 105, 50, 40, 20, "ROCK", "NA", "Boldore");
    }
}
class Gigalith extends Pokemon {
    public Gigalith() {
        super(85, 130, 135, 60, 80, 25, "ROCK", "NA", "Gigalith");
    }
}
class Woobat extends Pokemon {
    public Woobat() {
        super(65, 43, 45, 55, 43, 72, "PSYCHIC", "FLYING", "Woobat");
    }
}
class Swoobat extends Pokemon {
    public Swoobat() {
        super(67, 55, 57, 77, 55, 114, "PSYCHIC", "FLYING", "Swoobat");
    }
}
class Drilbur extends Pokemon {
    public Drilbur() {
        super(60, 40, 85, 30, 45, 68, "GROUND", "NA", "Drilbur");
    }
}
class Excadrill extends Pokemon {
    public Excadrill() {
        super(110, 60, 135, 50, 65, 88, "GROUND", "STEEL", "Excadrill");
    }
}
class Audino extends Pokemon {
    public Audino() {
        super(103, 86, 60, 60, 86, 50, "NORMAL", "NA", "Audino");
    }
}
class AudinoMega extends Pokemon {
    public AudinoMega() {
        super(103, 126, 60, 80, 126, 50, "NORMAL", "FAIRY", "Mega Audino");
    }
}
class Timburr extends Pokemon {
    public Timburr() {
        super(75, 55, 80, 25, 35, 35, "FIGHTING", "NA", "Timburr");
    }
}
class Gurdurr extends Pokemon {
    public Gurdurr() {
        super(85, 85, 105, 40, 50, 40, "FIGHTING", "NA", "Gurdurr");
    }
}
class Conkeldurr extends Pokemon {
    public Conkeldurr() {
        super(105, 95, 140, 55, 65, 45, "FIGHTING", "NA", "Conkeldurr");
    }
}
class Tympole extends Pokemon {
    public Tympole() {
        super(50, 40, 50, 50, 40, 64, "WATER", "NA", "Tympole");
    }
}
class Palpitoad extends Pokemon {
    public Palpitoad() {
        super(75, 55, 65, 65, 55, 69, "WATER", "GROUND", "Palpitoad");
    }
}
class Seismitoad extends Pokemon {
    public Seismitoad() {
        super(105, 75, 95, 85, 75, 74, "WATER", "GROUND", "Seismitoad");
    }
}
class Throh extends Pokemon {
    public Throh() {
        super(120, 85, 100, 30, 85, 45, "FIGHTING", "NA", "Throh");
    }
}
class Sawk extends Pokemon {
    public Sawk() {
        super(75, 75, 125, 30, 75, 85, "FIGHTING", "NA", "Sawk");
    }
}
class Sewaddle extends Pokemon {
    public Sewaddle() {
        super(45, 70, 53, 40, 60, 42, "BUG", "GRASS", "Sewaddle");
    }
}
class Swadloon extends Pokemon {
    public Swadloon() {
        super(55, 90, 63, 50, 80, 42, "BUG", "GRASS", "Swadloon");
    }
}
class Leavanny extends Pokemon {
    public Leavanny() {
        super(75, 80, 103, 70, 80, 92, "BUG", "GRASS", "Leavanny");
    }
}
class Venipede extends Pokemon {
    public Venipede() {
        super(30, 59, 45, 30, 39, 57, "BUG", "POISON", "Venipede");
    }
}
class Whirlipede extends Pokemon {
    public Whirlipede() {
        super(40, 99, 55, 40, 79, 47, "BUG", "POISON", "Whirlipede");
    }
}
class Scolipede extends Pokemon {
    public Scolipede() {
        super(60, 89, 100, 55, 69, 112, "BUG", "POISON", "Scolipede");
    }
}
class Cottonee extends Pokemon {
    public Cottonee() {
        super(40, 60, 27, 37, 50, 66, "GRASS", "FAIRY", "Cottonee");
    }
}
class Whimsicott extends Pokemon {
    public Whimsicott() {
        super(60, 85, 67, 77, 75, 116, "GRASS", "FAIRY", "Whimsicott");
    }
}
class Petilil extends Pokemon {
    public Petilil() {
        super(45, 50, 35, 70, 50, 30, "GRASS", "NA", "Petilil");
    }
}
class Lilligant extends Pokemon {
    public Lilligant() {
        super(70, 75, 60, 110, 75, 90, "GRASS", "NA", "Lilligant");
    }
}
class LilligantHisuian extends Pokemon {
    public LilligantHisuian() {
        super(70, 75, 105, 50, 75, 105, "GRASS", "FIGHTING", "Hisuian Lilligant");
    }
}
class BasculinRed extends Pokemon {
    public BasculinRed() {
        super(70, 65, 92, 80, 55, 98, "WATER", "NA", "Red-Striped Basculin");
    }
}
class BasculinBlue extends Pokemon {
    public BasculinBlue() {
        super(70, 65, 92, 80, 55, 98, "WATER", "NA", "Blue-Striped Basculin");
    }
}
class BasculinWhite extends Pokemon {
    public BasculinWhite() {
        super(70, 65, 92, 80, 55, 98, "WATER", "NA", "White-Striped Basculin");
    }
}
class Sandile extends Pokemon {
    public Sandile() {
        super(50, 35, 72, 35, 35, 65, "GROUND", "DARK", "Sandile");
    }
}
class Krokorok extends Pokemon {
    public Krokorok() {
        super(60, 45, 82, 45, 45, 74, "GROUND", "DARK", "Krokorok");
    }
}
class Krookodile extends Pokemon {
    public Krookodile() {
        super(95, 80, 117, 65, 70, 92, "GROUND", "DARK", "Krookodile");
    }
}
class Darumaka extends Pokemon {
    public Darumaka() {
        super(70, 45, 90, 15, 45, 50, "FIRE", "NA", "Darumaka");
    }
}
class DarumakaGalarian extends Pokemon {
    public DarumakaGalarian() {
        super(70, 45, 90, 15, 45, 50, "ICE", "NA", "Galarian Darumaka");
    }
}
class DarmanitanStandard extends Pokemon {
    public DarmanitanStandard() {
        super(105, 55, 140, 30, 55, 95, "FIRE", "NA", "Darmanitan Standard Mode");
    }
}
class DarmanitanZen extends Pokemon {
    public DarmanitanZen() {
        super(105, 105, 30, 140, 105, 55, "FIRE", "PSYCHIC", "Darmanitan Zen Mode");
    }
}
class DarmanitanGalarianStandard extends Pokemon {
    public DarmanitanGalarianStandard() {
        super(105, 55, 140, 30, 55, 95, "ICE", "NA", "Darmanitan Galarian Standard Mode");
    }
}
class DarmanitanGalarianZen extends Pokemon {
    public DarmanitanGalarianZen() {
        super(105, 55, 160, 30, 55, 135, "ICE", "FIRE", "Darmanitan Galarian Zen Mode");
    }
}
class Maractus extends Pokemon {
    public Maractus() {
        super(75, 67, 86, 106, 67, 60, "GRASS", "NA", "Maractus");
    }
}
class Dwebble extends Pokemon {
    public Dwebble() {
        super(50, 85, 65, 35, 35, 55, "BUG", "ROCK", "Dwebble");
    }
}
class Crustle extends Pokemon {
    public Crustle() {
        super(70, 125, 105, 65, 75, 45, "BUG", "ROCK", "Crustle");
    }
}
class Scraggy extends Pokemon {
    public Scraggy() {
        super(50, 70, 75, 35, 70, 48, "DARK", "FIGHTING", "Scraggy");
    }
}
class Scrafty extends Pokemon {
    public Scrafty() {
        super(65, 115, 90, 45, 115, 58, "DARK", "FIGHTING", "Scrafty");
    }
}
class Sigilyph extends Pokemon {
    public Sigilyph() {
        super(72, 80, 58, 103, 80, 97, "PSYCHIC", "FLYING", "Sigilyph");
    }
}
class Yamask extends Pokemon {
    public Yamask() {
        super(38, 85, 30, 55, 65, 30, "GHOST", "NA", "Yamask");
    }
}
class YamaskGalarian extends Pokemon {
    public YamaskGalarian() {
        super(38, 85, 55, 30, 65, 30, "GROUND", "GHOST", "Galarian Yamask");
    }
}
class Cofagrigus extends Pokemon {
    public Cofagrigus() {
        super(58, 145, 50, 95, 105, 30, "GHOST", "NA", "Cofagrigus");
    }
}
class Tirtouga extends Pokemon {
    public Tirtouga() {
        super(54, 103, 78, 53, 45, 22, "WATER", "ROCK", "Tirtouga");
    }
}
class Carracosta extends Pokemon {
    public Carracosta() {
        super(74, 133, 108, 83, 65, 32, "WATER", "ROCK", "Carracosta");
    }
}
class Archen extends Pokemon {
    public Archen() {
        super(55, 45, 112, 74, 45, 70, "ROCK", "FLYING", "Archen");
    }
}
class Archeops extends Pokemon {
    public Archeops() {
        super(75, 65, 140, 112, 65, 110, "ROCK", "FLYING", "Archeops");
    }
}
class Trubbish extends Pokemon {
    public Trubbish() {
        super(50, 62, 50, 40, 62, 65, "POISON", "NA", "Trubbish");
    }
}
class Garbodor extends Pokemon {
    public Garbodor() {
        super(80, 82, 95, 60, 82, 75, "POISON", "NA", "Garbodor");
    }
}
class Zorua extends Pokemon {
    public Zorua() {
        super(40, 40, 65, 80, 40, 65, "DARK", "NA", "Zorua");
    }
}
class ZoruaHisuian extends Pokemon {
    public ZoruaHisuian() {
        super(35, 40, 60, 85, 40, 70, "NORMAL", "GHOST", "Hisuian Zorua");
    }
}
class Zoroark extends Pokemon {
    public Zoroark() {
        super(60, 60, 105, 120, 60, 105, "DARK", "NA", "Zoroark");
    }
}
class ZoroarkHisuian extends Pokemon {
    public ZoroarkHisuian() {
        super(55, 60, 100, 125, 60, 110, "NORMAL", "GHOST", "Hisuian Zoroark");
    }
}
class Minccino extends Pokemon {
    public Minccino() {
        super(55, 40, 50, 40, 40, 75, "NORMAL", "NA", "Minccino");
    }
}
class Cinccino extends Pokemon {
    public Cinccino() {
        super(75, 60, 95, 65, 60, 115, "NORMAL", "NA", "Cinccino");
    }
}
class Gothita extends Pokemon {
    public Gothita() {
        super(45, 50, 30, 55, 65, 45, "PSYCHIC", "NA", "Gothita");
    }
}
class Gothorita extends Pokemon {
    public Gothorita() {
        super(60, 70, 45, 75, 85, 55, "PSYCHIC", "NA", "Gothorita");
    }
}
class Gothitelle extends Pokemon {
    public Gothitelle() {
        super(70, 95, 55, 95, 110, 65, "PSYCHIC", "NA", "Gothitelle");
    }
}
class Solosis extends Pokemon {
    public Solosis() {
        super(45, 40, 30, 105, 50, 20, "PSYCHIC", "NA", "Solosis");
    }
}
class Duosion extends Pokemon {
    public Duosion() {
        super(65, 50, 40, 125, 60, 30, "PSYCHIC", "NA", "Duosion");
    }
}
class Reuniclus extends Pokemon {
    public Reuniclus() {
        super(110, 75, 65, 125, 85, 30, "PSYCHIC", "NA", "Reuniclus");
    }
}
class Ducklett extends Pokemon {
    public Ducklett() {
        super(62, 50, 44, 44, 50, 55, "WATER", "FLYING", "Ducklett");
    }
}
class Swanna extends Pokemon {
    public Swanna() {
        super(75, 63, 87, 87, 63, 98, "WATER", "FLYING", "Swanna");
    }
}
class Vanillite extends Pokemon {
    public Vanillite() {
        super(36, 50, 50, 65, 60, 44, "ICE", "NA", "Vanillite");
    }
}
class Vanillish extends Pokemon {
    public Vanillish() {
        super(51, 65, 65, 80, 75, 59, "ICE", "NA", "Vanillish");
    }
}
class Vanilluxe extends Pokemon {
    public Vanilluxe() {
        super(71, 85, 95, 110, 95, 79, "ICE", "NA", "Vanilluxe");
    }
}
class Deerling extends Pokemon {
    public Deerling() {
        super(60, 50, 60, 40, 50, 75, "NORMAL", "GRASS", "Deerling");
    }
}
class Sawsbuck extends Pokemon {
    public Sawsbuck() {
        super(80, 70, 100, 60, 70, 95, "NORMAL", "GRASS", "Sawsbuck");
    }
}
class Emolga extends Pokemon {
    public Emolga() {
        super(55, 60, 75, 75, 60, 103, "ELECTRIC", "FLYING", "Emolga");
    }
}
class Karrablast extends Pokemon {
    public Karrablast() {
        super(50, 45, 75, 40, 45, 60, "BUG", "NA", "Karrablast");
    }
}
class Escavalier extends Pokemon {
    public Escavalier() {
        super(70, 105, 135, 60, 105, 20, "BUG", "STEEL", "Escavalier");
    }
}
class Foongus extends Pokemon {
    public Foongus() {
        super(69, 45, 55, 55, 55, 15, "GRASS", "POISON", "Foongus");
    }
}
class Amoonguss extends Pokemon {
    public Amoonguss() {
        super(114, 70, 85, 85, 80, 30, "GRASS", "POISON", "Amoonguss");
    }
}
class Frillish extends Pokemon {
    public Frillish() {
        super(55, 50, 40, 65, 85, 40, "WATER", "GHOST", "Frillish");
    }
}
class Jellicent extends Pokemon {
    public Jellicent() {
        super(100, 70, 60, 85, 105, 60, "WATER", "GHOST", "Jellicent");
    }
}
class Alomomola extends Pokemon {
    public Alomomola() {
        super(165, 80, 75, 40, 45, 65, "WATER", "NA", "Alomomola");
    }
}
class Joltik extends Pokemon {
    public Joltik() {
        super(50, 50, 47, 57, 50, 65, "BUG", "ELECTRIC", "Joltik");
    }
}
class Galvantula extends Pokemon {
    public Galvantula() {
        super(70, 60, 77, 97, 60, 108, "BUG", "ELECTRIC", "Galvantula");
    }
}
class Ferroseed extends Pokemon {
    public Ferroseed() {
        super(44, 91, 50, 24, 86, 10, "GRASS", "STEEL", "Ferroseed");
    }
}
class Ferrothorn extends Pokemon {
    public Ferrothorn() {
        super(74, 131, 94, 54, 116, 20, "GRASS", "STEEL", "Ferrothorn");
    }
}
class Klink extends Pokemon {
    public Klink() {
        super(40, 70, 55, 45, 60, 30, "STEEL", "NA", "Klink");
    }
}
class Klang extends Pokemon {
    public Klang() {
        super(60, 95, 80, 70, 85, 50, "STEEL", "NA", "Klang");
    }
}
class Klinklang extends Pokemon {
    public Klinklang() {
        super(60, 115, 100, 70, 85, 90, "STEEL", "NA", "Klinklang");
    }
}
class Tynamo extends Pokemon {
    public Tynamo() {
        super(35, 40, 55, 45, 40, 60, "ELECTRIC", "NA", "Tynamo");
    }
}
class Eelektrik extends Pokemon {
    public Eelektrik() {
        super(65, 70, 85, 75, 70, 40, "ELECTRIC", "NA", "Eelektrik");
    }
}
class Eelektross extends Pokemon {
    public Eelektross() {
        super(85, 80, 115, 105, 80, 50, "ELECTRIC", "NA", "Eelektross");
    }
}
class Elgyem extends Pokemon {
    public Elgyem() {
        super(55, 55, 55, 85, 55, 30, "PSYCHIC", "NA", "Elgyem");
    }
}
class Beheeyem extends Pokemon {
    public Beheeyem() {
        super(75, 75, 75, 125, 95, 40, "PSYCHIC", "NA", "Beheeyem");
    }
}
class Litwick extends Pokemon {
    public Litwick() {
        super(50, 55, 30, 65, 55, 20, "GHOST", "FIRE", "Litwick");
    }
}
class Lampent extends Pokemon {
    public Lampent() {
        super(60, 60, 40, 95, 60, 55, "GHOST", "FIRE", "Lampent");
    }
}
class Chandelure extends Pokemon {
    public Chandelure() {
        super(60, 90, 55, 145, 90, 80, "GHOST", "FIRE", "Chandelure");
    }
}
class Axew extends Pokemon {
    public Axew() {
        super(46, 60, 87, 30, 40, 57, "DRAGON", "NA", "Axew");
    }
}
class Fraxure extends Pokemon {
    public Fraxure() {
        super(66, 70, 117, 40, 50, 67, "DRAGON", "NA", "Fraxure");
    }
}
class Haxorus extends Pokemon {
    public Haxorus() {
        super(76, 90, 147, 60, 70, 97, "DRAGON", "NA", "Haxorus");
    }
}
class Cubchoo extends Pokemon {
    public Cubchoo() {
        super(55, 40, 70, 60, 40, 40, "ICE", "NA", "Cubchoo");
    }
}
class Beartic extends Pokemon {
    public Beartic() {
        super(95, 80, 130, 70, 80, 50, "ICE", "NA", "Beartic");
    }
}
class Cryogonal extends Pokemon {
    public Cryogonal() {
        super(80, 50, 50, 95, 135, 105, "ICE", "NA", "Cryogonal");
    }
}
class Shelmet extends Pokemon {
    public Shelmet() {
        super(50, 85, 40, 40, 65, 25, "BUG", "NA", "Shelmet");
    }
}
class Accelgor extends Pokemon {
    public Accelgor() {
        super(80, 40, 70, 100, 60, 145, "BUG", "NA", "Accelgor");
    }
}
class Stunfisk extends Pokemon {
    public Stunfisk() {
        super(109, 84, 66, 81, 99, 32, "GROUND", "ELECTRIC", "Stunfisk");
    }
}
class StunfiskGalarian extends Pokemon {
    public StunfiskGalarian() {
        super(109, 99, 81, 66, 84, 32, "GROUND", "STEEL", "Galarian Stunfisk");
    }
}
class Mienfoo extends Pokemon {
    public Mienfoo() {
        super(45, 50, 85, 55, 50, 65, "FIGHTING", "NA", "Mienfoo");
    }
}
class Mienshao extends Pokemon {
    public Mienshao() {
        super(65, 60, 125, 95, 60, 105, "FIGHTING", "NA", "Mienshao");
    }
}
class Druddigon extends Pokemon {
    public Druddigon() {
        super(77, 90, 120, 60, 90, 48, "DRAGON", "NA", "Druddigon");
    }
}
class Golett extends Pokemon {
    public Golett() {
        super(59, 50, 74, 35, 50, 35, "GROUND", "GHOST", "Golett");
    }
}
class Golurk extends Pokemon {
    public Golurk() {
        super(89, 80, 124, 55, 80, 55, "GROUND", "GHOST", "Golurk");
    }
}
class Pawniard extends Pokemon {
    public Pawniard() {
        super(45, 70, 85, 40, 40, 60, "DARK", "STEEL", "Pawniard");
    }
}
class Bisharp extends Pokemon {
    public Bisharp() {
        super(65, 100, 125, 60, 70, 70, "DARK", "STEEL", "Bisharp");
    }
}
class Bouffalant extends Pokemon {
    public Bouffalant() {
        super(95, 95, 110, 40, 95, 55, "NORMAL", "NA", "Bouffalant");
    }
}
class Rufflet extends Pokemon {
    public Rufflet() {
        super(70, 50, 83, 37, 50, 60, "NORMAL", "FLYING", "Rufflet");
    }
}
class Braviary extends Pokemon {
    public Braviary() {
        super(100, 75, 123, 57, 75, 80, "NORMAL", "FLYING", "Braviary");
    }
}
class BraviaryHisuian extends Pokemon {
    public BraviaryHisuian() {
        super(110, 70, 83, 112, 70, 65, "PSYCHIC", "FLYING", "Hisuian Braviary");
    }
}
class Vullaby extends Pokemon {
    public Vullaby() {
        super(70, 75, 55, 45, 65, 60, "DARK", "FLYING", "Vullaby");
    }
}
class Mandibuzz extends Pokemon {
    public Mandibuzz() {
        super(110, 105, 65, 55, 95, 80, "DARK", "FLYING", "Mandibuzz");
    }
}
class Heatmor extends Pokemon {
    public Heatmor() {
        super(85, 66, 97, 105, 66, 65, "FIRE", "NA", "Heatmor");
    }
}
class Durant extends Pokemon {
    public Durant() {
        super(58, 112, 109, 48, 48, 109, "BUG", "STEEL", "Durant");
    }
}
class Deino extends Pokemon {
    public Deino() {
        super(52, 50, 65, 45, 50, 38, "DARK", "DRAGON", "Deino");
    }
}
class Zweilous extends Pokemon {
    public Zweilous() {
        super(72, 70, 85, 65, 70, 58, "DARK", "DRAGON", "Zweilous");
    }
}
class Hydreigon extends Pokemon {
    public Hydreigon() {
        super(92, 90, 105, 125, 90, 98, "DARK", "DRAGON", "Hydreigon");
    }
}
class Larvesta extends Pokemon {
    public Larvesta() {
        super(55, 55, 85, 50, 55, 60, "BUG", "FIRE", "Larvesta");
    }
}
class Volcarona extends Pokemon {
    public Volcarona() {
        super(85, 65, 60, 135, 105, 100, "BUG", "FIRE", "Volcarona");
    }
}
class Cobalion extends Pokemon {
    public Cobalion() {
        super(91, 129, 90, 90, 72, 108, "STEEL", "FIGHTING", "Cobalion");
    }
}
class Terrakion extends Pokemon {
    public Terrakion() {
        super(91, 90, 129, 72, 90, 108, "ROCK", "FIGHTING", "Terrakion");
    }
}
class Virizion extends Pokemon {
    public Virizion() {
        super(91, 72, 90, 90, 129, 108, "GRASS", "FIGHTING", "Virizion");
    }
}
class TornadusIncarnate extends Pokemon {
    public TornadusIncarnate() {
        super(79, 70, 115, 125, 80, 111, "FLYING", "NA", "Tornadus Incarnate Forme");
    }
}
class TornadusTherian extends Pokemon {
    public TornadusTherian() {
        super(79, 80, 100, 110, 90, 121, "FLYING", "NA", "Tornadus Therian Forme");
    }
}
class ThundurusIncarnate extends Pokemon {
    public ThundurusIncarnate() {
        super(79, 70, 115, 125, 80, 111, "ELECTRIC", "FLYING", "Thundurus Incarnate Forme");
    }
}
class ThundurusTherian extends Pokemon {
    public ThundurusTherian() {
        super(79, 70, 105, 145, 80, 101, "ELECTRIC", "FLYING", "Thundurus Therian Forme");
    }
}
class Reshiram extends Pokemon {
    public Reshiram() {
        super(100, 100, 120, 150, 120, 90, "DRAGON", "FIRE", "Reshiram");
    }
}
class Zekrom extends Pokemon {
    public Zekrom() {
        super(100, 120, 150, 120, 100, 90, "DRAGON", "ELECTRIC", "Zekrom");
    }
}
class LandorusIncarnate extends Pokemon {
    public LandorusIncarnate() {
        super(89, 90, 125, 115, 80, 101, "GROUND", "FLYING", "Incarnate Landorus");
    }
}
class LandorusTherian extends Pokemon {
    public LandorusTherian() {
        super(89, 90, 145, 105, 80, 91, "GROUND", "FLYING", "Therian Landorus");
    }
}
class Kyurem extends Pokemon {
    public Kyurem() {
        super(125, 90, 130, 130, 90, 95, "DRAGON", "ICE", "Kyurem");
    }
}
class KyuremBlack extends Pokemon {
    public KyuremBlack() {
        super(125, 100, 170, 120, 90, 95, "DRAGON", "ICE", "Black Kyurem");
    }
}
class KyuremWhite extends Pokemon {
    public KyuremWhite() {
        super(125, 90, 120, 170, 100, 95, "DRAGON", "ICE", "White Kyurem");
    }
}
class KeldeoOrdinary extends Pokemon {
    public KeldeoOrdinary() {
        super(91, 90, 72, 129, 90, 108, "WATER", "FIGHTING", "Keldeo Ordinary Form");
    }
}
class KeldeoResolute extends Pokemon {
    public KeldeoResolute() {
        super(91, 90, 72, 129, 90, 108, "WATER", "FIGHTING", "Keldeo Resolute Form");
    }
}
class MeloettaAria extends Pokemon {
    public MeloettaAria() {
        super(100, 77, 77, 128, 128, 90, "NORMAL", "PSYCHIC", "Meloetta Aria Forme");
    }
}
class MeloettaPiroutte extends Pokemon {
    public MeloettaPiroutte() {
        super(100, 90, 128, 77, 77, 128, "NORMAL", "FIGHTING", "Meloetta Piroutte Forme");
    }
}
class Genesect extends Pokemon {
    public Genesect() {
        super(71, 95, 120, 120, 95, 99, "BUG", "STEEL", "Genesect");
    }
}
class Chespin extends Pokemon {
    public Chespin() {
        super(56, 65, 61, 48, 45, 38, "GRASS", "NA", "Chespin");
    }
}
class Quilladin extends Pokemon {
    public Quilladin() {
        super(61, 95, 78, 56, 58, 57, "GRASS", "NA", "Quilladin");
    }
}
class Chesnaught extends Pokemon {
    public Chesnaught() {
        super(88, 122, 107, 74, 75, 64, "GRASS", "FIGHTING", "Chesnaught");
    }
}
class Fennekin extends Pokemon {
    public Fennekin() {
        super(40, 40, 45, 62, 60, 60, "FIRE", "NA", "Fennekin");
    }
}
class Braixen extends Pokemon {
    public Braixen() {
        super(59, 58, 59, 90, 70, 73, "FIRE", "NA", "Braixen");
    }
}
class Delphox extends Pokemon {
    public Delphox() {
        super(75, 72, 69, 114, 100, 104, "FIRE", "PSYCHIC", "Delphox");
    }
}
class Froakie extends Pokemon {
    public Froakie() {
        super(41, 40, 56, 62, 44, 71, "WATER", "NA", "Froakie");
    }
}
class Frogadier extends Pokemon {
    public Frogadier() {
        super(54, 52, 63, 83, 56, 97, "WATER", "NA", "Frogadier");
    }
}
class Greninja extends Pokemon {
    public Greninja() {
        super(72, 67, 95, 103, 71, 122, "WATER", "DARK", "Greninja");
    }
}
class GreninjaAsh extends Pokemon {
    public GreninjaAsh() {
        super(72, 67, 145, 153, 71, 132, "WATER", "DARK", "Ash-Greninja");
    }
}
class Bunnelby extends Pokemon {
    public Bunnelby() {
        super(38, 38, 36, 32, 36, 57, "NORMAL", "NA", "Bunnelby");
    }
}
class Diggersby extends Pokemon {
    public Diggersby() {
        super(85, 77, 56, 50, 77, 78, "NORMAL", "GROUND", "Diggersby");
    }
}
class Fletchling extends Pokemon {
    public Fletchling() {
        super(45, 43, 50, 40, 38, 62, "NORMAL", "FLYING", "Fletchling");
    }
}
class Fletchinder extends Pokemon {
    public Fletchinder() {
        super(62, 55, 73, 56, 52, 84, "FIRE", "FLYING", "Fletchinder");
    }
}
class Talonflame extends Pokemon {
    public Talonflame() {
        super(78, 71, 81, 74, 69, 126, "FIRE", "FLYING", "Talonflame");
    }
}
class Scatterbug extends Pokemon {
    public Scatterbug() {
        super(38, 40, 35, 27, 25, 35, "BUG", "NA", "Scatterbug");
    }
}
class Spewpa extends Pokemon {
    public Spewpa() {
        super(45, 60, 22, 27, 30, 29, "BUG", "NA", "Spewpa");
    }
}
class Vivillon extends Pokemon {
    public Vivillon() {
        super(80, 50, 52, 90, 50, 89, "BUG", "FLYING", "Vivillon");
    }
}
class Litleo extends Pokemon {
    public Litleo() {
        super(62, 58, 50, 73, 54, 72, "FIRE", "NORMAL", "Litleo");
    }
}
class Pyroar extends Pokemon {
    public Pyroar() {
        super(86, 72, 68, 109, 66, 106, "FIRE", "NORMAL", "Pyroar");
    }
}
class Flabebe extends Pokemon {
    public Flabebe() {
        super(44, 39, 38, 61, 79, 42, "FAIRY", "NA", "Flabebe");
    }
}
class Floette extends Pokemon {
    public Floette() {
        super(54, 47, 45, 75, 98, 52, "FAIRY", "NA", "Floette");
    }
}
class Florges extends Pokemon {
    public Florges() {
        super(78, 68, 65, 112, 154, 75, "FAIRY", "NA", "Florges");
    }
}
class Skiddo extends Pokemon {
    public Skiddo() {
        super(66, 48, 65, 62, 57, 52, "GRASS", "NA", "Skiddo");
    }
}
class Gogoat extends Pokemon {
    public Gogoat() {
        super(123, 62, 100, 97, 81, 68, "GRASS", "NA", "Gogoat");
    }
}
class Pancham extends Pokemon {
    public Pancham() {
        super(67, 62, 82, 46, 48, 43, "FIGHTING", "NA", "Pancham");
    }
}
class Pangoro extends Pokemon {
    public Pangoro() {
        super(95, 78, 124, 69, 71, 58, "FIGHTING", "DARK", "Pangoro");
    }
}
class Furfrou extends Pokemon {
    public Furfrou() {
        super(75, 60, 80, 65, 90, 102, "NORMAL", "NA", "Furfrou");
    }
}
class Espurr extends Pokemon {
    public Espurr() {
        super(62, 54, 48, 63, 60, 68, "PSYCHIC", "NA", "Espurr");
    }
}
class MeowsticM extends Pokemon {
    public MeowsticM() {
        super(74, 76, 48, 83, 81, 104, "PSYCHIC", "NA", "Meowstic (Male)");
    }
}
class MeowsticF extends Pokemon {
    public MeowsticF() {
        super(74, 76, 48, 83, 81, 104, "PSYCHIC", "NA", "Meowstic (Female)");
    }
}
class Honedge extends Pokemon {
    public Honedge() {
        super(45, 100, 80, 35, 37, 28, "STEEL", "GHOST", "Honedge");
    }
}
class Doublade extends Pokemon {
    public Doublade() {
        super(59, 150, 110, 45, 49, 35, "STEEL", "GHOST", "Doublade");
    }
}
class AegislashShield extends Pokemon {
    public AegislashShield() {
        super(60, 140, 50, 50, 140, 60, "STEEL", "GHOST", "Aegislash Shield Forme");
    }
}
class AegislashBlade extends Pokemon {
    public AegislashBlade() {
        super(60, 50, 140, 140, 50, 60, "STEEL", "GHOST", "Aegislash Blade Forme");
    }
}
class Spritzee extends Pokemon {
    public Spritzee() {
        super(78, 60, 52, 63, 65, 23, "FAIRY", "NA", "Spritzee");
    }
}
class Aromatisse extends Pokemon {
    public Aromatisse() {
        super(101, 72, 72, 99, 89, 29, "FAIRY", "NA", "Aromatisse");
    }
}
class Swirlix extends Pokemon {
    public Swirlix() {
        super(62, 66, 48, 59, 57, 49, "FAIRY", "NA", "Swirlix");
    }
}
class Slurpuff extends Pokemon {
    public Slurpuff() {
        super(82, 86, 80, 85, 75, 72, "FAIRY", "NA", "Slurpuff");
    }
}
class Inkay extends Pokemon {
    public Inkay() {
        super(53, 53, 54, 37, 46, 45, "DARK", "PSYCHIC", "Inkay");
    }
}
class Malamar extends Pokemon {
    public Malamar() {
        super(86, 88, 92, 68, 75, 73, "DARK", "PSYCHIC", "Malamar");
    }
}
class Binacle extends Pokemon {
    public Binacle() {
        super(42, 67, 52, 39, 56, 50, "ROCK", "WATER", "Binacle");
    }
}
class Barbaracle extends Pokemon {
    public Barbaracle() {
        super(72, 115, 105, 54, 86, 68, "ROCK", "WATER", "Barbaracle");
    }
}
class Skrelp extends Pokemon {
    public Skrelp() {
        super(50, 60, 60, 60, 60, 30, "POISON", "WATER", "Skrelp");
    }
}
class Dragalge extends Pokemon {
    public Dragalge() {
        super(65, 90, 75, 97, 123, 44, "POISON", "DRAGON", "Dragalge");
    }
}
class Clauncher extends Pokemon {
    public Clauncher() {
        super(50, 62, 53, 58, 63, 44, "WATER", "NA", "Clauncher");
    }
}
class Clawitzer extends Pokemon {
    public Clawitzer() {
        super(71, 88, 73, 120, 89, 59, "WATER", "NA", "Clawitzer");
    }
}
class Helioptile extends Pokemon {
    public Helioptile() {
        super(44, 33, 38, 61, 43, 70, "ELECTRIC", "NORMAL", "Helioptile");
    }
}
class Heliolisk extends Pokemon {
    public Heliolisk() {
        super(62, 52, 55, 109, 94, 109, "ELECTRIC", "NORMAL", "Heliolisk");
    }
}
class Tyrunt extends Pokemon {
    public Tyrunt() {
        super(58, 77, 89, 45, 45, 48, "ROCK", "DRAGON", "Tyrunt");
    }
}
class Tyrantrum extends Pokemon {
    public Tyrantrum() {
        super(82, 119, 121, 69, 59, 71, "ROCK", "DRAGON", "Tyrantrum");
    }
}
class Amaura extends Pokemon {
    public Amaura() {
        super(77, 50, 59, 67, 63, 46, "ROCK", "ICE", "Amaura");
    }
}
class Aurorus extends Pokemon {
    public Aurorus() {
        super(123, 72, 77, 99, 92, 58, "ROCK", "ICE", "Aurorus");
    }
}
class Sylveon extends Pokemon {
    public Sylveon() {
        super(95, 65, 65, 110, 130, 60, "FAIRY", "NA", "Sylveon");
    }
}
class Hawlucha extends Pokemon {
    public Hawlucha() {
        super(78, 75, 92, 74, 63, 118, "FIGHTING", "FLYING", "Hawlucha");
    }
}
class Dedenne extends Pokemon {
    public Dedenne() {
        super(67, 57, 58, 81, 67, 101, "ELECTRIC", "FAIRY", "Dedenne");
    }
}
class Carbink extends Pokemon {
    public Carbink() {
        super(50, 150, 50, 50, 150, 50, "ROCK", "FAIRY", "Carbink");
    }
}
class Goomy extends Pokemon {
    public Goomy() {
        super(45, 35, 50, 55, 75, 40, "DRAGON", "NA", "Goomy");
    }
}
class Sliggoo extends Pokemon {
    public Sliggoo() {
        super(68, 53, 75, 83, 113, 60, "DRAGON", "NA", "Sliggoo");
    }
}
class SliggooHisuian extends Pokemon {
    public SliggooHisuian() {
        super(58, 83, 75, 83, 113, 40, "DRAGON", "STEEL", "Hisuian Sliggoo");
    }
}
class Goodra extends Pokemon {
    public Goodra() {
        super(90, 70, 100, 110, 150, 80, "DRAGON", "NA", "Goodra");
    }
}
class GoodraHisuian extends Pokemon {
    public GoodraHisuian() {
        super(80, 100, 100, 110, 150, 60, "DRAGON", "STEEL", "Hisuian Goodra");
    }
}
class Klefki extends Pokemon {
    public Klefki() {
        super(57, 91, 80, 80, 87, 75, "STEEL", "FAIRY", "Klefki");
    }
}
class Phantump extends Pokemon {
    public Phantump() {
        super(43, 48, 70, 50, 60, 38, "GHOST", "GRASS", "Phantump");
    }
}
class Trevenant extends Pokemon {
    public Trevenant() {
        super(85, 76, 110, 65, 82, 56, "GHOST", "GRASS", "Trevenant");
    }
}
class PumpkabooAverage extends Pokemon {
    public PumpkabooAverage() {
        super(49, 70, 66, 44, 55, 51, "GHOST", "GRASS", "Pumpkaboo (Average Size)");
    }
}
class PumpkabooSmall extends Pokemon {
    public PumpkabooSmall() {
        super(44, 70, 66, 44, 55, 56, "GHOST", "GRASS", "Pumpkaboo (Small Size)");
    }
}
class PumpkabooLarge extends Pokemon {
    public PumpkabooLarge() {
        super(54, 70, 66, 44, 55, 46, "GHOST", "GRASS", "Pumpkaboo (Large Size)");
    }
}
class PumpkabooSuper extends Pokemon {
    public PumpkabooSuper() {
        super(59, 70, 66, 44, 55, 41, "GHOST", "GRASS", "Pumpkaboo (Super Size)");
    }
}
class GourgeistAverage extends Pokemon {
    public GourgeistAverage() {
        super(65, 122, 90, 58, 75, 84, "GHOST", "GRASS", "Gourgeist (Average Size)");
    }
}
class GourgeistSmall extends Pokemon {
    public GourgeistSmall() {
        super(55, 122, 85, 58, 75, 99, "GHOST", "GRASS", "Gourgeist (Small Size)");
    }
}
class GourgeistLarge extends Pokemon {
    public GourgeistLarge() {
        super(75, 122, 95, 58, 75, 69, "GHOST", "GRASS", "Gourgeist (Large Size)");
    }
}
class GourgeistSuper extends Pokemon {
    public GourgeistSuper() {
        super(85, 122, 100, 58, 75, 54, "GHOST", "GRASS", "Gourgeist (Super Size)");
    }
}
class Bergmite extends Pokemon {
    public Bergmite() {
        super(55, 85, 69, 32, 35, 28, "ICE", "NA", "Bergmite");
    }
}
class Avalugg extends Pokemon {
    public Avalugg() {
        super(95, 184, 117, 44, 46, 28, "ICE", "NA", "Avalugg");
    }
}
class AvaluggHisuian extends Pokemon {
    public AvaluggHisuian() {
        super(95, 184, 127, 34, 36, 38, "ICE", "ROCK", "Hisuian Avalugg");
    }
}
class Noibat extends Pokemon {
    public Noibat() {
        super(40, 35, 30, 45, 40, 55, "FLYING", "DRAGON", "Noibat");
    }
}
class Noivern extends Pokemon {
    public Noivern() {
        super(85, 80, 70, 97, 80, 123, "FLYING", "DRAGON", "Noivern");
    }
}
class Xerneas extends Pokemon {
    public Xerneas() {
        super(126, 95, 131, 131, 98, 99, "FAIRY", "NA", "Xerneas");
    }
}
class Yveltal extends Pokemon {
    public Yveltal() {
        super(126, 95, 131, 131, 98, 99, "DARK", "FLYING", "Yveltal");
    }
}
class Zygarde50 extends Pokemon {
    public Zygarde50() {
        super(108, 121, 100, 81, 95, 95, "DRAGON", "GROUND", "Zygarde 50% Forme");
    }
}
class Zygarde10 extends Pokemon {
    public Zygarde10() {
        super(54, 71, 100, 61, 85, 115, "DRAGON", "GROUND", "Zygarde 10% Forme");
    }
}
class ZygardeComplete extends Pokemon {
    public ZygardeComplete() {
        super(216, 121, 100, 91, 95, 85, "DRAGON", "GROUND", "Zygarde Complete Forme");
    }
}
class Diancie extends Pokemon {
    public Diancie() {
        super(50, 150, 100, 100, 150, 50, "ROCK", "FAIRY", "Diancie");
    }
}
class DiancieMega extends Pokemon {
    public DiancieMega() {
        super(50, 110, 160, 160, 110, 110, "ROCK", "FAIRY", "Mega Diancie");
    }
}
class HoopaConfined extends Pokemon {
    public HoopaConfined() {
        super(80, 60, 110, 150, 130, 70, "PSYCHIC", "GHOST", "Hoopa Confined");
    }
}
class HoopaUnbound extends Pokemon {
    public HoopaUnbound() {
        super(80, 60, 160, 170, 130, 80, "PSYCHIC", "DARK", "Hoopa Unbound");
    }
}
class Volcanion extends Pokemon {
    public Volcanion() {
        super(80, 120, 110, 130, 90, 70, "FIRE", "WATER", "Volcanion");
    }
}
class Rowlet extends Pokemon {
    public Rowlet() {
        super(68, 55, 55, 50, 50, 42, "GRASS", "FLYING", "Rowlet");
    }
}
class Dartrix extends Pokemon {
    public Dartrix() {
        super(78, 75, 75, 70, 70, 52, "GRASS", "FLYING", "Dartrix");
    }
}
class Decidueye extends Pokemon {
    public Decidueye() {
        super(78, 75, 107, 100, 100, 70, "GRASS", "GHOST", "Decidueye");
    }
}
class DecidueyeHisuian extends Pokemon {
    public DecidueyeHisuian() {
        super(88, 80, 112, 95, 95, 60, "GRASS", "FIGHTING", "Hisuian Decidueye");
    }
}
class Litten extends Pokemon {
    public Litten() {
        super(45, 40, 65, 60, 40, 70, "FIRE", "NA", "Litten");
    }
}
class Torracat extends Pokemon {
    public Torracat() {
        super(65, 50, 85, 80, 50, 90, "FIRE", "NA", "Torracat");
    }
}
class Incineroar extends Pokemon {
    public Incineroar() {
        super(95, 90, 115, 80, 90, 60, "FIRE", "DARK", "Incineroar");
    }
}
class Popplio extends Pokemon {
    public Popplio() {
        super(50, 54, 54, 66, 56, 40, "WATER", "NA", "Popplio");
    }
}
class Brionne extends Pokemon {
    public Brionne() {
        super(60, 69, 69, 91, 81, 50, "WATER", "NA", "Brionne");
    }
}
class Primarina extends Pokemon {
    public Primarina() {
        super(80, 74, 74, 126, 116, 60, "WATER", "FAIRY", "Primarina");
    }
}
class Pikipek extends Pokemon {
    public Pikipek() {
        super(35, 30, 75, 30, 30, 65, "NORMAL", "FLYING", "Pikipek");
    }
}
class Trumbeak extends Pokemon {
    public Trumbeak() {
        super(55, 50, 85, 40, 50, 75, "NORMAL", "FLYING", "Trumbeak");
    }
}
class Toucannon extends Pokemon {
    public Toucannon() {
        super(80, 75, 120, 75, 75, 60, "NORMAL", "FLYING", "Toucannon");
    }
}
class Yungoos extends Pokemon {
    public Yungoos() {
        super(48, 30, 70, 30, 30, 45, "NORMAL", "NA", "Yungoos");
    }
}
class Gumshoos extends Pokemon {
    public Gumshoos() {
        super(88, 60, 110, 55, 60, 45, "NORMAL", "NA", "Gumshoos");
    }
}
class Grubbin extends Pokemon {
    public Grubbin() {
        super(47, 45, 62, 55, 45, 46, "BUG", "NA", "Grubbin");
    }
}
class Charjabug extends Pokemon {
    public Charjabug() {
        super(57, 95, 82, 55, 75, 36, "BUG", "ELECTRIC", "Charjabug");
    }
}
class Vikavolt extends Pokemon {
    public Vikavolt() {
        super(77, 90, 70, 145, 75, 43, "BUG", "ELECTRIC", "Vikavolt");
    }
}
class Crabrawler extends Pokemon {
    public Crabrawler() {
        super(47, 57, 82, 42, 47, 63, "FIGHTING", "NA", "Crabrawler");
    }
}
class Crabominable extends Pokemon {
    public Crabominable() {
        super(97, 77, 132, 62, 67, 43, "FIGHTING", "ICE", "Crabominable");
    }
}
class OricorioBaile extends Pokemon {
    public OricorioBaile() {
        super(75, 70, 70, 98, 70, 93, "FIRE", "FLYING", "Oricorio Baile Style");
    }
}
class OricorioPom extends Pokemon {
    public OricorioPom() {
        super(75, 70, 70, 98, 70, 93, "ELECTRIC", "FLYING", "Oricorio Pom-Pom Style");
    }
}
class OricorioPau extends Pokemon {
    public OricorioPau() {
        super(75, 70, 70, 98, 70, 93, "PSYCHIC", "FLYING", "Oricorio Pa'u Style");
    }
}
class OricorioSensu extends Pokemon {
    public OricorioSensu() {
        super(75, 70, 70, 98, 70, 93, "GHOST", "FLYING", "Oricorio Sesnu Style");
    }
}
class Cutiefly extends Pokemon {
    public Cutiefly() {
        super(40, 40, 45, 55, 40, 84, "BUG", "FAIRY", "Cutiefly");
    }
}
class Ribombee extends Pokemon {
    public Ribombee() {
        super(60, 60, 55, 95, 70, 124, "BUG", "FAIRY", "Ribombee");
    }
}
class Rockruff extends Pokemon {
    public Rockruff() {
        super(45, 40, 65, 30, 40, 60, "ROCK", "NA", "Rockruff");
    }
}
class RockruffTempo extends Pokemon {
    public RockruffTempo() {
        super(45, 40, 65, 30, 40, 60, "ROCK", "NA", "Own Tempo Rockruff");
    }
}
class LycanrocMidday extends Pokemon {
    public LycanrocMidday() {
        super(75, 65, 115, 55, 65, 112, "ROCK", "NA", "Lycanroc Midday Form");
    }
}
class LycanrocMidnight extends Pokemon {
    public LycanrocMidnight() {
        super(85, 75, 115, 55, 75, 82, "ROCK", "NA", "Lycanroc Midnight Form");
    }
}
class LycanrocDusk extends Pokemon {
    public LycanrocDusk() {
        super(75, 65, 117, 55, 65, 110, "ROCK", "NA", "Lycanroc Dusk Form");
    }
}
class WishiwashiSolo extends Pokemon {
    public WishiwashiSolo() {
        super(45, 20, 20, 25, 25, 40, "WATER", "NA", "Wishiwashi Solo Form");
    }
}
class WishiwashiSchool extends Pokemon {
    public WishiwashiSchool() {
        super(45, 130, 140, 140, 135, 30, "WATER", "NA", "Wishiwashi School Form");
    }
}
class Mareanie extends Pokemon {
    public Mareanie() {
        super(50, 62, 53, 43, 52, 45, "POISON", "WATER", "Mareanie");
    }
}
class Toxapex extends Pokemon {
    public Toxapex() {
        super(50, 152, 63, 53, 142, 35, "POISON", "WATER", "Toxapex");
    }
}
class Mudbray extends Pokemon {
    public Mudbray() {
        super(70, 70, 100, 45, 55, 45, "GROUND", "NA", "Mudbray");
    }
}
class Mudsdale extends Pokemon {
    public Mudsdale() {
        super(100, 100, 125, 55, 85, 35, "GROUND", "NA", "Mudsdale");
    }
}
class Dewpider extends Pokemon {
    public Dewpider() {
        super(38, 52, 40, 40, 72, 27, "WATER", "BUG", "Dewpider");
    }
}
class Araquanid extends Pokemon {
    public Araquanid() {
        super(68, 92, 70, 50, 132, 42, "WATER", "BUG", "Araquanid");
    }
}
class Fomantis extends Pokemon {
    public Fomantis() {
        super(40, 35, 55, 50, 35, 35, "GRASS", "NA", "Fomantis");
    }
}
class Lurantis extends Pokemon {
    public Lurantis() {
        super(70, 90, 105, 80, 90, 45, "GRASS", "NA", "Lurantis");
    }
}
class Morelull extends Pokemon {
    public Morelull() {
        super(40, 55, 35, 65, 75, 15, "GRASS", "FAIRY", "Morelull");
    }
}
class Shiinotic extends Pokemon {
    public Shiinotic() {
        super(60, 80, 45, 90, 100, 30, "GRASS", "FAIRY", "Shiinotic");
    }
}
class Salandit extends Pokemon {
    public Salandit() {
        super(48, 40, 44, 71, 40, 77, "POISON", "FIRE", "Salandit");
    }
}
class Salazzle extends Pokemon {
    public Salazzle() {
        super(68, 60, 64, 111, 60, 117, "POISON", "FIRE", "Salazzle");
    }
}
class Stufful extends Pokemon {
    public Stufful() {
        super(70, 50, 75, 45, 50, 50, "NORMAL", "FIGHTING", "Stufful");
    }
}
class Bewear extends Pokemon {
    public Bewear() {
        super(120, 80, 125, 55, 60, 60, "NORMAL", "FIGHTING", "Bewear");
    }
}
class Bounsweet extends Pokemon {
    public Bounsweet() {
        super(42, 38, 30, 30, 38, 32, "GRASS", "NA", "Bounsweet");
    }
}
class Steenee extends Pokemon {
    public Steenee() {
        super(52, 48, 40, 40, 48, 62, "GRASS", "NA", "Steenee");
    }
}
class Tsareena extends Pokemon {
    public Tsareena() {
        super(72, 98, 120, 50, 98, 72, "GRASS", "NA", "Tsareena");
    }
}
class Comfey extends Pokemon {
    public Comfey() {
        super(51, 90, 52, 82, 110, 100, "FAIRY", "NA", "Comfey");
    }
}
class Oranguru extends Pokemon {
    public Oranguru() {
        super(90, 80, 60, 90, 110, 60, "NORMAL", "PSYCHIC", "Oranguru");
    }
}
class Passimian extends Pokemon {
    public Passimian() {
        super(100, 90, 120, 40, 60, 80, "FIGHTING", "NA", "Passimian");
    }
}
class Wimpod extends Pokemon {
    public Wimpod() {
        super(25, 40, 35, 20, 30, 80, "BUG", "WATER", "Wimpod");
    }
}
class Golisopod extends Pokemon {
    public Golisopod() {
        super(75, 140, 125, 60, 90, 40, "BUG", "WATER", "Golisopod");
    }
}
class Sandygast extends Pokemon {
    public Sandygast() {
        super(55, 80, 55, 70, 45, 15, "GHOST", "GROUND", "Sandygast");
    }
}
class Palossand extends Pokemon {
    public Palossand() {
        super(85, 110, 75, 100, 75, 35, "GHOST", "GROUND", "Palossand");
    }
}
class Pyukumuku extends Pokemon {
    public Pyukumuku() {
        super(55, 130, 60, 30, 130, 5, "WATER", "NA", "Pyukumuku");
    }
}
class TypeNull extends Pokemon {
    public TypeNull() {
        super(95, 95, 95, 95, 95, 59, "NORMAL", "NA", "Type: Null");
    }
}
class Silvally extends Pokemon {
    public Silvally() {
        super(95, 95, 95, 95, 95, 95, "NORMAL", "NA", "Silvally");
    }
}
class MiniorMeteor extends Pokemon {
    public MiniorMeteor() {
        super(60, 100, 60, 60, 100, 60, "ROCK", "FLYING", "Minior Meteor Form");
    }
}
class MiniorCore extends Pokemon {
    public MiniorCore() {
        super(60, 60, 100, 100, 60, 120, "ROCK", "FLYING", "Minior Core Form");
    }
}
class Komala extends Pokemon {
    public Komala() {
        super(65, 65, 115, 75, 95, 65, "NORMAL", "NA", "Komala");
    }
}
class Turtonator extends Pokemon {
    public Turtonator() {
        super(60, 135, 78, 91, 85, 36, "FIRE", "DRAGON", "Turtonator");
    }
}
class Togedemaru extends Pokemon {
    public Togedemaru() {
        super(65, 63, 98, 40, 73, 96, "ELECTRIC", "STEEL", "Togedemaru");
    }
}
class Mimikyu extends Pokemon {
    public Mimikyu() {
        super(55, 80, 90, 50, 105, 96, "GHOST", "FAIRY", "Mimikyu");
    }
}
class Bruxish extends Pokemon {
    public Bruxish() {
        super(68, 70, 105, 70, 70, 92, "WATER", "PSYCHIC", "Bruxish");
    }
}
class Drampa extends Pokemon {
    public Drampa() {
        super(78, 85, 60, 135, 91, 36, "NORMAL", "DRAGON", "Drampa");
    }
}
class Dhelmise extends Pokemon {
    public Dhelmise() {
        super(70, 100, 131, 86, 90, 40, "GHOST", "GRASS", "Dhelmise");
    }
}
class Jangmoo extends Pokemon {
    public Jangmoo() {
        super(45, 65, 55, 45, 45, 45, "DRAGON", "NA", "Jangmo-o");
    }
}
class Hakamoo extends Pokemon {
    public Hakamoo() {
        super(55, 90, 75, 65, 70, 65, "DRAGON", "FIGHTING", "Hakamo-o");
    }
}
class Kommoo extends Pokemon {
    public Kommoo() {
        super(75, 125, 110, 100, 105, 85, "DRAGON", "FIGHTING", "Kommo-o");
    }
}
class TapuKoko extends Pokemon {
    public TapuKoko() {
        super(70, 85, 115, 95, 75, 130, "ELECTRIC", "FAIRY", "Tapu Koko");
    }
}
class TapuLele extends Pokemon {
    public TapuLele() {
        super(70, 75, 85, 130, 115, 95, "PSYCHIC", "FAIRY", "Tapu Lele");
    }
}
class TapuBulu extends Pokemon {
    public TapuBulu() {
        super(70, 115, 130, 85, 95, 75, "GRASS", "FAIRY", "Tapu Bulu");
    }
}
class TapuFini extends Pokemon {
    public TapuFini() {
        super(70, 115, 75, 95, 130, 85, "WATER", "FAIRY", "Tapu Fini");
    }
}
class Cosmog extends Pokemon {
    public Cosmog() {
        super(43, 31, 29, 29, 31, 37, "PSYCHIC", "NA", "Cosmog");
    }
}
class Cosmoem extends Pokemon {
    public Cosmoem() {
        super(43, 131, 29, 29, 131, 37, "PSYCHIC", "NA", "Cosmoem");
    }
}
class Solgaleo extends Pokemon {
    public Solgaleo() {
        super(137, 107, 137, 113, 89, 97, "PSYCHIC", "STEEL", "Solgaleo");
    }
}
class Lunala extends Pokemon {
    public Lunala() {
        super(137, 89, 113, 137, 107, 97, "PSYCHIC", "GHOST", "Lunala");
    }
}
class Nihilego extends Pokemon {
    public Nihilego() {
        super(109, 47, 53, 127, 131, 103, "ROCK", "POISON", "Nihilego");
    }
}
class Buzzwole extends Pokemon {
    public Buzzwole() {
        super(107, 139, 139, 53, 53, 79, "BUG", "FIGHTING", "Buzzwole");
    }
}
class Pheromosa extends Pokemon {
    public Pheromosa() {
        super(71, 37, 137, 137, 37, 151, "BUG", "FIGHTING", "Pheromosa");
    }
}
class Xurkitree extends Pokemon {
    public Xurkitree() {
        super(83, 71, 89, 173, 71, 83, "ELECTRIC", "NA", "Xurkitree");
    }
}
class Celesteela extends Pokemon {
    public Celesteela() {
        super(97, 103, 101, 107, 101, 61, "STEEL", "FLYING", "Celesteela");
    }
}
class Kartana extends Pokemon {
    public Kartana() {
        super(59, 131, 181, 59, 31, 109, "GRASS", "STEEL", "Kartana");
    }
}
class Guzzlord extends Pokemon {
    public Guzzlord() {
        super(223, 53, 101, 97, 53, 43, "DARK", "DRAGON", "Guzzlord");
    }
}
class Necrozma extends Pokemon {
    public Necrozma() {
        super(97, 101, 107, 127, 89, 79, "PSYCHIC", "NA", "Necrozma");
    }
}
class NecrozmaDusk extends Pokemon {
    public NecrozmaDusk() {
        super(97, 127, 157, 113, 109, 77, "PSYCHIC", "STEEL", "Dusk Mane Necrozma");
    }
}
class NecrozmaDawn extends Pokemon {
    public NecrozmaDawn() {
        super(97, 109, 113, 157, 127, 77, "PSYCHIC", "GHOST", "Dawn Wings Necrozma");
    }
}
class NecrozmaUltra extends Pokemon {
    public NecrozmaUltra() {
        super(97, 97, 167, 167, 97, 129, "PSYCHIC", "DRAGON", "Ultra Necrozma");
    }
}
class Magearna extends Pokemon {
    public Magearna() {
        super(80, 115, 95, 130, 115, 65, "STEEL", "FAIRY", "Magearna");
    }
}
class Marshadow extends Pokemon {
    public Marshadow() {
        super(90, 80, 125, 90, 90, 125, "FIGHTING", "GHOST", "Marshadow");
    }
}
class Poipole extends Pokemon {
    public Poipole() {
        super(67, 67, 73, 73, 67, 73, "POISON", "NA", "Poipole");
    }
}
class Naganadel extends Pokemon {
    public Naganadel() {
        super(73, 73, 73, 127, 73, 121, "POISON", "DRAGON", "Naganadel");
    }
}
class Stakataka extends Pokemon {
    public Stakataka() {
        super(61, 211, 131, 53, 101, 13, "ROCK", "STEEL", "Stakataka");
    }
}
class Blacephalon extends Pokemon {
    public Blacephalon() {
        super(53, 53, 127, 151, 79, 107, "FIRE", "GHOST", "Blacephalon");
    }
}
class Zeraora extends Pokemon {
    public Zeraora() {
        super(88, 75, 112, 102, 80, 143, "ELECTRIC", "NA", "Zeraora");
    }
}
class Meltan extends Pokemon {
    public Meltan() {
        super(46, 65, 65, 55, 35, 34, "STEEL", "NA", "Meltan");
    }
}
class Melmetal extends Pokemon {
    public Melmetal() {
        super(135, 143, 143, 80, 65, 34, "STEEL", "NA", "Melmetal");
    }
}
class Grookey extends Pokemon {
    public Grookey() {
        super(50, 50, 65, 40, 40, 65, "GRASS", "NA", "Grookey");
    }
}
class Thwackey extends Pokemon {
    public Thwackey() {
        super(70, 70, 85, 55, 60, 80, "GRASS", "NA", "Thwackey");
    }
}
class Rillaboom extends Pokemon {
    public Rillaboom() {
        super(100, 90, 125, 60, 70, 85, "GRASS", "NA", "Rillaboom");
    }
}
class Scorbunny extends Pokemon {
    public Scorbunny() {
        super(50, 40, 71, 40, 40, 69, "FIRE", "NA", "Scorbunny");
    }
}
class Raboot extends Pokemon {
    public Raboot() {
        super(65, 60, 86, 55, 60, 94, "FIRE", "NA", "Raboot");
    }
}
class Cinderace extends Pokemon {
    public Cinderace() {
        super(80, 75, 116, 65, 75, 119, "FIRE", "NA", "Cinderace");
    }
}
class Sobble extends Pokemon {
    public Sobble() {
        super(50, 40, 40, 70, 40, 70, "WATER", "NA", "Sobble");
    }
}
class Drizzile extends Pokemon {
    public Drizzile() {
        super(65, 55, 60, 95, 55, 90, "WATER", "NA", "Drizzile");
    }
}
class Inteleon extends Pokemon {
    public Inteleon() {
        super(70, 65, 85, 125, 65, 120, "WATER", "NA", "Inteleon");
    }
}
class Skwovet extends Pokemon {
    public Skwovet() {
        super(70, 55, 55, 35, 35, 25, "NORMAL", "NA", "Skwovet");
    }
}
class Greedent extends Pokemon {
    public Greedent() {
        super(120, 95, 95, 55, 75, 20, "NORMAL", "NA", "Greedent");
    }
}
class Rookidee extends Pokemon {
    public Rookidee() {
        super(38, 35, 47, 33, 35, 57, "FLYING", "NA", "Rookidee");
    }
}
class Corvisquire extends Pokemon {
    public Corvisquire() {
        super(68, 55, 67, 43, 55, 77, "FLYING", "NA", "Corvisquire");
    }
}
class Corviknight extends Pokemon {
    public Corviknight() {
        super(98, 105, 87, 53, 85, 67, "FLYING", "STEEL", "Corviknight");
    }
}
class Blipbug extends Pokemon {
    public Blipbug() {
        super(25, 20, 20, 25, 45, 45, "BUG", "NA", "Blipbug");
    }
}
class Dottler extends Pokemon {
    public Dottler() {
        super(50, 80, 35, 50, 90, 30, "BUG", "PSYCHIC", "Dottler");
    }
}
class Orbeetle extends Pokemon {
    public Orbeetle() {
        super(60, 110, 45, 80, 120, 90, "BUG", "PSYCHIC", "Orbeetle");
    }
}
class Nickit extends Pokemon {
    public Nickit() {
        super(40, 28, 28, 47, 52, 50, "DARK", "NA", "Nickit");
    }
}
class Thievul extends Pokemon {
    public Thievul() {
        super(70, 58, 58, 87, 92, 90, "DARK", "NA", "Thievul");
    }
}
class Gossifleur extends Pokemon {
    public Gossifleur() {
        super(40, 60, 40, 40, 60, 10, "GRASS", "NA", "Gossifleur");
    }
}
class Eldegoss extends Pokemon {
    public Eldegoss() {
        super(60, 90, 50, 80, 120, 60, "GRASS", "NA", "Eldegoss");
    }
}
class Wooloo extends Pokemon {
    public Wooloo() {
        super(42, 55, 40, 40, 45, 48, "NORMAL", "NA", "Wooloo");
    }
}
class Dubwool extends Pokemon {
    public Dubwool() {
        super(72, 100, 80, 60, 90, 88, "NORMAL", "NA", "Dubwool");
    }
}
class Chewtle extends Pokemon {
    public Chewtle() {
        super(50, 50, 64, 38, 38, 44, "WATER", "NA", "Chewtle");
    }
}
class Drednaw extends Pokemon {
    public Drednaw() {
        super(90, 90, 115, 48, 68, 74, "WATER", "ROCK", "Drednaw");
    }
}
class Yamper extends Pokemon {
    public Yamper() {
        super(59, 50, 45, 40, 50, 26, "ELECTRIC", "NA", "Yamper");
    }
}
class Boltund extends Pokemon {
    public Boltund() {
        super(69, 60, 90, 90, 60, 121, "ELECTRIC", "NA", "Boltund");
    }
}
class Rolycoly extends Pokemon {
    public Rolycoly() {
        super(30, 50, 40, 40, 50, 30, "ROCK", "NA", "Rolycoly");
    }
}
class Carkol extends Pokemon {
    public Carkol() {
        super(80, 90, 60, 60, 70, 50, "ROCK", "FIRE", "Carkol");
    }
}
class Coalossal extends Pokemon {
    public Coalossal() {
        super(110, 120, 80, 80, 90, 30, "ROCK", "FIRE", "Coalossal");
    }
}
class Applin extends Pokemon {
    public Applin() {
        super(40, 80, 40, 40, 40, 20, "GRASS", "DRAGON", "Applin");
    }
}
class Flapple extends Pokemon {
    public Flapple() {
        super(70, 80, 110, 95, 60, 70, "GRASS", "DRAGON", "Flapple");
    }
}
class Appletun extends Pokemon {
    public Appletun() {
        super(110, 80, 85, 100, 80, 30, "GRASS", "DRAGON", "Appletun");
    }
}
class Silicobra extends Pokemon {
    public Silicobra() {
        super(52, 75, 57, 35, 50, 46, "GROUND", "NA", "Silicobra");
    }
}
class Sandaconda extends Pokemon {
    public Sandaconda() {
        super(72, 125, 107, 65, 70, 71, "GROUND", "NA", "Sandaconda");
    }
}
class Cramorant extends Pokemon {
    public Cramorant() {
        super(70, 55, 85, 85, 95, 85, "FLYING", "WATER", "Cramorant");
    }
}
class Arrokuda extends Pokemon {
    public Arrokuda() {
        super(41, 40, 63, 40, 30, 66, "WATER", "NA", "Arrokuda");
    }
}
class Barraskewda extends Pokemon {
    public Barraskewda() {
        super(61, 60, 123, 60, 50, 136, "WATER", "NA", "Barraskewda");
    }
}
class Toxel extends Pokemon {
    public Toxel() {
        super(40, 35, 38, 54, 35, 40, "ELECTRIC", "POISON", "Toxel");
    }
}
class ToxtricityLowKey extends Pokemon {
    public ToxtricityLowKey() {
        super(75, 70, 98, 114, 70, 75, "ELECTRIC", "POISON", "Toxtricity Low Key Form");
    }
}
class ToxtricityAmped extends Pokemon {
    public ToxtricityAmped() {
        super(75, 70, 98, 114, 70, 75, "ELECTRIC", "POISON", "Toxtricity Amped Form");
    }
}
class Sizzlipede extends Pokemon {
    public Sizzlipede() {
        super(50, 45, 65, 50, 50, 45, "FIRE", "BUG", "Sizzlipede");
    }
}
class Centiskorch extends Pokemon {
    public Centiskorch() {
        super(100, 65, 115, 90, 90, 65, "FIRE", "BUG", "Centiskorch");
    }
}
class Clobbopus extends Pokemon {
    public Clobbopus() {
        super(50, 60, 68, 50, 50, 32, "FIGHTING", "NA", "Clobbopus");
    }
}
class Grapploct extends Pokemon {
    public Grapploct() {
        super(80, 90, 118, 70, 80, 42, "FIGHTING", "NA", "Grapploct");
    }
}
class Sinistea extends Pokemon {
    public Sinistea() {
        super(40, 45, 45, 74, 54, 50, "GHOST", "NA", "Sinistea");
    }
}
class Polteageist extends Pokemon {
    public Polteageist() {
        super(60, 65, 65, 134, 114, 70, "GHOST", "NA", "Polteageist");
    }
}
class Hatenna extends Pokemon {
    public Hatenna() {
        super(42, 45, 30, 56, 53, 39, "PSYCHIC", "NA", "Hatenna");
    }
}
class Hattrem extends Pokemon {
    public Hattrem() {
        super(57, 65, 40, 86, 73, 49, "PSYCHIC", "NA", "Hattrem");
    }
}
class Hatterene extends Pokemon {
    public Hatterene() {
        super(57, 95, 90, 136, 103, 29, "PSYCHIC", "FAIRY", "Hatterene");
    }
}
class Impidimp extends Pokemon {
    public Impidimp() {
        super(45, 30, 45, 55, 40, 50, "DARK", "FAIRY", "Impidimp");
    }
}
class Morgrem extends Pokemon {
    public Morgrem() {
        super(65, 45, 60, 75, 55, 70, "DARK", "FAIRY", "Morgrem");
    }
}
class Grimmsnarl extends Pokemon {
    public Grimmsnarl() {
        super(95, 65, 120, 95, 75, 60, "DARK", "FAIRY", "Grimmsnarl");
    }
}
class Obstagoon extends Pokemon {
    public Obstagoon() {
        super(93, 101, 90, 60, 81, 95, "DARK", "NORMAL", "Obstagoon");
    }
}
class Perrserker extends Pokemon {
    public Perrserker() {
        super(70, 100, 110, 50, 60, 50, "STEEL", "NA", "Perrserker");
    }
}
class Cursola extends Pokemon {
    public Cursola() {
        super(60, 50, 95, 145, 130, 30, "GHOST", "NA", "Cursola");
    }
}
class Sirfetchd extends Pokemon {
    public Sirfetchd() {
        super(62, 95, 135, 68, 82, 65, "FIGHTING", "NA", "Sirfetch'd");
    }
}
class MrRime extends Pokemon {
    public MrRime() {
        super(80, 75, 85, 110, 100, 70, "ICE", "PSYCHIC", "Mr. Rime");
    }
}
class Runerigus extends Pokemon {
    public Runerigus() {
        super(58, 145, 95, 50, 105, 30, "GROUND", "GHOST", "Runerigus");
    }
}
class Milcery extends Pokemon {
    public Milcery() {
        super(45, 40, 40, 50, 61, 34, "FAIRY", "NA", "Milcery");
    }
}
class Alcremie extends Pokemon {
    public Alcremie() {
        super(65, 75, 60, 110, 121, 64, "FAIRY", "NA", "Alcremie");
    }
}
class Falinks extends Pokemon {
    public Falinks() {
        super(65, 100, 100, 70, 60, 75, "FIGHTING", "NA", "Falinks");
    }
}
class Pincurchin extends Pokemon {
    public Pincurchin() {
        super(48, 95, 101, 91, 85, 15, "ELECTRIC", "NA", "Pincurchin");
    }
}
class Snom extends Pokemon {
    public Snom() {
        super(30, 35, 25, 45, 30, 20, "ICE", "BUG", "Snom");
    }
}
class Frosmoth extends Pokemon {
    public Frosmoth() {
        super(70, 60, 65, 125, 90, 65, "ICE", "BUG", "Frosmoth");
    }
}
class Stonjourner extends Pokemon {
    public Stonjourner() {
        super(100, 135, 125, 20, 20, 70, "ROCK", "NA", "Stonjourner");
    }
}
class EiscueIce extends Pokemon {
    public EiscueIce() {
        super(75, 110, 80, 65, 90, 50, "ICE", "NA", "Eiscue Ice Face");
    }
}
class EiscueNoice extends Pokemon {
    public EiscueNoice() {
        super(75, 70, 80, 65, 50, 130, "ICE", "NA", "Eiscue Noice Face");
    }
}
class IndeedeeM extends Pokemon {
    public IndeedeeM() {
        super(60, 55, 65, 105, 95, 95, "PSYCHIC", "NORMAL", "Indeedee (Male)");
    }
}
class IndeedeeF extends Pokemon {
    public IndeedeeF() {
        super(70, 65, 55, 95, 105, 85, "PSYCHIC", "NORMAL", "Indeedee (Female)");
    }
}
class MorpekoFullBelly extends Pokemon {
    public MorpekoFullBelly() {
        super(58, 58, 95, 70, 58, 97, "ELECTRIC", "DARK", "Morpeko Full Belly Mode");
    }
}
class MorpekoHangry extends Pokemon {
    public MorpekoHangry() {
        super(58, 58, 95, 70, 58, 97, "ELECTRIC", "DARK", "Morpeko Hangry Mode");
    }
}
class Cufant extends Pokemon {
    public Cufant() {
        super(72, 49, 80, 40, 49, 40, "STEEL", "NA", "Cufant");
    }
}
class Copperajah extends Pokemon {
    public Copperajah() {
        super(122, 69, 130, 80, 69, 30, "STEEL", "NA", "Copperajah");
    }
}
class Dracozolt extends Pokemon {
    public Dracozolt() {
        super(90, 90, 100, 80, 70, 75, "ELECTRIC", "DRAGON", "Dracozolt");
    }
}
class Arctozolt extends Pokemon {
    public Arctozolt() {
        super(90, 90, 100, 90, 80, 55, "ELECTRIC", "ICE", "Arctozolt");
    }
}
class Dracovish extends Pokemon {
    public Dracovish() {
        super(90, 100, 90, 70, 80, 75, "WATER", "DRAGON", "Dracovish");
    }
}
class Arctovish extends Pokemon {
    public Arctovish() {
        super(90, 100, 90, 80, 90, 55, "WATER", "ICE", "Arctovish");
    }
}
class Duraludon extends Pokemon {
    public Duraludon() {
        super(70, 115, 95, 120, 50, 85, "STEEL", "DRAGON", "Duraludon");
    }
}
class Dreepy extends Pokemon {
    public Dreepy() {
        super(28, 30, 60, 40, 30, 82, "DRAGON", "GHOST", "Dreepy");
    }
}
class Drakloak extends Pokemon {
    public Drakloak() {
        super(68, 50, 80, 60, 50, 102, "DRAGON", "GHOST", "Drakloak");
    }
}
class Dragapult extends Pokemon {
    public Dragapult() {
        super(88, 75, 120, 100, 75, 142, "DRAGON", "GHOST", "Dragapult");
    }
}
class ZacianCrowned extends Pokemon {
    public ZacianCrowned() {
        super(92, 115, 170, 80, 115, 148, "FAIRY", "STEEL", "Zacian Crowned Sword");
    }
}
class ZacianHero extends Pokemon {
    public ZacianHero() {
        super(92, 115, 130, 80, 115, 138, "FAIRY", "NA", "Zacian Hero of Many Battles");
    }
}
class ZamazentaCrown extends Pokemon {
    public ZamazentaCrown() {
        super(92, 145, 130, 80, 145, 128, "FIGHTING", "STEEL", "Zamazenta Crowned Shield");
    }
}
class ZamazentaHero extends Pokemon {
    public ZamazentaHero() {
        super(92, 115, 130, 80, 115, 138, "FIGHTING", "NA", "Zamazenta Hero of Many Battles");
    }
}
class Eternatus extends Pokemon {
    public Eternatus() {
        super(140, 95, 85, 145, 95, 130, "POISON", "DRAGON", "Eternatus");
    }
}
class EternatusMax extends Pokemon {
    public EternatusMax() {
        super(255, 250, 115, 125, 250, 130, "POISON", "DRAGON", "Eternamax");
    }
}
class Kubfu extends Pokemon {
    public Kubfu() {
        super(60, 60, 90, 53, 50, 72, "FIGHTING", "NA", "Kubfu");
    }
}
class UrshifuSingle extends Pokemon {
    public UrshifuSingle() {
        super(100, 100, 130, 63, 60, 97, "FIGHTING", "DARK", "Urshifu Single Strike Style");
    }
}
class UrshifuRapid extends Pokemon {
    public UrshifuRapid() {
        super(100, 100, 130, 63, 60, 97, "FIGHTING", "WATER", "Urshifu Rapid Strike Style");
    }
}
class Zarude extends Pokemon {
    public Zarude() {
        super(105, 105, 120, 70, 95, 105, "DARK", "GRASS", "Zarude");
    }
}
class Regieleki extends Pokemon {
    public Regieleki() {
        super(80, 50, 100, 100, 50, 200, "ELECTRIC", "NA", "Regieleki");
    }
}
class Regidrago extends Pokemon {
    public Regidrago() {
        super(200, 50, 100, 100, 50, 80, "DRAGON", "NA", "Regidrago");
    }
}
class Glastrier extends Pokemon {
    public Glastrier() {
        super(100, 130, 145, 65, 110, 30, "ICE", "NA", "Glastrier");
    }
}
class Spectrier extends Pokemon {
    public Spectrier() {
        super(100, 60, 65, 145, 80, 130, "GHOST", "NA", "Spectrier");
    }
}
class Calyrex extends Pokemon {
    public Calyrex() {
        super(100, 80, 80, 80, 80, 80, "PSYCHIC", "GRASS", "Calyrex");
    }
}
class CalyrexIce extends Pokemon {
    public CalyrexIce() {
        super(100, 150, 165, 85, 130, 50, "PSYCHIC", "ICE", "Calyrex Ice Rider");
    }
}
class CalyrexShadow extends Pokemon {
    public CalyrexShadow() {
        super(100, 80, 85, 165, 100, 150, "PSYCHIC", "GHOST", "Calyrex Shadow Rider");
    }
}
class Wyrdeer extends Pokemon {
    public Wyrdeer() {
        super(103, 72, 105, 105, 75, 65, "NORMAL", "PSYCHIC", "Wyrdeer");
    }
}
class Kleavor extends Pokemon {
    public Kleavor() {
        super(70, 95, 135, 45, 70, 85, "BUG", "ROCK", "Kleavor");
    }
}
class Ursaluna extends Pokemon {
    public Ursaluna() {
        super(130, 105, 140, 45, 80, 50, "NORMAL", "GROUND", "Ursaluna");
    }
}
class BasculegionM extends Pokemon {
    public BasculegionM() {
        super(120, 65, 112, 80, 75, 78, "WATER", "GHOST", "Basculegion (Male)");
    }
}
class BasculegionF extends Pokemon {
    public BasculegionF() {
        super(120, 65, 92, 100, 75, 78, "WATER", "GHOST", "Basculegion (Female)");
    }
}
class Sneasler extends Pokemon {
    public Sneasler() {
        super(80, 60, 130, 40, 80, 120, "POISON", "FIGHTING", "Sneasler");
    }
}
class Overqwil extends Pokemon {
    public Overqwil() {
        super(85, 95, 115, 65, 65, 85, "DARK", "POISON", "Overqwil");
    }
}
class EnamorusIncarnate extends Pokemon {
    public EnamorusIncarnate() {
        super(74, 70, 115, 135, 80, 106, "FAIRY", "FLYING", "Enamorus Incarnate Forme");
    }
}
class EnamorusTherian extends Pokemon {
    public EnamorusTherian() {
        super(74, 110, 115, 135, 100, 46, "FAIRY", "FLYING", "Enamorus Therian Forme");
    }
}