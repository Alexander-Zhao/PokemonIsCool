class Main {
    public static void main(String[] args) {
        // System.out.println("i am cool");
        Player coolKid = new Player();
        coolKid.menu();
    }
}